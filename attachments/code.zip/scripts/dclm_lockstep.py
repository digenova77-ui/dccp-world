#!/usr/bin/env python3
"""DCLM idempotency lockstep for DCCP World modules.

For each canonical module file in public/registry (plus the final Trinity verdict bytes):
  1. client computes SHA-256 of the exact file bytes (labelled client-computed);
  2. payload "dccpworld|module|<name>|<sha256>" (<=256 bytes) is submitted to DCLM API v2 twice;
  3. the module is LOCKSTEP only if both are accepted with identical inputDigest.
Only sequence, inputDigest, stateDigest (and accepted/protocolVersion) from the API are kept.
Output: public/dclm-receipts.json. Re-running is safe: payloads are content-addressed.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
REG = ROOT / "public/registry"
API = "https://dualiscapax.ai/api/v2"
VERDICT = ROOT / "trinity/VERDICT-DCCPWORLD-V1.json"


def submit(payload: str) -> dict:
    for attempt in range(3):
        try:
            r = requests.post(f"{API}/compute", json={"payload": payload, "flags": 0}, timeout=20)
            if r.ok:
                j = r.json()
                return {k: j.get(k) for k in ("accepted", "reason", "sequence", "inputDigest", "stateDigest", "protocolVersion")}
            last = {"accepted": False, "http": r.status_code}
        except Exception as exc:  # network failure -> retry, then record honestly
            last = {"accepted": False, "error": type(exc).__name__}
        time.sleep(1.5 * (attempt + 1))
    return last


def main() -> int:
    # The verdict is copied byte-for-byte so the browser hashes the same bytes that were receipted.
    shutil.copyfile(VERDICT, REG / "trinity-verdict.json")
    modules = sorted(p for p in REG.glob("*.json"))
    out = []
    for p in modules:
        raw = p.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        payload = f"dccpworld|module|{p.stem}|{digest}"
        assert len(payload.encode()) <= 256, payload
        a, b = submit(payload), submit(payload)
        lock = bool(a.get("accepted") and b.get("accepted") and a.get("inputDigest") and a.get("inputDigest") == b.get("inputDigest"))
        out.append({"module": p.stem, "file": f"registry/{p.name}", "bytes": len(raw), "clientSha256": digest,
                    "payload": payload, "receipts": [a, b], "lockstep": lock})
        print(f"{p.stem:<18} lockstep={lock} seq={[a.get('sequence'), b.get('sequence')]} in={str(a.get('inputDigest'))[:16]}")
    try:
        prov = requests.get(f"{API}/provenance", timeout=15).json()
    except Exception:
        prov = {}
    doc = {
        "schema": "dccpworld.dclm-receipts/1",
        "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "kernelEndpoint": f"{API}/compute",
        "kernelProvenance": {"source": "GET /api/v2/provenance (kernel-published, not part of the compute receipt)",
                             "artifactSha256": prov.get("artifactSha256"), "backend": prov.get("backend")},
        "rule": "LOCKSTEP = two submissions of the same content-addressed payload, both accepted, identical inputDigest",
        "labels": {"clientSha256": "client-computed SHA-256 of the exact module bytes",
                   "receipts": "fields returned by DCLM API v2 compute"},
        "modules": out,
    }
    (ROOT / "public/dclm-receipts.json").write_text(json.dumps(doc, indent=1, ensure_ascii=False) + "\n")
    bad = [m["module"] for m in out if not m["lockstep"]]
    print("not locked:", bad or "none")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
