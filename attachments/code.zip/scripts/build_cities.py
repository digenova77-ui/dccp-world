#!/usr/bin/env python3
"""Build public/registry/cities.json from Natural Earth 1:50m populated places (public domain).

Deterministic: fixed field order, sorted rows, rounded coordinates, canonical JSON bytes.
Usage: python3 scripts/build_cities.py /path/to/ne_50m_populated_places_simple.geojson
"""
import json, sys, unicodedata
from pathlib import Path

def ascii_name(s: str) -> str:
    return unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode().strip()

src = json.load(open(sys.argv[1], encoding='utf-8'))
rows = []
for f in src['features']:
    p = f['properties']
    name = p.get('nameascii') or ascii_name(p.get('name') or '')
    if not name:
        continue
    rows.append({
        'name': name,
        'a3': p.get('adm0_a3') or '',
        'region': ascii_name(p.get('adm1name') or ''),
        'lat': round(float(p['latitude']), 3),
        'lon': round(float(p['longitude']), 3),
        'pop': int(p.get('pop_max') or 0),
        'capital': 1 if p.get('adm0cap') else 0,
        'kind': p.get('featurecla') or '',
    })
rows.sort(key=lambda r: (r['a3'], -r['pop'], r['name']))
doc = {'cities': rows, 'source': 'Natural Earth 1:50m populated places (public domain), naturalearthdata.com', 'note': 'pop = Natural Earth pop_max estimate; not a live census.'}
out = Path(__file__).resolve().parent.parent / 'public' / 'registry' / 'cities.json'
out.write_text(json.dumps(doc, sort_keys=True, separators=(',', ':'), ensure_ascii=False), encoding='utf-8')
print(f'cities: {len(rows)} rows -> {out} ({out.stat().st_size} bytes)')
