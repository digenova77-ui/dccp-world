// Convert a TTF into a Three.js typeface JSON (facetype.js format) for TextGeometry.
// Usage: node scripts/make-typeface.mjs <in.ttf> <out.json>
import { readFileSync, writeFileSync } from 'node:fs'
import opentype from 'opentype.js'

const [input, output] = process.argv.slice(2)
const buf = readFileSync(input)
const font = opentype.parse(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength))
const scale = (1000 * 100) / ((font.unitsPerEm || 2048) * 72)
const chars = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~·—–’“”…×²³°'
const glyphs = {}
for (const ch of chars) {
  const g = font.charToGlyph(ch)
  if (!g || (g.unicode === undefined && ch !== ' ')) continue
  const token = { ha: Math.round(g.advanceWidth * scale), x_min: Math.round((g.xMin ?? 0) * scale), x_max: Math.round((g.xMax ?? 0) * scale), o: '' }
  for (const c of g.path.commands) {
    const t = c.type.toLowerCase()
    const r = v => Math.round(v * scale)
    if (t === 'm' || t === 'l') token.o += `${t} ${r(c.x)} ${r(c.y)} `
    else if (t === 'q') token.o += `q ${r(c.x)} ${r(c.y)} ${r(c.x1)} ${r(c.y1)} `
    else if (t === 'c') token.o += `b ${r(c.x)} ${r(c.y)} ${r(c.x1)} ${r(c.y1)} ${r(c.x2)} ${r(c.y2)} `
  }
  glyphs[ch] = token
}
const out = {
  glyphs,
  familyName: font.names.fontFamily?.en ?? 'Sora',
  ascender: Math.round(font.ascender * scale),
  descender: Math.round(font.descender * scale),
  underlinePosition: Math.round((font.tables.post?.underlinePosition ?? -100) * scale),
  underlineThickness: Math.round((font.tables.post?.underlineThickness ?? 50) * scale),
  boundingBox: { yMin: Math.round(font.tables.head.yMin * scale), xMin: Math.round(font.tables.head.xMin * scale), yMax: Math.round(font.tables.head.yMax * scale), xMax: Math.round(font.tables.head.xMax * scale) },
  resolution: 1000,
  original_font_information: { license: 'SIL Open Font License 1.1 — Sora by Jonathan Barnbrook & Julián Moncada' },
  cssFontWeight: 'bold',
  cssFontStyle: 'normal',
}
writeFileSync(output, JSON.stringify(out))
console.log(output, Object.keys(glyphs).length, 'glyphs', JSON.stringify(out).length, 'bytes')
