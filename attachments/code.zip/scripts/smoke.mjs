// End-to-end smoke test for DCCP World. Requires a build in dist/ (`pnpm build`).
// Serves dist/, boots the world in headless Chromium and checks: entry, DCLM receipt integrity,
// every Atlas place, keyboard + dock controls, read mode with a typed question, a phone viewport,
// a fully offline run (feeds must degrade, nothing may hang), and a tampered registry module
// (must be flagged MISMATCH while the world keeps running). Screenshots go to ./shots/.
import { spawn } from 'node:child_process'
import { mkdirSync } from 'node:fs'
import { chromium } from 'playwright'

const port = 4300 + Math.floor(Math.random() * 500)
const origin = `http://127.0.0.1:${port}`
const url = `${origin}/?quality=low`
const out = process.env.SHOTS_DIR ?? 'shots'
mkdirSync(out, { recursive: true })
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--port', String(port), '--strictPort', '--host', '127.0.0.1'], { stdio: 'ignore' })
let browser
const guard = setTimeout(() => fail('timed out after 600 s'), 600_000)
function cleanup() { clearTimeout(guard); try { server.kill('SIGTERM') } catch { /* gone */ } }
async function fail(msg) {
  console.error(`smoke: FAIL — ${msg}`)
  await browser?.close().catch(() => {})
  cleanup()
  process.exit(1)
}
const check = (cond, msg) => { if (!cond) throw new Error(msg) }
async function waitForServer() {
  for (let i = 0; i < 80; i += 1) {
    try { if ((await fetch(origin)).ok) return } catch { /* not yet */ }
    await new Promise(r => setTimeout(r, 250))
  }
  throw new Error('preview server did not start')
}
// Only first-party failures count as errors; third-party feeds are allowed to fail (that is tested separately).
function watch(page, errors, label) {
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource|net::ERR_/.test(m.text())) errors.push(`[${label}] ${m.text()}`) })
  page.on('pageerror', e => errors.push(`[${label}] ${String(e)}`))
  page.on('response', r => { if (r.status() >= 400 && r.url().startsWith(origin)) errors.push(`[${label}] HTTP ${r.status()} ${r.url()}`) })
}
async function boot(context, errors, label, mode = 'listen') {
  const page = await context.newPage()
  watch(page, errors, label)
  await page.goto(url)
  await page.waitForFunction(() => window.__world?.ready === true, null, { timeout: 60_000 })
  await page.click(`[data-enter="${mode}"]`)
  await page.waitForFunction(() => document.querySelector('.gate')?.hidden === true && window.__world.irisAwake === true, null, { timeout: 10_000 })
  return page
}
const world = page => page.evaluate(() => {
  const w = window.__world
  return { ready: w.ready, mode: w.mode, sector: w.sector, integrity: w.integrity, feeds: w.feeds, discovered: w.discovered.length, camera: w.camera, flying: w.flying, awake: w.irisAwake, pickables: w.pickables() }
})

try {
  await waitForServer()
  const args = ['--ignore-gpu-blocklist', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required']
  browser = await chromium.launch({ args }).catch(() => chromium.launch({ args, channel: 'chrome' }))
  const errors = []

  // 1. Desktop, listen mode: integrity, every place, controls.
  const desk = await browser.newContext({ viewport: { width: 1280, height: 720 } })
  const page = await boot(desk, errors, 'desktop')
  await page.waitForTimeout(1500)
  await page.screenshot({ path: `${out}/01-home.png` })
  let s = await world(page)
  check(s.integrity.length === 8 && s.integrity.every(m => m.state === 'MATCH'), `integrity not all MATCH: ${JSON.stringify(s.integrity)}`)
  check(s.pickables >= 80, `only ${s.pickables} interaction points`)
  check(!(await page.locator('.panel.transcript').isVisible()), 'transcript visible by default in listen mode (Iris must be voice-first)')
  console.log(`smoke: ${s.pickables} interaction points, 8/8 DCLM modules MATCH`)

  await page.click('[data-p="atlas"]')
  const n = await page.locator('.atlas-list button').count()
  check(n >= 80, `Atlas lists only ${n} places`)
  await page.screenshot({ path: `${out}/02-atlas.png` })
  // One real pointer click, then the rest through the same buttons in-page (fast on software GPUs).
  await page.locator('.atlas-list button').first().click()
  await page.evaluate(async () => {
    for (const b of document.querySelectorAll('.atlas-list button')) {
      b.click()
      await new Promise(r => setTimeout(r, 80))
    }
  })
  await page.waitForTimeout(2500)
  s = await world(page)
  check(s.discovered === 21, `expected all 21 chambers discovered, got ${s.discovered}`)
  check(s.ready && s.awake, 'world or Iris died during the Atlas sweep')
  await page.screenshot({ path: `${out}/03-after-sweep.png` })
  console.log(`smoke: visited all ${n} Atlas places; 21/21 chambers discovered`)

  await page.evaluate(() => window.__world.goTo({ kind: 'jurisdiction', key: 'Japan' }))
  await page.waitForTimeout(4000)
  await page.screenshot({ path: `${out}/04-japan.png` })
  await page.evaluate(() => window.__world.goTo({ kind: 'dclm', key: 'dclm' }))
  await page.waitForTimeout(4000)
  await page.screenshot({ path: `${out}/05-dclm.png` })

  const before = (await world(page)).camera
  await page.locator('#game').focus()
  for (const k of ['ArrowLeft', 'ArrowLeft', 'ArrowUp', '+', '-']) await page.keyboard.press(k)
  await page.waitForTimeout(300)
  const after = (await world(page)).camera
  check(Math.hypot(after[0] - before[0], after[1] - before[1], after[2] - before[2]) > 0.05, 'keyboard orbit did not move the camera')
  await page.keyboard.press('n')
  await page.waitForTimeout(200)
  check((await world(page)).flying, 'N did not start a flight')
  await page.keyboard.press(' ')
  await page.keyboard.press('h')
  await page.waitForTimeout(3500)
  for (const t of ['sound', 'haptics', 'reducedMotion', 'transcript']) {
    const b = page.locator(`[data-t="${t}"]`)
    const v0 = await b.getAttribute('aria-pressed')
    await b.click()
    check((await b.getAttribute('aria-pressed')) !== v0, `dock toggle ${t} did not change`)
    await b.click()
  }
  console.log('smoke: keyboard orbit/zoom/next/pause/home and all dock toggles respond')

  const reply = await page.evaluate(() => window.__world.ask('How is Japan doing in water?'))
  check(/Japan in Water/.test(reply?.speech ?? ''), `Iris grade answer wrong: ${reply?.speech}`)
  const unknown = await page.evaluate(() => window.__world.ask('quantum banana'))
  check(/do not hold that yet/.test(unknown?.speech ?? ''), 'Iris invented an answer')
  await page.waitForTimeout(800)
  await desk.close()

  // 2. Read mode: transcript visible, typed question answered.
  const reader = await browser.newContext({ viewport: { width: 1280, height: 720 } })
  const rp = await boot(reader, errors, 'read', 'read')
  check(await rp.locator('.panel.transcript').isVisible(), 'transcript hidden in read mode')
  await rp.fill('#ask-input', 'what is the universal rte')
  await rp.press('#ask-input', 'Enter')
  await rp.waitForFunction(() => /Universal RTE/i.test(document.querySelector('.log')?.textContent ?? ''), null, { timeout: 8000 })
  await rp.waitForTimeout(2500)
  await rp.screenshot({ path: `${out}/06-read-mode.png` })
  console.log('smoke: read mode answers a typed question in the transcript')
  await reader.close()

  // 3. Phone viewport with touch.
  const phone = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true })
  const pp = await boot(phone, errors, 'phone')
  await pp.waitForTimeout(1200)
  const box = await pp.locator('.dock').boundingBox()
  check(box && box.x >= 0 && box.x + box.width <= 390, 'dock overflows the phone viewport')
  await pp.evaluate(() => window.__world.goTo({ kind: 'chamber', key: 'unity-id' }))
  await pp.waitForTimeout(4000)
  await pp.screenshot({ path: `${out}/07-phone.png` })
  await phone.close()

  // 4. Offline: every third-party feed and the font CDN blocked. Nothing may hang.
  const offline = await browser.newContext({ viewport: { width: 1280, height: 720 } })
  await offline.route(r => !r.toString().startsWith(origin), route => route.abort('internetdisconnected'))
  const op = await boot(offline, errors, 'offline')
  await op.waitForFunction(() => window.__world.feeds.every(f => f.state === 'UNAVAILABLE'), null, { timeout: 30_000 })
  const offAnswer = await op.evaluate(() => window.__world.ask('where is the space station'))
  check(/unavailable right now/.test(offAnswer?.speech ?? ''), `offline ISS answer not honest: ${offAnswer?.speech}`)
  await op.evaluate(() => window.__world.goTo({ kind: 'feed', key: 'weather' }))
  await op.waitForTimeout(4000)
  await op.screenshot({ path: `${out}/08-offline.png` })
  check((await world(op)).ready, 'world died while offline')
  console.log('smoke: offline — all 6 feeds UNAVAILABLE, Iris says so, world keeps running')
  await offline.close()

  // 5. Tamper: one registry module altered in transit must be flagged, not trusted silently.
  const tamper = await browser.newContext({ viewport: { width: 1280, height: 720 } })
  await tamper.route(`${origin}/registry/canada.json`, async route => {
    const res = await route.fetch()
    const body = (await res.text()).replace('Ontario', 'Ontar1o')
    await route.fulfill({ response: res, body })
  })
  const tp = await boot(tamper, errors, 'tamper')
  const ts = await world(tp)
  const canada = ts.integrity.find(m => m.module === 'canada')
  check(canada?.state === 'MISMATCH', `tampered module not flagged: ${JSON.stringify(canada)}`)
  check(ts.integrity.filter(m => m.state === 'MATCH').length === 7, 'other modules should still MATCH')
  const dclm = await tp.evaluate(() => window.__world.ask('check with dclm'))
  check(/canada/i.test(dclm?.speech ?? ''), `Iris did not report the mismatched module: ${dclm?.speech}`)
  await tp.evaluate(() => window.__world.goTo({ kind: 'dclm', key: 'dclm' }))
  await tp.waitForTimeout(4000)
  await tp.screenshot({ path: `${out}/09-tamper.png` })
  console.log('smoke: tampered canada.json flagged MISMATCH; 7/8 still MATCH; Iris reports it')
  await tamper.close()

  if (errors.length) throw new Error(`console/page errors:\n  ${errors.join('\n  ')}`)
  await browser.close()
  cleanup()
  console.log(`smoke: PASS — screenshots in ${out}/`)
  process.exit(0)
} catch (err) {
  await fail(err instanceof Error ? err.message : String(err))
}
