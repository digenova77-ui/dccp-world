#!/usr/bin/env python3
"""Build src/data/registry.json for DCCP World from the user's Unity Framework / RTE sources.

Deterministic: same inputs -> byte-identical output (sorted keys, no timestamps in content).
Sources: /home/ubuntu/rte-src (Drive exports of unity-framework v6-68, rte-suite, specs).
"""
from __future__ import annotations

import hashlib
import html
import json
import re
from pathlib import Path

SRC = Path("/home/ubuntu/rte-src")
UF = SRC / "unity-v6-68/unity-framework"
OUT = Path(__file__).resolve().parents[1] / "src/data/registry.json"

# Representative coordinates (capital or geographic centre) — used only to place markers.
COORDS = {
    "United States": (38.9, -77.0), "Canada": (45.4, -75.7), "United Kingdom": (51.5, -0.1),
    "Germany": (52.5, 13.4), "France": (48.9, 2.35), "Japan": (35.7, 139.7), "Australia": (-35.3, 149.1),
    "China": (39.9, 116.4), "India": (28.6, 77.2), "Brazil": (-15.8, -47.9), "Argentina": (-34.6, -58.4),
    "Ukraine": (50.45, 30.5), "Nigeria": (9.1, 7.5), "South Africa": (-25.7, 28.2), "Mexico": (19.4, -99.1),
    "Netherlands": (52.4, 4.9), "South Korea": (37.6, 127.0), "Egypt": (30.0, 31.2), "Switzerland": (46.9, 7.45),
    "Spain": (40.4, -3.7), "Sweden": (59.3, 18.1), "New Zealand": (-41.3, 174.8), "Italy": (41.9, 12.5),
    "Israel": (31.8, 35.2),
}
ALIASES = {"USA": "United States", "UK": "United Kingdom"}
ISO = {"United States": "US", "Canada": "CA", "United Kingdom": "UK", "Germany": "DE", "France": "FR", "Japan": "JP",
       "Australia": "AU", "China": "CN", "India": "IN", "Brazil": "BR", "Argentina": "AR", "Ukraine": "UA",
       "Nigeria": "NG", "South Africa": "ZA", "Mexico": "MX", "Netherlands": "NL", "South Korea": "KR", "Egypt": "EG",
       "Switzerland": "CH", "Spain": "ES", "Sweden": "SE", "New Zealand": "NZ", "Italy": "IT", "Israel": "IL"}

SECTOR_META = {
    "water": ("Water", "NWIS-RICH", "hydrological observation data"),
    "energy": ("Energy", "GRID-RICH", "electricity-grid telemetry"),
    "climate": ("Climate", "CLIMATE-RICH", "greenhouse-gas and atmospheric-observation data"),
    "food": ("Food", "seven-dimension food benchmark", "food production, stocks, trade, price, nutrition and verification data"),
    "pandemic": ("Pandemic", "seven-dimension pandemic benchmark", "case, genomic, hospital, mortality, vaccination and verification data"),
}


def text_of(fragment: str) -> str:
    t = re.sub(r"<script.*?</script>|<style.*?</style>", "", fragment, flags=re.S)
    t = re.sub(r"<[^>]+>", " ", t)
    return re.sub(r"\s+", " ", html.unescape(t)).strip()


def grade_of(raw: str) -> str:
    raw = raw.upper()
    for g in ("AT BENCHMARK", "NEAR", "GAPPED", "THIN"):
        if g in raw:
            return g
    return "UNGRADED"


def sentences(text: str, n: int) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", text)
    out = []
    for p in parts:
        p = p.strip()
        if 25 <= len(p) <= 260 and not p.isupper():
            out.append(p)
        if len(out) >= n:
            break
    return out


def sectors() -> tuple[list[dict], dict]:
    verdicts = json.loads((SRC / "sector-verdicts.json").read_text())
    out, juris = [], {}
    for key, (name, bench, scope) in SECTOR_META.items():
        page = (UF / f"{key}-countries.html").read_text()
        headline = text_of(re.search(r"<h1[^>]*>(.*?)</h1>", page, re.S).group(1)) if re.search(r"<h1", page) else name
        rows = []
        for r in verdicts[key]["rows"]:
            jname = ALIASES.get(r["jurisdiction"], r["jurisdiction"])
            rows.append({"jurisdiction": jname, "grade": grade_of(r["grade"]), "fact": r["fact"]})
            j = juris.setdefault(jname, {"name": jname, "iso": ISO[jname], "lat": COORDS[jname][0], "lon": COORDS[jname][1], "grades": {}})
            j["grades"][key] = {"grade": grade_of(r["grade"]), "fact": r["fact"]}
        counts = {g: sum(1 for r in rows if r["grade"] == g) for g in ("AT BENCHMARK", "NEAR", "GAPPED", "THIN")}
        out.append({"key": key, "name": name, "benchmark": bench, "scope": scope, "headline": headline,
                    "researched": "2026-09-28", "state": "PILOT · RESEARCH — modeled analysis on public figures, not a live feed",
                    "source": f"Unity Framework · {key}-countries.html (v6-68)", "rows": rows, "counts": counts})
    return out, juris


def pharmacology() -> dict:
    v = json.loads((SRC / "sector-verdicts.json").read_text())["pharmacology"]
    return {"key": "pharmacology", "name": "Pharmacology", "state": "DESIGN STAGE — no estate research conducted; no grades assigned",
            "arc": "proteome (structure) → genome (code) → pharmacology (intervention)",
            "estates": [{"name": r["jurisdiction"], "note": r["fact"]} for r in v["rows"]],
            "source": "Unity Framework · pharmacology.html (v6-68)"}


CANADA = [
    {"key": "ca", "name": "All Canada", "lat": 56.1, "lon": -106.3, "systems": "National aggregate", "guard": "Canada Health Infoway CA Core · CIHI reporting"},
    {"key": "on", "name": "Ontario", "lat": 50.0, "lon": -85.0, "systems": "Meditech Expanse, Epic, Oracle Health (Cerner); ConnectingOntario, OLIS; 50+ Ontario Health Teams, Quinte Health, UHN", "guard": "PHIPA · Bill 119 · ConnectingOntario rules"},
    {"key": "ab", "name": "Alberta", "lat": 53.9, "lon": -116.6, "systems": "Connect Care (Epic, province-wide); Alberta Netcare, PIN; AHS", "guard": "Health Information Act (HIA)"},
    {"key": "bc", "name": "British Columbia", "lat": 53.7, "lon": -127.6, "systems": "CST Cerner Millennium, Meditech Expanse; CareConnect, PLIS; VCH, Fraser, PHSA, Island, Interior", "guard": "FIPPA · E-Health Act"},
    {"key": "qc", "name": "Quebec", "lat": 52.9, "lon": -73.5, "systems": "CIUSSS/CISSS; DSQ modernization", "guard": "Law 25 (former Bill 64)"},
    {"key": "atl", "name": "Atlantic Canada", "lat": 46.5, "lon": -63.0, "systems": "Nova Scotia OPOR (Epic), Horizon/Vitalité NB, IWK", "guard": "Provincial health-information acts"},
    {"key": "pn", "name": "Prairies & North", "lat": 54.0, "lon": -102.0, "systems": "eHealth Saskatchewan, eChart Manitoba, Shared Health MB, SHA", "guard": "Provincial health-information acts"},
]

RTES = [
    {"key": "health", "name": "RTE-Health", "job": "Clinical informatics (SIMA-DCLM)", "status": "APPROVED · published · living", "kind": "suite",
     "about": "A deterministic, mobile-first operating workspace for clinical informatics, training and adoption on EHR implementations across Canadian health authorities. Governed by the triad: DCLM computes friction and capacity, Iris enforces the 4.20 millisecond render ceiling and zero PHI, Twain squared filters for bedside usability.",
     "facts": ["Click-Burden Index: clicks times 1, tabs times 2.5, modals times 4, app swaps times 3 — the portal's own formula.", "Zero point zero zero percent PHI ingested, logged or retained — the stated invariant."]},
    {"key": "teach", "name": "RTE-Teach", "job": "The classroom seat", "status": "DRAFT · published · living", "kind": "suite",
     "about": "The classroom seat. No registry file exists yet, so its three reserved hooks render zero colon one until the extractor output is wired.", "facts": []},
    {"key": "ice", "name": "RTE-Ice", "job": "Hockey seat · U16 AAA", "status": "DRAFT · published · living", "kind": "suite",
     "about": "A sovereign hockey runtime for players and families: no subscription traps, minor athletes' biometrics and carpool locations zeroized after the game, objective ice metrics instead of scouting noise. The hockey registry is withheld from publication because it carries minors' names.", "facts": []},
    {"key": "golf", "name": "RTE-Golf", "job": "Golfer seat", "status": "DRAFT · published · living", "kind": "suite",
     "about": "The golfer's seat: club choice on a real course with real wind, weather and time-of-day green speeds. It reads its bundled golf registry snapshot.", "facts": []},
    {"key": "hospitality", "name": "RTE-Hospitality", "job": "Host seat · the venue as instrument", "status": "DRAFT · published · living", "kind": "suite",
     "about": "The venue as an instrument. It reads its hospitality registry snapshot and fails closed to an honest zero colon one when the snapshot is empty.", "facts": []},
    {"key": "financials", "name": "RTE-Financials", "job": "Principal seat · finance, held to evidence", "status": "DRAFT · published · living", "kind": "suite",
     "about": "Finance held to evidence. Its figures are inlined from the financials registry at build time; a re-sync rebuilds the page from the registry, never by hand.", "facts": []},
    {"key": "civic", "name": "RTE-Civic", "job": "The town's ledger, honestly", "status": "LANDED · cloned room", "kind": "unity",
     "about": "Municipal residual-cost analysis, cloned from the framework root by the five-step recipe. No municipal figures are banked yet, so every slot is a named zero colon one. The room is complete anyway — the framework carries the shape.", "facts": ["Operating budget: zero colon one, reserved.", "Households served: zero colon one, reserved.", "Cost per household: derived, never measured — reserved."]},
    {"key": "athletic", "name": "Athletic Intelligence RTE", "job": "Unified sports operating system (hockey)", "status": "SPEC · live-stream simulator storyboard", "kind": "spec",
     "about": "A unified sports operating system storyboard: one family pass consolidating streaming, event breakdown and scheduling apps, with cognitive scouting synthesis. Athlete identities are not shown in this world.", "facts": []},
    {"key": "baseball", "name": "Baseball Diamond Module", "job": "Diamond operating system", "status": "SPEC · storyboard", "kind": "spec",
     "about": "The Athletic Intelligence RTE's baseball module storyboard: radar ballistics, pitch tunnelling and biomechanics in one pass. Athlete identities are not shown in this world.", "facts": []},
    {"key": "flight", "name": "DCCP Crypto Flight HUD", "job": "The DCCP pipe as a flight instrument", "status": "SPEC · concept art", "kind": "spec",
     "about": "A heads-up display concept for flying the DCCP pipe. Concept art only; no coin moves through it.", "facts": []},
    {"key": "publicsector", "name": "Public Sector à la carte", "job": "Residual-cost onboarding pathways", "status": "SPEC · production draft", "kind": "spec",
     "about": "Six pathways — small business, commercial and fleets, public sector and school boards, global enterprise, startups and unowned domains, and families. Its figures are the draft's own illustrative claims, not audited results.", "facts": ["Look and measure are free — the diverter spec's rule.", "If it cannot invert, it is not spent — the Fuel invariant."]},
    {"key": "energy", "name": "Energy & SCADA RTE", "job": "Microgrids, plants and utilities", "status": "SPEC · landing taxonomy", "kind": "spec",
     "about": "Planned landings for foundries, cold storage, microgrid nodes and wastewater plants in the Iris diverter's thousand-landing taxonomy. Not built yet.", "facts": []},
]

CHAMBER_PAGES = ["index", "the-why", "design-law", "data-law", "authority", "consultation", "rite", "unity-id", "onboarding",
                 "clone", "mesh", "reading", "wisdom", "protocol", "engine", "elements", "tree-sitemap", "iris-lineage",
                 "genome", "proteome", "ledger"]


def chambers() -> list[dict]:
    out = []
    for key in CHAMBER_PAGES:
        p = UF / f"{key}.html"
        if not p.exists():
            continue
        s = p.read_text()
        title = text_of(re.search(r"<title>(.*?)</title>", s, re.S).group(1)).split(" — ")[0].split(" · ")[0]
        h1 = re.search(r"<h1[^>]*>(.*?)</h1>", s, re.S)
        status = "LANDED" if "LANDED" in s[:6000] else ("DRAFT" if "DRAFT" in s[:6000] else "STANDALONE")
        quotes = []
        for m in re.finditer(r'<div class="say">(.*?)</div>', s, re.S):
            ps = re.findall(r"<p(?: class=\"([^\"]*)\")?>(.*?)</p>", m.group(1), re.S)
            body = " ".join(text_of(t) for c, t in ps if c != "who")
            who = " ".join(text_of(t) for c, t in ps if c == "who")
            body = body.strip("“”\" ")
            if 20 < len(body) < 700:
                quotes.append({"text": body, "who": who})
        cards = [text_of(c) for c in re.findall(r'<div class="card">(.*?)</div>\s*(?=<div class="card"|</main>|<footer)', s, re.S)]
        body = text_of(re.sub(r'<div class="say">.*?</div>', " ", s, flags=re.S))
        summary = sentences(body.split("←", 1)[-1], 6)
        out.append({"key": key, "title": title, "headline": text_of(h1.group(1)) if h1 else title, "status": status,
                    "summary": summary, "quotes": quotes[:6], "source": f"Unity Framework · {key}.html (v6-68)", "cards": len(cards)})
    return out


DOCTRINE = {
    "definition": "it's application of logic to every retrievable result you can find I guess if you wanted to define it 'as something'.",
    "universal_rte": "so essentially the root of the RTE framework is universal and the applications you're developing are merely data models being implemented into that framework.",
    "honest_mirror": "that should be your overarching encompassing goal too to not over claim or not overstate but to simply mirror what is gatherable intelligence providing it in the most logical construct you possibly can. claiming truth and cure is overstepping our boundary here.",
    "dependency": "it's also displaying in real time to the world that we're dependent on your data. we're not reinventing a wheel. if your data goes dead it hurts us. conversely. if your data grows and your data sets get more information on we're unstoppable. the ball is where the ball has always been and will always stay in your court.",
    "peg": "in other words nobody sells the efuse. it's supply is capped and it is the bedrock of the system",
    "manifesto": "the most important things are the ones that cost have not been pegged to or understood and they are driving up a residual loss. we need to tackle that first",
    "unity_id": "One identifier. No exposed name. A stable internal identifier — for people, corporations, and silicon agents alike.",
    "hook": "The Unity ID hook is reserved. A hook is not an issuance.",
}


def main() -> None:
    secs, juris = sectors()
    reg = {
        "schema": "dccpworld.registry/1",
        "sources": "Google Drive: unity-framework-20260929-v6-68.zip, rte-suite-20260928.zip, SIMA-DCLM RTE specs, ED-SPEC-20260904-DIVERTER-V1, DCLM-RTE-V2.0.4 manifest",
        "doctrine": DOCTRINE,
        "sectors": secs,
        "pharmacology": pharmacology(),
        "jurisdictions": sorted(juris.values(), key=lambda j: j["name"]),
        "canada": CANADA,
        "rtes": RTES,
        "chambers": chambers(),
    }
    data = json.dumps(reg, sort_keys=True, ensure_ascii=False, indent=1)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(data + "\n")
    print(OUT, len(data), "bytes sha256", hashlib.sha256(data.encode()).hexdigest()[:16])
    # Canonical per-module files: these exact bytes are hashed and receipted by DCLM, and the
    # browser re-hashes the same bytes before trusting them.
    mod_dir = Path(__file__).resolve().parents[1] / "public/registry"
    mod_dir.mkdir(parents=True, exist_ok=True)
    for name in ("doctrine", "sectors", "pharmacology", "jurisdictions", "canada", "rtes", "chambers"):
        raw = json.dumps(reg[name], sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
        (mod_dir / f"{name}.json").write_bytes(raw)
        print("  module", name, len(raw), hashlib.sha256(raw).hexdigest()[:16])
    print("sectors", len(secs), "jurisdictions", len(juris), "chambers", len(reg["chambers"]), "rtes", len(RTES))
    for c in reg["chambers"]:
        print(" ", c["key"], c["status"], len(c["summary"]), len(c["quotes"]), "|", c["headline"][:70])


if __name__ == "__main__":
    main()
