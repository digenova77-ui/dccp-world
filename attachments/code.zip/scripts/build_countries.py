#!/usr/bin/env python3
"""Build public/registry/countries.json from Natural Earth 1:50m Admin-0 countries (public domain).

Deterministic: sorted by ISO/ADM0 code, coordinates rounded to 0.05 degrees, rings simplified with
Douglas-Peucker (tolerance 0.06 deg), canonical JSON (sorted keys, no whitespace). The exact bytes are
then receipted by DCLM through scripts/dclm_lockstep.py like every other registry module.

Usage: python3 scripts/build_countries.py /path/to/ne_50m_admin_0_countries.geojson
"""
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "registry" / "countries.json"
TOL = 0.06
Q = 20  # 1/20 deg = 0.05 deg


def dp(pts, tol):
    if len(pts) < 4:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        ax, ay = pts[a]
        bx, by = pts[b]
        dx, dy = bx - ax, by - ay
        L = math.hypot(dx, dy) or 1e-12
        best, idx = 0.0, -1
        for i in range(a + 1, b):
            px, py = pts[i]
            d = abs(dy * px - dx * py + bx * ay - by * ax) / L
            if d > best:
                best, idx = d, i
        if best > tol and idx > 0:
            keep[idx] = True
            stack += [(a, idx), (idx, b)]
    return [p for p, k in zip(pts, keep) if k]


def ring(coords):
    raw = [(float(c[0]), float(c[1])) for c in coords]
    # A closed ring has identical endpoints, which makes Douglas-Peucker see zero deviation.
    # Simplify it as two open halves split at the midpoint, then rejoin.
    mid = len(raw) // 2
    pts = dp(raw[: mid + 1], TOL) + dp(raw[mid:], TOL)[1:]
    out = []
    for x, y in pts:
        q = [round(x * Q) / Q, round(y * Q) / Q]
        if not out or out[-1] != q:
            out.append(q)
    if len(out) < 4:
        return None
    flat = []
    for x, y in out:
        flat += [x, y]
    return flat


def main(src):
    d = json.loads(Path(src).read_text())
    rows = []
    for f in d["features"]:
        p = f["properties"]
        g = f["geometry"]
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
        rings = []
        for poly in polys:
            r = ring(poly[0])  # outer ring only; holes are not needed for outlines or picking at this scale
            if r:
                rings.append(r)
        if not rings:
            continue
        xs = [v for r in rings for v in r[0::2]]
        ys = [v for r in rings for v in r[1::2]]
        code = p["ISO_A3"] if p.get("ISO_A3") not in (None, "-99") else p["ADM0_A3"]
        rows.append({
            "a3": code,
            "name": p["NAME"],
            "continent": p.get("CONTINENT") or "",
            "subregion": p.get("SUBREGION") or "",
            "pop": int(p.get("POP_EST") or 0),
            "popYear": int(p.get("POP_YEAR") or 0),
            "gdpMd": int(p.get("GDP_MD") or 0),
            "gdpYear": int(p.get("GDP_YEAR") or 0),
            "label": [round(float(p["LABEL_X"]), 3), round(float(p["LABEL_Y"]), 3)],
            "bbox": [min(xs), min(ys), max(xs), max(ys)],
            "rings": rings,
        })
    rows.sort(key=lambda r: (r["a3"], r["name"]))
    doc = {"source": "Natural Earth 1:50m Admin 0 countries (public domain), naturalearthdata.com", "simplified": f"Douglas-Peucker {TOL} deg, 0.05 deg grid", "countries": rows}
    data = json.dumps(doc, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    OUT.write_text(data, encoding="utf-8")
    pts = sum(len(r) // 2 for c in rows for r in c["rings"])
    print(f"countries: {len(rows)} countries, {pts} points, {len(data.encode())} bytes -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ne/c50.geojson")
