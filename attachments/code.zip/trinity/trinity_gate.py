#!/usr/bin/env python3
"""Trinity gate for DCCP World.

1. Three independent reviewers (DCLM / Iris / Twain²), each on a different model family,
   vote on every proposal item: ANSWER | CONDITIONAL | REJECT, with conditions.
2. Deterministic reconciliation (chain call):
   - any REJECT                       -> HOLD (not built)
   - otherwise all ANSWER             -> IMPLEMENT
   - otherwise                        -> IMPLEMENT-WITH-CONDITIONS (union of conditions binds the build)
3. DCLM decides admission: each reconciled decision record is canonicalised and its SHA-256
   is submitted to the live DCLM kernel twice. The decision is admitted only if both
   submissions are accepted with identical inputDigest (idempotency lockstep). Otherwise HOLD.

The DCLM kernel is deterministic and non-arbitrary: it does not judge design merit. It is the
admission gate and receipt authority for decisions the reviewers reached.
"""
from __future__ import annotations

import concurrent.futures as cf
import hashlib
import json
import re
import sys
import time
from pathlib import Path

import requests
from openai import OpenAI

ROOT = Path(__file__).resolve().parent
PACKET = ROOT / "PROPOSAL-DCCPWORLD-V1.md"
OUT = ROOT / "VERDICT-DCCPWORLD-V1.json"
DCLM = "https://dualiscapax.ai/api/v2/compute"

ROLES = {
    "DCLM": {
        "model": "gpt-5",
        "brief": (
            "You are the DCLM reviewer of the DualisCapax Trinity — the law and the logic. "
            "You check determinism, invariants, arithmetic, provenance and that every figure "
            "carries value, label, source and claim state. You refuse anything that presents "
            "modeled or stale data as live, invents values for empty slots, or claims a capability "
            "the system does not have (e.g. DCLM arbitrary compute, live browser reach without CORS)."
        ),
    },
    "Iris": {
        "model": "claude-sonnet-4-6",
        "brief": (
            "You are Iris, the governance and security reviewer of the DualisCapax Trinity — the eyes. "
            "You enforce zero PHI/PII, never show minors' names, sealed-room discipline, no overclaim, "
            "no deployment or seal authority claimed by builders, microphone and privacy safety, "
            "accessibility, and that nothing frozen or authoritative (DNS, coin, chain) is touched."
        ),
    },
    "Twain²": {
        "model": "gemini-3.1-pro-preview",
        "brief": (
            "You are Twain², the pragmatic reviewer of the DualisCapax Trinity — the knife. "
            "You strip fluff and ask whether a real person on a real phone or laptop will actually "
            "use and understand this, whether it will load and run without hanging, whether scope "
            "is buildable now in a static browser build, and whether anything is decoration pretending "
            "to be function."
        ),
    },
}

SCHEMA = {
    "type": "object",
    "properties": {
        "items": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "vote": {"type": "string", "enum": ["ANSWER", "CONDITIONAL", "REJECT"]},
                    "reason": {"type": "string"},
                    "conditions": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["id", "vote", "reason", "conditions"],
                "additionalProperties": False,
            },
        },
        "overall": {"type": "string"},
    },
    "required": ["items", "overall"],
    "additionalProperties": False,
}


def item_ids(text: str) -> list[str]:
    return re.findall(r"^\*\*(P\d+) —", text, flags=re.M)


def review(role: str, packet: str, ids: list[str]) -> dict:
    spec = ROLES[role]
    client = OpenAI()
    prompt = (
        f"{spec['brief']}\n\nReview the packet below independently. Vote on EVERY item "
        f"{', '.join(ids)} exactly once. ANSWER = sound as written. CONDITIONAL = build only with the "
        "concrete, testable conditions you list. REJECT = must not be built. Keep each reason under "
        "60 words and each condition a single testable sentence. Do not invent facts about the "
        "sources; judge the proposal as written.\n\n" + packet
    )
    kwargs: dict = {
        "model": spec["model"],
        "messages": [{"role": "user", "content": prompt}],
        "response_format": {"type": "json_schema", "json_schema": {"name": "verdict", "strict": True, "schema": SCHEMA}},
    }
    if spec["model"].startswith("gpt"):
        kwargs["max_completion_tokens"] = 16000
        kwargs["extra_body"] = {"reasoning": {"effort": "medium"}}
    elif spec["model"].startswith("claude"):
        kwargs["max_tokens"] = 12000
        kwargs["extra_body"] = {"thinking": {"type": "enabled", "budget_tokens": 4000}}
    else:
        kwargs["max_tokens"] = 16000
    last: Exception | None = None
    for attempt in range(3):
        try:
            resp = client.chat.completions.create(**kwargs)
            data = json.loads(resp.choices[0].message.content)
            got = {i["id"] for i in data["items"]}
            missing = [i for i in ids if i not in got]
            if missing:
                raise ValueError(f"{role} omitted {missing}")
            return {"role": role, "model": spec["model"], **data}
        except Exception as exc:  # retry on malformed output or transport errors
            last = exc
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"{role} review failed: {last}")


def reconcile(ids: list[str], reviews: list[dict]) -> list[dict]:
    out = []
    for pid in ids:
        votes = {}
        conditions: list[str] = []
        for r in reviews:
            v = next(i for i in r["items"] if i["id"] == pid)
            votes[r["role"]] = {"vote": v["vote"], "reason": v["reason"], "conditions": v["conditions"]}
            conditions += [f"[{r['role']}] {c}" for c in v["conditions"]]
        kinds = {v["vote"] for v in votes.values()}
        if "REJECT" in kinds:
            disposition = "HOLD"
        elif kinds == {"ANSWER"}:
            disposition = "IMPLEMENT"
        else:
            disposition = "IMPLEMENT-WITH-CONDITIONS"
        out.append({"id": pid, "disposition": disposition, "votes": votes, "conditions": conditions})
    return out


def canonical(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()


def dclm_lockstep(decision: dict) -> dict:
    record = {"packet": "ED-PROPOSAL-20261003-DCCPWORLD-V1", "id": decision["id"],
              "disposition": decision["disposition"], "conditions": decision["conditions"]}
    digest = hashlib.sha256(canonical(record)).hexdigest()
    payload = f"dccpworld|trinity|{decision['id']}|{decision['disposition']}|{digest}"
    assert len(payload.encode()) <= 256
    receipts = []
    for _ in range(2):
        try:
            r = requests.post(DCLM, json={"payload": payload, "flags": 0}, timeout=20)
            receipts.append(r.json() if r.ok else {"accepted": False, "http": r.status_code})
        except Exception as exc:
            receipts.append({"accepted": False, "error": type(exc).__name__})
    locked = (len(receipts) == 2 and all(x.get("accepted") for x in receipts)
              and receipts[0].get("inputDigest") == receipts[1].get("inputDigest"))
    return {"payload": payload, "recordSha256": digest, "receipts": receipts, "lockstep": locked}


def main() -> int:
    packet = PACKET.read_text()
    ids = item_ids(packet)
    if not ids:
        print("no items found", file=sys.stderr)
        return 2
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        reviews = list(ex.map(lambda role: review(role, packet, ids), ROLES))
    decisions = reconcile(ids, reviews)
    for d in decisions:
        d["dclm"] = dclm_lockstep(d)
        if not d["dclm"]["lockstep"]:
            d["disposition"] = "HOLD"
            d["holdReason"] = "DCLM lockstep not achieved"
    provenance = {}
    try:
        provenance = requests.get("https://dualiscapax.ai/api/v2/provenance", timeout=15).json()
    except Exception:
        provenance = {"unavailable": True}
    result = {
        "packet": "ED-PROPOSAL-20261003-DCCPWORLD-V1",
        "packetSha256": hashlib.sha256(packet.encode()).hexdigest(),
        "decidedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "rule": "any REJECT -> HOLD; all ANSWER -> IMPLEMENT; else IMPLEMENT-WITH-CONDITIONS; DCLM double-submission with identical inputDigest required for admission",
        "kernel": provenance,
        "reviews": [{"role": r["role"], "model": r["model"], "overall": r["overall"]} for r in reviews],
        "decisions": decisions,
    }
    OUT.write_text(json.dumps(result, indent=1, ensure_ascii=False))
    for d in decisions:
        v = " ".join(f"{k}:{x['vote'][0]}" for k, x in d["votes"].items())
        print(f"{d['id']:>4} {d['disposition']:<26} {v}  lockstep={d['dclm']['lockstep']} seq={[x.get('sequence') for x in d['dclm']['receipts']]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
