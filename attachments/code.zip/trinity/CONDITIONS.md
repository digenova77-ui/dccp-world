# Trinity conditions — DCCP World v1

## P1 IMPLEMENT
## P2 IMPLEMENT
## P3 IMPLEMENT
## P4 IMPLEMENT
## P5 IMPLEMENT
## P6 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: Microphone-derived interaction and speech services require meaningful consent, privacy controls, and a non-voice accessible route; voice-only output otherwise excludes Deaf users and can silently disclose speech to browser services.
- Twain² CONDITIONAL: Browser Web Speech API is notoriously inconsistent across devices and browsers, especially on mobile platforms. Needs strict fallbacks.
  * [Iris] Microphone access and any network-backed speech-recognition service must require an explicit informed opt-in before audio capture begins.
  * [Iris] No audio, transcript, intent text, or derived voice data may be retained or transmitted except to a speech service explicitly disclosed and accepted by the visitor.
  * [Iris] The world must provide keyboard-operable, screen-reader-accessible non-voice navigation and equivalent access to Iris content without displaying Iris text in the default visual experience.
  * [Twain²] The UI must explicitly display a 'Microphone/Speech API unavailable' fallback button that allows tap navigation if speech recognition fails to initialize or returns an error.
## P7 IMPLEMENT-WITH-CONDITIONS
- DCLM CONDITIONAL: Live polling is constrained to public CORS-open feeds with freshness states and fault isolation, but instruments must show source and timing to avoid mislabeling.
- Twain² CONDITIONAL: Browser CORS policies often block direct API calls to public feeds unless they explicitly allow cross-origin requests.
  * [DCLM] Each telemetry instrument renders its source name and last-updated time beside its LIVE/STALE/UNAVAILABLE state.
  * [DCLM] Only feeds that respond with permissive CORS headers from the world origin are polled; others are labeled UNAVAILABLE.
  * [Twain²] Every feed must be tested for CORS headers allowing browser fetch; any feed lacking them must be removed or proxied through a build-time static snapshot.
## P8 IMPLEMENT-WITH-CONDITIONS
- DCLM CONDITIONAL: Idempotent digesting and bundled receipts are sound, but 'kernel artifact SHA-256' is not defined by API v2 and must not be implied as kernel-provided.
- Iris CONDITIONAL: Local digest comparison is a valid integrity check, but calling a display state a seal can imply authority, and inclusion of a Trinity verdict must not predate or alter the final authorized record.
  * [DCLM] Receipts bundled include only sequence, inputDigest, and stateDigest returned by API v2.
  * [DCLM] Any additional hash is clearly labeled client-computed and not attributed to the kernel.
  * [Iris] Every red or green receipt display must be labelled as a client-side integrity status and must not be called a seal, finalization, approval, or Trinity verdict.
  * [Iris] The bundled verdict digest must be generated only from the final Trinity verdict record and must identify its packet ID and immutable source bytes.
  * [Iris] Each displayed receipt must be verifiably bound to the exact canonical module bytes and kernel artifact hash included in the released bundle.
## P9 IMPLEMENT
## P10 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: Depth styling is acceptable, but information conveyed through 3D labels and tilted plates must not become inaccessible through camera position, visual effects, or screen-reader omission.
- Twain² CONDITIONAL: 3D extruded text generates massive polygon counts that will crash mobile browsers or cause severe thermal throttling if overused.
  * [Iris] Every informational 3D label and detail plate must have an equivalent programmatically determinable text alternative available to assistive technology.
  * [Twain²] All extruded 3D text must be baked into optimized geometries or replaced with signed distance field (SDF) rendering if the polygon count drops mobile framerates below 30fps.
## P11 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: Haptics and low-frequency audio can create sensory and accessibility harms if triggered automatically, while a mute toggle alone does not ensure informed control over audio or vibration.
  * [Iris] Audio thumps, vibration, and gamepad rumble must be disabled by default until a user gesture enables them and must each have an independently operable persistent off control.
  * [Iris] Reduced-motion and reduced-sensory preferences must suppress nonessential haptic, rumble, and interaction-thump effects.
## P12 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: Free-fly motion, bloom, ambient audio, and smooth flights need accessible alternatives and user control; an always-available home control alone does not mitigate motion or sensory risk.
- Twain² CONDITIONAL: Post-processing effects like bloom can severely degrade performance on integrated GPUs and mobile devices.
  * [Iris] The world must provide keyboard-accessible home, pause-flight, and non-motion navigation controls that remain available during every camera transition.
  * [Iris] Ambient audio must be off until user activation and must have a persistent mute control.
  * [Iris] Reduced-motion preference must disable automatic flights and nonessential camera motion.
  * [Twain²] The bloom effect must automatically disable itself if the device fails to maintain a stable 30fps during the initial load sequence.
## P13 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: An open browser tab cannot be guaranteed to run indefinitely because browsers, devices, networks, and power management may suspend or terminate it; the current wording overclaims reliability.
- Twain² CONDITIONAL: Memory leaks in Three.js from uncleared geometries and accumulating DOM nodes will crash a browser left open indefinitely.
  * [Iris] All user-facing copy must state that operation and polling are best-effort while the browser tab remains active and must not promise indefinite execution or continuous re-verification.
  * [Twain²] The application must pass a 24-hour automated memory profiling test without exceeding a 10% increase in baseline heap usage.
## P14 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: A visually hidden live region assists screen-reader users but does not give Deaf visitors equivalent access to spoken Iris responses, so it does not resolve the stated accessibility tension by itself.
  * [Iris] An opt-in visible transcript and keyboard-operable text alternative must provide content equivalent to Iris speech for Deaf and speech-disabled visitors.
  * [Iris] The visible transcript mode must be available without microphone permission and must not be presented as a lesser or incomplete experience.
## P15 IMPLEMENT
## P16 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: A local-only discovery loop is compatible with the boundaries, provided the answer bank remains source-bounded and does not expose names, PHI/PII, or unresolved material as settled doctrine.
  * [Iris] The Unity answer bank must be reviewed before bundling to exclude PHI, PII, and all minors' names.
  * [Iris] Every answer must be traceable to a bundled source passage or an explicit DEFER, REASSESS, or 0:1 record.
  * [Iris] Discovery progress must remain solely on the visitor device unless the visitor separately opts in to an identified export mechanism.
## P17 IMPLEMENT-WITH-CONDITIONS
- Iris CONDITIONAL: The pilot label properly avoids claiming Unity Network issuance, but a 64-bit truncated public-key hash has avoidable collision risk and passkeys may be synchronised rather than physically confined to one device.
- Twain² CONDITIONAL: WebAuthn requires a secure context and a relying party ID that matches the domain. It must fail gracefully.
  * [Iris] The pilot handle must use at least the first 32 hexadecimal characters of SHA-256(public key) or another collision-resistant identifier of equivalent strength.
  * [Iris] The interface must describe the credential as authenticator-bound and must not claim it never leaves a physical device unless non-syncing device binding is technically verified.
  * [Iris] Creating a passkey must require explicit user confirmation after disclosure that the resulting pilot handle is a persistent pseudonymous identifier stored by the visitor's authenticator.
  * [Twain²] The WebAuthn implementation must strictly use the deployment domain as the relying party ID and handle unsupported devices without blocking access.
## P18 HOLD
- DCLM CONDITIONAL: Jacket format and ≤256-byte payload are sound, but CORS blocks live submission; must not fake success or add a server without authority.
- Iris REJECT: Automatic submission of a persistent Unity handle, action, and content-derived digest creates an undisclosed identity-linked engagement record, conflicts with zero-PII discipline, and proposes proxy/CORS paths requiring separate operational authorization. Calling a discovery action “sealing” also risks claiming seal authority.
- Twain² CONDITIONAL: Adding a server proxy violates the 'no server enabled for this build' constraint. The local queue option is the only valid path.
  * [DCLM] In this static build, jackets are queued locally and displayed as PENDING until the kernel becomes CORS-reachable.
  * [DCLM] No proxy server is deployed unless Trinity formally amends the 'no server' constraint for this project.
  * [DCLM] Each jacket payload length is enforced ≤256 bytes before submission or queuing.
  * [Twain²] The build must remain strictly static, queuing jackets locally and displaying 'DCCP binding pending a reachable kernel' until the kernel explicitly allows CORS.
