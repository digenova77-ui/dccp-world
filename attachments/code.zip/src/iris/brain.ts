// Agent Iris — Universal Conversational Diverter (ED-SPEC-20260904-DIVERTER-V1), deterministic.
// Same words + same state -> same reply. Every answer is drawn from the bundled registry or the
// live-feed snapshot, or says plainly that it is not held / not determined.
import type { Chamber, Registry, Rte } from '../data/types'
import type { FeedStatus, FeedValues } from '../live/feeds'

export type TargetKind = 'chamber' | 'rte' | 'sector' | 'jurisdiction' | 'canada' | 'feed' | 'dclm' | 'pipe' | 'iris' | 'universal' | 'earth' | 'estates' | 'country' | 'city'
export interface Target { kind: TargetKind; key: string }
export type IrisAction = 'home' | 'sleep' | 'unity-id-disclose' | 'unity-id-create' | 'none'
export interface IrisReply { speech: string; target?: Target; action: IrisAction; source?: string; sector?: string }

export interface LiveSnapshot { values: FeedValues; status: FeedStatus[] }
export interface DclmSummary { locked: number; total: number; mismatched: string[]; lastSequence?: number }

const SECTOR_WORDS: Record<string, string[]> = {
  water: ['water', 'hydrology', 'hydrological', 'rivers', 'streamflow'],
  energy: ['energy', 'electricity', 'grid', 'power'],
  climate: ['climate', 'emissions', 'greenhouse', 'atmosphere'],
  food: ['food', 'agriculture', 'farming', 'crops', 'nutrition'],
  pandemic: ['pandemic', 'pandemics', 'disease', 'outbreak', 'outbreaks', 'epidemic'],
  pharmacology: ['pharmacology', 'drugs', 'drug', 'medicines', 'pharma'],
}
const JUR_ALIASES: Record<string, string[]> = {
  'United States': ['usa', 'america', 'united states', 'the us', 'u s', 'states'],
  'United Kingdom': ['uk', 'britain', 'great britain', 'england', 'united kingdom'],
  'South Korea': ['korea', 'south korea'],
  'New Zealand': ['new zealand', 'kiwi'],
  'South Africa': ['south africa'],
}
const CANADA_ALIASES: Record<string, string[]> = {
  on: ['ontario', 'quinte', 'toronto', 'phipa'], ab: ['alberta', 'connect care'], bc: ['british columbia', 'b c', 'vancouver'],
  qc: ['quebec', 'québec', 'law 25'], atl: ['atlantic', 'nova scotia', 'new brunswick', 'maritimes'], pn: ['prairies', 'saskatchewan', 'manitoba', 'the north'],
  ca: ['all canada', 'pan canadian', 'pan-canadian'],
}
const RTE_ALIASES: Record<string, string[]> = {
  health: ['health', 'hospital', 'clinical', 'sima', 'nursing', 'ehr'], teach: ['teach', 'teacher', 'classroom', 'education'],
  ice: ['ice', 'hockey', 'rink'], golf: ['golf', 'golfer', 'course'], hospitality: ['hospitality', 'hotel', 'venue', 'restaurant'],
  financials: ['financials', 'finance', 'financial', 'money', 'accounting'], civic: ['civic', 'town', 'municipal', 'city', 'municipality'],
  athletic: ['athletic', 'athletics', 'sports', 'scouting'], baseball: ['baseball', 'diamond', 'pitching'],
  flight: ['flight', 'hud', 'crypto flight', 'heads up'], publicsector: ['public sector', 'a la carte', 'school boards', 'pathways', 'small business'],
  energy: ['scada', 'microgrid', 'microgrids', 'utilities', 'plants'],
}
const CHAMBER_ALIASES: Record<string, string[]> = {
  index: ['unity framework', 'framework', 'playground', 'poster', 'cornerstone'], 'the-why': ['why', 'the why', 'residual', 'royalty'],
  'design-law': ['design law', 'design'], 'data-law': ['data law', 'evidence', 'claim'], authority: ['authority', 'gate', 'vote'],
  consultation: ['consultation', 'consult', 'consults'], rite: ['rite', 'services'], 'unity-id': ['unity id', 'identity', 'identifier', 'seat', 'landing'],
  onboarding: ['onboarding', 'early', 'why early', 'founder'], clone: ['clone', 'cloning', 'copy', 'recipe'], mesh: ['mesh', 'patent', 'sharing'],
  reading: ['reading', 'reader'], wisdom: ['wisdom', 'knowledge'], protocol: ['protocol', 'mechanism'], engine: ['engine', 'boot', 'mount'],
  elements: ['elements', 'element'], 'tree-sitemap': ['tree', 'sitemap', 'organism', 'unity tree'], 'iris-lineage': ['lineage', 'iris lineage', 'holders'],
  genome: ['genome', 'genomic', 'dna'], proteome: ['proteome', 'protein', 'proteins', 'structure'], ledger: ['ledger', 'judgments', 'record'],
}
const FEED_ALIASES: Record<string, string[]> = {
  quakes: ['earthquake', 'earthquakes', 'quake', 'quakes', 'seismic'], iss: ['iss', 'space station', 'station', 'satellite'],
  weather: ['weather', 'temperature', 'wind', 'belleville weather', 'outside'], kp: ['kp', 'geomagnetic', 'aurora', 'solar storm', 'space weather'],
  carbon: ['carbon intensity', 'grid carbon', 'national grid'], river: ['river', 'moira', 'water level', 'discharge', 'hydrometric'],
}

export function normalize(s: string): string {
  return ` ${s.toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9²\s-]/g, ' ').replace(/-/g, ' ').replace(/\s+/g, ' ').trim()} `
}
const has = (t: string, phrase: string): boolean => t.includes(` ${normalize(phrase).trim()} `)
const any = (t: string, phrases: string[]): boolean => phrases.some(p => has(t, p))
const longest = (t: string, table: Record<string, string[]>): { key: string; len: number } | undefined => {
  let best: { key: string; len: number } | undefined
  for (const [key, phrases] of Object.entries(table)) for (const p of phrases) if (has(t, p) && (!best || p.length > best.len)) best = { key, len: p.length }
  return best
}

/** Make registry text speakable: no symbols the voice would mangle. */
export function speakable(s: string): string {
  return s
    .replace(/https?:\/\/\S+/g, '')
    .replace(/0:1/g, 'zero colon one')
    .replace(/Twain²|Twain\^2/g, 'Twain squared')
    .replace(/²/g, ' squared')
    .replace(/→/g, ' to ')
    .replace(/[·•|]/g, ', ')
    .replace(/≤/g, 'at most ')
    .replace(/≥/g, 'at least ')
    .replace(/[“”"]/g, '')
    .replace(/\s*—\s*/g, ', ')
    .replace(/\s+,/g, ',')
    .replace(/,\s*,/g, ',')
    .replace(/\s+/g, ' ')
    .trim()
}

function cleanSummary(c: Chamber): string[] {
  return c.summary
    .map(s => s.replace(/^The Framework\s+/, '').replace(/^(?:[A-Z0-9·'’\- ]{6,}\s)+/, '').trim())
    .filter(s => s.length > 24 && !/^[A-Z\s·]+$/.test(s) && !/^(ROUTE|SEE|PROVE|FILE)\b/.test(s))
}

const GRADE_WORDS: Record<string, string> = { 'AT BENCHMARK': 'at benchmark', NEAR: 'near benchmark', GAPPED: 'gapped', THIN: 'thin', UNGRADED: 'not graded' }
/** Close a registry fragment as a sentence so spliced facts never run together when spoken. */
export const sentence = (s: string | undefined): string => {
  const x = (s ?? '').trim()
  return !x ? '' : /[.!?…:]$/.test(x) ? x : `${x}.`
}
const fmtAgo = (ms: number): string => {
  const m = Math.round(ms / 60000)
  if (m < 1) return 'moments ago'
  if (m < 60) return `${m} minute${m === 1 ? '' : 's'} ago`
  const h = Math.round(m / 60)
  return `${h} hour${h === 1 ? '' : 's'} ago`
}

export class IrisBrain {
  private last?: { target: Target; cursor: number }
  private pending: 'unity-id' | null = null
  private lastSpeech = ''

  constructor(private reg: Registry, private live: () => LiveSnapshot, private dclm: () => DclmSummary, private hasUnityId: () => string | null) {}

  greeting(): IrisReply {
    return this.say('Hello. I am Iris. This is the Unity playground, mirrored as a world. Ask me anything about Unity, or tell me where you want to go. Say help if you want ideas.', undefined, 'none')
  }

  respond(utterance: string, now = Date.now()): IrisReply {
    const t = normalize(utterance)
    if (t.trim() === '') return this.say('I did not catch that. Try again whenever you are ready.')

    if (this.pending === 'unity-id') {
      this.pending = null
      if (any(t, ['confirm', 'yes', 'yes create', 'do it', 'create it', 'go ahead'])) return this.say('Creating your pilot handle now. Your device will ask you to approve a passkey.', { kind: 'chamber', key: 'unity-id' }, 'unity-id-create')
      if (any(t, ['no', 'cancel', 'not now', 'stop'])) return this.say('Cancelled. Nothing was created.', undefined, 'none')
    }
    if (any(t, ['repeat', 'say that again', 'again', 'what did you say'])) return this.say(this.lastSpeech || 'I have not said anything yet.')
    if (any(t, ['go to sleep', 'sleep', 'goodbye', 'bye', 'stop listening', 'be quiet', 'quiet'])) return this.say('Resting now. Touch the orb when you want me again.', undefined, 'sleep')
    if (any(t, ['go home', 'home', 'take me back', 'start over', 'back to start'])) return this.say('Back to the overlook. Earth in front of you, the Unity ring around it, the Universal RTE root below.', { kind: 'earth', key: 'home' }, 'home')
    if (any(t, ['tell me more', 'more', 'go on', 'continue', 'keep going', 'next'])) return this.more()
    if (any(t, ['help', 'what can i ask', 'what can you do', 'what do i do', 'how does this work', 'how do i play'])) return this.help()
    if (any(t, ['who are you', 'what are you', 'your name', 'about you', 'are you iris'])) return this.selfIntro()
    if (/^\s*(hello|hi|hey|good morning|good evening|good afternoon|yo)\b/.test(t) && t.trim().split(' ').length <= 4) return this.say('Hello. I am listening. Where would you like to go in the Unity playground?')

    // DCCP jacket binding: held by the Trinity.
    if (any(t, ['jacket', 'bind me', 'engage dccp', 'engage in dccp', 'connect me to dccp', 'api v2', 'submit to dclm'])) return this.jacketHold()
    if (any(t, ['create my unity id', 'make my unity id', 'get a unity id', 'give me a unity id', 'my unity id', 'sign me up', 'create unity id'])) return this.unityIdDisclose()

    // Concepts with no single location.
    if (any(t, ['efuse', 'e fuse', 'peg', 'the peg'])) return this.say(`In David's words: ${this.reg.doctrine.peg}. eFuse is the capped bedrock of the system. Its full tokenomics are not settled in what I hold.`, { kind: 'dclm', key: 'dclm' }, 'none', 'Unity Framework doctrine')
    if (any(t, ['trinity', 'twain', 'twain squared', 'verdict', 'umpires'])) return this.trinity()
    if (any(t, ['universal rte', 'universal', 'root', 'rte framework', 'what is an rte', 'what is rte', 'rte']) && !longest(t, RTE_ALIASES)) return this.universal()
    if (any(t, ['dclm', 'deterministic', 'logic machine', 'kernel', 'receipt', 'receipts', 'integrity', 'verify', 'check with dclm'])) return this.dclmSpeech()
    if (any(t, ['dccp', 'pipe', 'release pipe', 'ipfs', 'ipns', 'pinata', 'release'])) return this.pipe()
    if (any(t, ['manifesto', 'residual loss', 'cost to zero'])) return this.say(`The manifesto, in David's words: ${this.reg.doctrine.manifesto}.`, { kind: 'chamber', key: 'index' }, 'none', 'Unity Framework · index')
    if (any(t, ['honest mirror', 'mirror', 'overclaim', 'over claim'])) return this.say(`The honest mirror. David said: ${this.reg.doctrine.honest_mirror}`, { kind: 'chamber', key: 'data-law' }, 'none', 'Unity Framework doctrine')

    const feed = longest(t, FEED_ALIASES)
    const sector = longest(t, SECTOR_WORDS)
    const jur = this.matchJurisdiction(t)
    const scope = longest(t, CANADA_ALIASES)
    const rte = longest(t, RTE_ALIASES)
    const chamber = longest(t, CHAMBER_ALIASES)

    if (feed && (feed.len >= (chamber?.len ?? 0) || feed.key === 'river')) return this.feed(feed.key, now)
    if (sector && jur) return this.grade(sector.key, jur)
    if (scope && (!rte || scope.len >= rte.len)) return this.canada(scope.key)
    if (jur) return this.jurisdiction(jur)
    if (any(t, ['benchmark', 'best', 'leader', 'leading', 'top']) && sector) return this.benchmark(sector.key)
    if (sector && (!rte || sector.len >= rte.len || sector.key !== 'energy' || !any(t, RTE_ALIASES.energy))) return this.sector(sector.key)
    if (rte && (!chamber || rte.len >= chamber.len)) return this.rte(rte.key)
    if (chamber) return this.chamber(chamber.key)
    if (any(t, ['unity', 'what is unity', 'unity playground'])) return this.chamber('index')
    const city = this.matchCity(t)
    if (city) return this.cityReply(`${city.a3}:${city.name}`)
    const country = this.matchCountry(t)
    if (country) return this.countryReply(country.a3)
    if (any(t, ['earth', 'world', 'globe', 'planet'])) return this.say('This Earth is NASA imagery of record, Blue Marble by day and Black Marble by night, lit by where the sun is right now. It is imagery, not a live camera.', { kind: 'earth', key: 'home' })
    if (any(t, ['iris', 'orb'])) return this.selfIntro()
    return this.say('I do not hold that yet. What I hold is the Unity Framework, the sector country models, every RTE room, and six live public feeds. Try asking about one of those, or say help.')
  }

  /** Spoken description when a visitor selects something by touch or keyboard. */
  describe(target: Target, now = Date.now()): IrisReply {
    switch (target.kind) {
      case 'chamber': return this.chamber(target.key)
      case 'rte': return this.rte(target.key)
      case 'sector': return this.sector(target.key)
      case 'jurisdiction': { const j = this.reg.jurisdictions.find(x => x.name === target.key); return j ? this.jurisdiction(j.name) : this.say('That place is not in what I hold.') }
      case 'canada': return this.canada(target.key)
      case 'feed': return this.feed(target.key, now)
      case 'dclm': return this.dclmSpeech()
      case 'pipe': return this.pipe(target.key)
      case 'universal': return this.universal()
      case 'estates': return this.sector('pharmacology')
      case 'iris': return this.selfIntro()
      case 'country': return this.countryReply(target.key)
      case 'city': return this.cityReply(target.key)
      case 'earth': return this.say('The overlook. Earth in front of you, the Unity ring around it, the Universal RTE root below.', target, 'home')
    }
  }

  private countryNames?: { n: string; a3: string }[]
  private cityNames?: { n: string; key: string }[]
  private static fold(x: string): string {
    return x.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim()
  }
  private matchCountry(t: string): { a3: string } | undefined {
    if (!this.reg.countries) return undefined
    this.countryNames ??= this.reg.countries.countries.map(c => ({ n: IrisBrain.fold(c.name), a3: c.a3 })).filter(c => c.n.length > 3).sort((a, b) => b.n.length - a.n.length)
    const hay = ` ${IrisBrain.fold(t)} `
    return this.countryNames.find(c => hay.includes(` ${c.n} `))
  }
  private matchCity(t: string): { a3: string; name: string } | undefined {
    if (!this.reg.cities) return undefined
    this.cityNames ??= this.reg.cities.cities.filter(c => c.capital || c.pop >= 500_000).map(c => ({ n: IrisBrain.fold(c.name), key: `${c.a3}:${c.name}` })).filter(c => c.n.length > 3).sort((a, b) => b.n.length - a.n.length)
    const hay = ` ${IrisBrain.fold(t)} `
    const hit = this.cityNames.find(c => hay.includes(` ${c.n} `))
    if (!hit) return undefined
    const [a3, ...rest] = hit.key.split(':')
    return { a3, name: rest.join(':') }
  }
  private static people(n: number): string {
    if (!n) return ''
    if (n >= 1e9) return `about ${(n / 1e9).toFixed(1).replace(/\.0$/, '')} billion people`
    if (n >= 1e6) return `about ${Math.round(n / 1e6)} million people`
    if (n >= 1e3) return `about ${Math.round(n / 1e3)} thousand people`
    return `about ${n} people`
  }
  private countryReply(a3: string): IrisReply {
    const c = this.reg.countries?.countries.find(x => x.a3 === a3)
    if (!c) return this.say('That country is not in what I hold.')
    const cap = this.reg.cities?.cities.find(x => x.a3 === a3 && x.capital)
    const graded = this.reg.jurisdictions.find(j => j.iso && c.name.toLowerCase() === j.name.toLowerCase())
    const parts = [`${c.name}, in ${c.subregion || c.continent}.`]
    const ppl = IrisBrain.people(c.pop)
    if (ppl) parts.push(`Home to ${ppl}.`)
    if (cap) parts.push(sentence(`Its capital is ${cap.name}`))
    parts.push(graded ? `I also hold sector grades for ${c.name}; ask me how it does in water or energy.` : 'I hold its borders and cities, not sector grades yet.')
    parts.push('Go lower to see its cities.')
    return this.say(parts.join(' '), { kind: 'country', key: a3 }, 'none', 'Natural Earth')
  }
  private cityReply(key: string): IrisReply {
    const [a3, ...rest] = key.split(':')
    const name = rest.join(':')
    const c = this.reg.cities?.cities.find(x => x.a3 === a3 && x.name === name)
    if (!c) return this.say('That city is not in what I hold.')
    const country = this.reg.countries?.countries.find(x => x.a3 === a3)
    const ppl = IrisBrain.people(c.pop)
    return this.say(`${c.name}${c.capital ? ', the capital' : ''}${country ? ` of ${country.name}` : ''}.${ppl ? ` Around ${ppl.replace('about ', '')} in the wider area.` : ''} The card shows the weather there right now.`, { kind: 'city', key }, 'none', 'Natural Earth')
  }

  private say(speech: string, target?: Target, action: IrisAction = 'none', source?: string, sector?: string): IrisReply {
    const s = speakable(speech)
    this.lastSpeech = s
    if (target) this.last = { target, cursor: 0 }
    return { speech: s, target, action, source, sector }
  }

  private matchJurisdiction(t: string): string | undefined {
    for (const [name, al] of Object.entries(JUR_ALIASES)) if (any(t, al)) return name
    const names = [...this.reg.jurisdictions].sort((a, b) => b.name.length - a.name.length)
    for (const j of names) if (has(t, j.name)) return j.name
    if (has(t, 'canada') && !longest(t, CANADA_ALIASES)) return 'Canada'
    return undefined
  }

  private help(): IrisReply {
    return this.say('Ask me about the Unity playground. The manifesto, the design law, the data law, Unity ID, the Universal RTE. Ask how a country does in water, energy, climate, food or pandemic data, like, how is Japan in water. Ask about the space station, earthquakes, or the weather in Belleville. Say take me to, and I will fly you there. Say tell me more to go deeper, and home to come back.')
  }

  private selfIntro(): IrisReply {
    return this.say('I am Agent Iris, the universal conversational diverter. You tell me what you are looking for, and I take you to where it lives. Looking and measuring are free. I only speak what the registry holds, and I tell you when something is not determined yet.', { kind: 'iris', key: 'iris' })
  }

  private chamber(key: string): IrisReply {
    const c = this.reg.chambers.find(x => x.key === key)
    if (!c) return this.say('That chamber is not in what I hold.')
    const lines = cleanSummary(c)
    const quote = c.quotes[0]
    const status = c.status === 'LANDED' ? 'This chamber has landed.' : c.status === 'DRAFT' ? 'This chamber is still a draft.' : ''
    const body = [`${sentence(c.title)} ${sentence(c.headline)}`, sentence(lines[0]), quote ? `${quote.who.startsWith('HIS') || quote.who === 'DAVID' ? 'In David\'s words' : quote.who.toLowerCase()}: ${sentence(quote.text)}` : '', status]
    if (key === 'unity-id') body.push(this.reg.doctrine.hook, this.hasUnityId() ? 'You already hold a pilot handle on this device.' : 'You can ask me to create a pilot handle on this device.')
    return this.say(body.filter(Boolean).join(' '), { kind: 'chamber', key }, 'none', c.source)
  }

  private more(): IrisReply {
    const l = this.last
    if (!l) return this.say('Pick somewhere first, then ask me for more.')
    l.cursor += 1
    if (l.target.kind === 'chamber') {
      const c = this.reg.chambers.find(x => x.key === l.target.key)!
      const lines = cleanSummary(c)
      const pool = [...lines.slice(1).map(s => ({ s })), ...c.quotes.slice(1).map(q => ({ s: `${q.who.startsWith('HIS') || q.who === 'DAVID' ? 'David said' : q.who.toLowerCase()}: ${sentence(q.text)}` }))]
      const item = pool[l.cursor - 1]
      const reply = this.say(item ? item.s : `That is everything I hold in ${c.title}. Ask me to take you to another chamber.`, undefined, 'none', c.source)
      this.last = l
      return reply
    }
    if (l.target.kind === 'sector') {
      const s = this.reg.sectors.find(x => x.key === l.target.key)
      const row = s?.rows[l.cursor - 1]
      const reply = this.say(row ? `${row.jurisdiction}: ${GRADE_WORDS[row.grade]}. ${row.fact}` : 'That is every jurisdiction in this sector.', undefined, 'none', s?.source)
      this.last = l
      return reply
    }
    if (l.target.kind === 'rte') {
      const r = this.reg.rtes.find(x => x.key === l.target.key)
      const fact = r?.facts[l.cursor - 1]
      const reply = this.say(fact ?? 'That is everything I hold about this room.')
      this.last = l
      return reply
    }
    return this.say('That is everything I hold here.')
  }

  private sector(key: string): IrisReply {
    if (key === 'pharmacology') {
      const p = this.reg.pharmacology
      return this.say(`Pharmacology is at design stage. Ten data estates, from DrugBank to Open Targets, and no grades assigned, because no estate research has been done yet. The arc runs ${p.arc}.`, { kind: 'estates', key: 'pharmacology' }, 'none', p.source, 'pharmacology')
    }
    const s = this.reg.sectors.find(x => x.key === key)
    if (!s) return this.say('That sector is not in what I hold.')
    const c = s.counts
    return this.say(`${s.name}. ${sentence(s.headline)} ${s.rows.length} jurisdictions graded against the ${s.benchmark} benchmark: ${c['AT BENCHMARK'] ?? 0} at benchmark, ${c.NEAR ?? 0} near, ${c.GAPPED ?? 0} gapped, ${c.THIN ?? 0} thin. This is pilot research from ${s.researched}, modeled analysis, not a live feed. Say tell me more to walk through them.`, { kind: 'sector', key }, 'none', s.source, key)
  }

  private benchmark(key: string): IrisReply {
    const s = this.reg.sectors.find(x => x.key === key)
    if (!s) return this.sector(key)
    const top = s.rows.filter(r => r.grade === 'AT BENCHMARK').map(r => r.jurisdiction)
    return this.say(top.length ? `In ${s.name}, at benchmark: ${top.join(', ')}.` : `In ${s.name}, no jurisdiction is graded at benchmark.`, { kind: 'sector', key }, 'none', s.source, key)
  }

  private grade(sectorKey: string, jur: string): IrisReply {
    if (sectorKey === 'pharmacology') return this.sector('pharmacology')
    const j = this.reg.jurisdictions.find(x => x.name === jur)
    const s = this.reg.sectors.find(x => x.key === sectorKey)!
    const g = j?.grades[sectorKey]
    if (!j || !g) return this.say(`${jur} is not graded in ${s.name}. I will not guess a grade.`, j ? { kind: 'jurisdiction', key: j.name } : undefined, 'none', s.source, sectorKey)
    return this.say(`${j.name} in ${s.name}: ${GRADE_WORDS[g.grade]}. ${sentence(g.fact)} Pilot research, ${s.researched}.`, { kind: 'jurisdiction', key: j.name }, 'none', s.source, sectorKey)
  }

  private jurisdiction(name: string): IrisReply {
    const j = this.reg.jurisdictions.find(x => x.name === name)
    if (!j) return this.say(`${name} is not in what I hold.`)
    const parts = Object.entries(j.grades).map(([k, g]) => `${this.reg.sectors.find(s => s.key === k)?.name ?? k} ${GRADE_WORDS[g.grade]}`)
    return this.say(`${j.name}. Graded in ${parts.length} sector${parts.length === 1 ? '' : 's'}: ${parts.join(', ')}. Ask me about one, like, ${j.name} in ${this.reg.sectors.find(s => s.key === Object.keys(j.grades)[0])?.name ?? 'water'}.`, { kind: 'jurisdiction', key: j.name })
  }

  private canada(key: string): IrisReply {
    const c = this.reg.canada.find(x => x.key === key)
    if (!c) return this.say('That part of Canada is not in what I hold.')
    return this.say(`${c.name}, in the pan-Canadian clinical informatics portal. Systems: ${c.systems}. Guarded by ${c.guard}. The invariant is zero patient health information, ingested, logged or retained.`, { kind: 'canada', key }, 'none', 'SIMA-DCLM RTE specification')
  }

  private rte(key: string): IrisReply {
    const r: Rte | undefined = this.reg.rtes.find(x => x.key === key)
    if (!r) return this.say('That room is not in what I hold.')
    return this.say(`${r.name}, ${r.job}. Status: ${r.status}. ${sentence(r.about)}`, { kind: 'rte', key }, 'none', r.kind === 'spec' ? 'RTE specification, Google Drive' : 'RTE suite, v2026-09-28')
  }

  private universal(): IrisReply {
    return this.say(`The Universal RTE. In David's words: ${this.reg.doctrine.universal_rte} Every room you see around this root is a data model seated into the same framework. One RTE per Unity ID.`, { kind: 'universal', key: 'universal' }, 'none', 'Unity Framework doctrine')
  }

  private trinity(): IrisReply {
    const v = this.reg.verdict
    const counts = v.decisions.reduce<Record<string, number>>((a, d) => ((a[d.disposition] = (a[d.disposition] ?? 0) + 1), a), {})
    return this.say(`The Trinity is DCLM, the logic, Iris, the eyes, and Twain squared, the knife. This world went before them as packet ${v.packet.replace(/-/g, ' ')}. ${counts.IMPLEMENT ?? 0} items passed clean, ${counts['IMPLEMENT-WITH-CONDITIONS'] ?? 0} passed with conditions, and ${counts.HOLD ?? 0} is on hold: automatic jacket binding. Those reviewers were role models of the Trinity run by the builder, not a sealed Trinity session.`, { kind: 'dclm', key: 'dclm' }, 'none', 'Trinity verdict')
  }

  private dclmSpeech(): IrisReply {
    const d = this.dclm()
    const mism = d.mismatched.length ? ` These do not match their receipts: ${d.mismatched.join(', ')}.` : ''
    return this.say(`The Deterministic Compute Logic Machine. Every module of this world was submitted to its kernel twice, and the receipts agree, the same input digest both times. Here on your device, ${d.locked} of ${d.total} modules match their receipts byte for byte. That is a client side integrity check, not a seal.${mism} The kernel is deterministic and does no arbitrary compute.`, { kind: 'dclm', key: 'dclm' }, 'none', 'DCLM API v2 receipts')
  }

  private pipe(key = 'pipe'): IrisReply {
    return this.say('The DCCP release pipe. A proposal leaves the DCLM machine, gathers a quorum, is finalized, pinned to IPFS through Pinata, and pointed to by IPNS. What you see is the design. Nothing here is deployed on a chain, and no coin moves through it.', { kind: 'pipe', key }, 'none', 'DCCP authority registry design')
  }

  private jacketHold(): IrisReply {
    return this.say('Automatic jacket binding into DCCP is on hold. The Trinity held it: tying a persistent Unity handle to every action creates an identity linked record, and the kernel is not reachable from this page yet. Nothing about you is being sent anywhere.', { kind: 'dclm', key: 'dclm' }, 'none', 'Trinity verdict P18')
  }

  private unityIdDisclose(): IrisReply {
    const existing = this.hasUnityId()
    if (existing) return this.say('You already hold a pilot handle on this device. It is a pilot, not an issuance by the Unity Network.', { kind: 'chamber', key: 'unity-id' })
    this.pending = 'unity-id'
    return this.say('Before I make one, here is what it is. A pilot Unity handle, made from a passkey your device creates. It is a persistent pseudonymous identifier, stored by your authenticator, which may sync it across your devices. It is not issued by the Unity Network; the issuer and shape still wait on David. No name, email or document is collected. Say confirm to create it, or cancel.', { kind: 'chamber', key: 'unity-id' }, 'unity-id-disclose')
  }

  private feed(key: string, now: number): IrisReply {
    const snap = this.live()
    const st = snap.status.find(s => s.key === key)
    const v = snap.values
    const target: Target = { kind: 'feed', key }
    if (!st) return this.say('That feed is not wired.')
    if (st.state === 'PENDING') return this.say(`${st.title} is still loading from ${st.source}.`, target)
    if (st.state === 'UNAVAILABLE') return this.say(`${st.title} is unavailable right now. ${st.source} did not answer${st.lastError ? `, ${st.lastError}` : ''}. I will keep trying.`, target)
    const ago = st.lastOk ? fmtAgo(now - st.lastOk) : ''
    const stale = st.state === 'STALE' ? ' This reading is stale.' : ''
    const tail = ` From ${st.source}, updated ${ago}.${stale}`
    switch (key) {
      case 'quakes': {
        const q = v.quakes!
        return this.say(`${q.count} earthquakes of magnitude two point five or more in the past day.${q.strongest ? ` The strongest, magnitude ${q.strongest.mag.toFixed(1)}, ${q.strongest.place}.` : ''}${tail}`, target)
      }
      case 'iss': {
        const s = v.iss!
        return this.say(`The space station is at ${Math.abs(s.lat).toFixed(1)} degrees ${s.lat >= 0 ? 'north' : 'south'}, ${Math.abs(s.lon).toFixed(1)} degrees ${s.lon >= 0 ? 'east' : 'west'}, ${Math.round(s.altKm)} kilometres up, moving ${Math.round(s.speedKmh).toLocaleString('en-US')} kilometres an hour, in ${s.visibility || 'unknown'} light.${tail}`, target)
      }
      case 'weather': {
        const w = v.weather!
        return this.say(`In Belleville, Ontario, it is ${Math.round(w.tempC)} degrees, wind ${Math.round(w.windKmh)} kilometres an hour.${tail}`, target)
      }
      case 'kp': return this.say(`The planetary K index is ${v.kp!.kp.toFixed(1)}. ${v.kp!.kp >= 5 ? 'That is storm level; aurora is likely at high latitudes.' : v.kp!.kp >= 4 ? 'Active, not yet a storm.' : 'Quiet.'}${tail}`, target)
      case 'carbon': return this.say(`Great Britain's grid is at ${Math.round(v.carbon!.intensity)} grams of carbon dioxide per kilowatt hour, rated ${v.carbon!.index || 'unrated'}.${tail}`, target)
      case 'river': {
        const r = v.river!
        const parts = [r.levelM !== undefined ? `level ${r.levelM.toFixed(2)} metres` : '', r.dischargeM3s !== undefined ? `discharge ${r.dischargeM3s.toFixed(1)} cubic metres a second` : ''].filter(Boolean)
        return this.say(`The Moira River at Belleville: ${parts.join(', ') || 'no reading in the latest record'}. Provisional real time data.${tail}`, target)
      }
    }
    return this.say('That feed is not wired.', target)
  }
}
