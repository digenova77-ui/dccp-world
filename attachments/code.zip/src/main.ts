import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import './styles/main.css'
import { Renderer, suggestQuality } from './engine/renderer'
import { Flight } from './engine/flight'
import { Haptics, type HapticKind } from './engine/haptics'
import { Ambient } from './engine/ambient'
import { loadFont } from './world/text3d'
import { World } from './world/world'
import { loadRegistry } from './data/registry'
import type { ModuleIntegrity, Registry } from './data/types'
import { LiveFeeds, type FeedValues } from './live/feeds'
import { IrisBrain, type IrisReply, type Target } from './iris/brain'
import { IrisVoice, recognitionSupported, synthesisSupported } from './iris/voice'
import { IrisOrb } from './iris/orb'
import { Overlay, type EntryMode, type Toggles } from './ui/overlay'
import { Card, Ladder, type CardModel } from './ui/card'
import { cardFor, cityCard, countryCard, type CardCtx } from './ui/cards'
import { TIERS, inCountry, toLatLon, tierInfo, type Tier } from './world/geo'
import type { City, Country } from './data/types'
import { createPilotHandle, FAILURE_SPEECH, forgetHandle, storedHandle } from './unity/unityid'

const PREFS = 'dccpworld.prefs.v2' // v2: sound now means optional ambient music, off by default
const DISC = 'dccpworld.discovered.v1'
const FEED_KEYS = ['weather', 'river', 'quakes', 'iss', 'kp', 'carbon'] as const
const prefersReduced = matchMedia('(prefers-reduced-motion: reduce)').matches
const defaults = (): Toggles => ({ sound: false, haptics: false, reducedMotion: prefersReduced, transcript: false })
const loadPrefs = (): Toggles => {
  try { return { ...defaults(), ...JSON.parse(localStorage.getItem(PREFS) ?? '{}') } } catch { return defaults() }
}
const hadPrefs = (): boolean => { try { return localStorage.getItem(PREFS) !== null } catch { return false } }
const savePrefs = (t: Toggles): void => { try { localStorage.setItem(PREFS, JSON.stringify(t)) } catch { /* private mode */ } }

const toggles = loadPrefs()
if (prefersReduced) toggles.reducedMotion = true
const canvas = document.getElementById('game') as HTMLCanvasElement
canvas.tabIndex = 0
const overlay = new Overlay(document.getElementById('ui')!, toggles, recognitionSupported())
const card = new Card(document.getElementById('ui')!)
const ladder = new Ladder(document.getElementById('ui')!, TIERS)
card.setReducedMotion(toggles.reducedMotion)
let shown: Target | null = null

type Q = 'low' | 'medium' | 'high'
function chooseQuality(): Q {
  const forced = new URLSearchParams(location.search).get('quality')
  if (forced === 'low' || forced === 'medium' || forced === 'high') return forced
  let q: Q = suggestQuality()
  try {
    // Software rasterisers (SwiftShader, llvmpipe) and small GPUs cannot hold 4K textures + bloom; never let them crash the tab.
    const probe = document.createElement('canvas').getContext('webgl2') ?? document.createElement('canvas').getContext('webgl')
    if (!probe) return 'low'
    const info = probe.getExtension('WEBGL_debug_renderer_info')
    const name = String(info ? probe.getParameter(info.UNMASKED_RENDERER_WEBGL) : probe.getParameter(probe.RENDERER)).toLowerCase()
    if (/swiftshader|llvmpipe|software|basic render/.test(name)) q = 'low'
    if (probe.getParameter(probe.MAX_TEXTURE_SIZE) < 8192 && q === 'high') q = 'medium'
    probe.getExtension('WEBGL_lose_context')?.loseContext()
  } catch { q = 'low' }
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory
  if (mem !== undefined && mem <= 2) q = 'low'
  return q
}
const quality = chooseQuality()
const renderer = new Renderer(canvas, quality)
canvas.addEventListener('webglcontextlost', e => {
  e.preventDefault()
  overlay.fail('The graphics context was lost. Reload to continue; add ?quality=low to the address for a lighter world.')
})
const scene = new THREE.Scene()
scene.background = new THREE.Color(0x03050b)
const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 2000)
const controls = new OrbitControls(camera, canvas)
controls.enableDamping = true
controls.dampingFactor = 0.08
controls.minDistance = 4
controls.maxDistance = 140
controls.rotateSpeed = 0.6
const flight = new Flight(camera, controls.target)
const haptics = new Haptics()
haptics.enabled = false
let audio: AudioContext | null = null
let ambient: Ambient | null = null
let voice: IrisVoice | null = null
let mode: EntryMode | null = null
let world: World | null = null
let registry: Registry
let integrity: ModuleIntegrity[] = []
let brain: IrisBrain
const feeds = new LiveFeeds()
const orb = new IrisOrb(1.6, quality === 'low' ? 4 : 5)
orb.group.position.set(-9, 3.5, 17)
scene.add(orb.group)
const discovered = new Set<string>((() => { try { return JSON.parse(localStorage.getItem(DISC) ?? '[]') as string[] } catch { return [] } })())
let irisAwake = false
let order: Target[] = []
let cursor = -1
const emptySpectrum = new Uint8Array(64)

function pulse(kind: HapticKind): void {
  if (toggles.haptics && !toggles.reducedMotion) haptics.pulse(kind)
}

async function boot(): Promise<void> {
  const tl = new THREE.TextureLoader()
  const size = quality === 'high' ? 4096 : 2048
  const loadTex = (name: string) => tl.loadAsync(`./textures/earth-${name}-${size}.jpg`).then(t => {
    t.colorSpace = THREE.SRGBColorSpace
    t.anisotropy = renderer.gl.capabilities.getMaxAnisotropy()
    return t
  })
  let timer: number | undefined
  const timeout = new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new Error('Loading took longer than 40 seconds. Check your connection and reload.')), 40_000) as unknown as number })
  const [font, reg, day, night] = await Promise.race([Promise.all([loadFont(), loadRegistry('./'), loadTex('day'), loadTex('night')]), timeout])
  clearTimeout(timer)
  registry = reg.registry
  integrity = reg.integrity
  const w = new World(font, registry, integrity, { day, night }, quality)
  world = w
  scene.add(w.root)
  w.setDiscovered(discovered)
  const home = w.homeFocus()
  camera.position.copy(home.camera)
  controls.target.copy(home.anchor)
  brain = new IrisBrain(registry, () => ({ values: feeds.values, status: [...feeds.status.values()] }), () => ({
    locked: integrity.filter(m => m.state === 'MATCH').length,
    total: integrity.length,
    mismatched: integrity.filter(m => m.state === 'MISMATCH' || m.state === 'NOT-LOCKED').map(m => m.module),
  }), () => storedHandle()?.handle ?? null)
  order = [
    { kind: 'iris', key: 'iris' },
    ...registry.chambers.map(c => ({ kind: 'chamber' as const, key: c.key })),
    { kind: 'universal', key: 'universal' },
    ...registry.rtes.map(r => ({ kind: 'rte' as const, key: r.key })),
    ...['water', 'energy', 'climate', 'food', 'pandemic', 'pharmacology'].map(k => ({ kind: 'sector' as const, key: k })),
    ...registry.jurisdictions.map(j => ({ kind: 'jurisdiction' as const, key: j.name })),
    ...registry.canada.map(c => ({ kind: 'canada' as const, key: c.key })),
    { kind: 'dclm', key: 'dclm' },
    ...['proposal', 'quorum', 'finalize', 'ipfs', 'ipns'].map(k => ({ kind: 'pipe' as const, key: k })),
    ...FEED_KEYS.map(k => ({ kind: 'feed' as const, key: k })),
  ]
  const label = (t: Target): string => (t.kind === 'iris' ? 'Agent Iris, the orb' : w.findPickable(t)?.label ?? t.key)
  const group: Record<string, string> = { iris: 'Iris', chamber: 'Unity playground chambers', universal: 'Universal RTE', rte: 'RTE rooms', sector: 'Sector layers', jurisdiction: 'Jurisdictions', canada: 'Pan-Canadian scopes', dclm: 'DCLM and DCCP', pipe: 'DCLM and DCCP', feed: 'Live public feeds' }
  overlay.setAtlas(order.map((t, i) => ({ id: String(i), group: group[t.kind] ?? 'Other', label: label(t) })))
  refreshUnityId()
  feeds.onUpdate(key => onFeed(key))
  feeds.start()
  for (const k of FEED_KEYS) w.renderInstrument(k, feeds.status.get(k), feeds.values, Date.now())
  overlay.ready()
}

function onFeed(key: keyof FeedValues): void {
  if (!world) return
  world.renderInstrument(key, feeds.status.get(key), feeds.values, Date.now())
  if (key === 'quakes' && feeds.values.quakes) world.setQuakes(feeds.values.quakes.items)
  if (shown && (shown.kind === 'feed' || shown.kind === 'country' || shown.kind === 'city')) refreshCard()
  if (key === 'iss' && feeds.values.iss && Number.isFinite(feeds.values.iss.lat)) world.setIss(feeds.values.iss.lat, feeds.values.iss.lon, feeds.values.iss.altKm)
}

function refreshUnityId(): void {
  overlay.setUnityId(storedHandle()?.handle ?? null, 'A pilot handle is a persistent pseudonymous identifier derived from a passkey your authenticator creates (it may sync across your devices). It is not issued by the Unity Network. No name, email or document is collected, and nothing is sent anywhere.')
}

// ---------------- Iris ----------------
async function irisSays(reply: IrisReply): Promise<void> {
  overlay.iris(reply.speech)
  if (reply.sector && world && reply.sector !== world.sector) world.setSector(reply.sector)
  if (reply.target && reply.action !== 'home') goTo(reply.target, false)
  if (reply.action === 'home') goHome(false)
  if (reply.action === 'unity-id-create') void makeUnityId()
  if (mode !== 'read' && synthesisSupported() && voice) await voice.speak(reply.speech)
  if (reply.action === 'sleep') sleepIris()
}

function hear(text: string): void {
  if (!brain) return
  overlay.visitor(text)
  pulse('tap')
  void irisSays(brain.respond(text))
}

function ensureVoice(): void {
  if (voice) return
  const v = new IrisVoice()
  v.onUtterance = hear
  v.onState = s => {
    ambient?.duck(s === 'speaking')
    overlay.setMic(v.micOn)
    if (s === 'unavailable') { overlay.speechUnavailable(); overlay.setMic(false) }
  }
  voice = v
}

async function wakeIris(): Promise<void> {
  if (!brain) return
  ensureVoice()
  irisAwake = true
  orb.setAwake(true)
  pulse('wake')
  // Speak first, synchronously inside the user's tap (browsers block speech started later),
  // then open the microphone once the greeting has finished.
  const greeted = irisSays(brain.greeting())
  if (mode === 'talk' && voice && !voice.micOn) {
    const ok = await voice.enableMic()
    overlay.setMic(ok)
    if (!ok) overlay.speechUnavailable()
  }
  await greeted
}

function sleepIris(): void {
  irisAwake = false
  orb.setAwake(false)
  voice?.disableMic()
  overlay.setMic(false)
}

// ---------------- navigation ----------------
const cardCtx = (): CardCtx => ({
  reg: registry, integrity, feeds: { values: feeds.values, status: feeds.status }, discovered,
  describe: t => brain?.describe(t).speech ?? '',
  onLate: () => { if (shown) refreshCard() },
})
function countryOf(a3: string): Country | undefined { return world?.geo.byA3.get(a3) }
function cityOf(key: string): City | undefined {
  const [a3, ...rest] = key.split(':'); const name = rest.join(':')
  return registry.cities.cities.find(c => c.a3 === a3 && c.name === name)
}
function modelFor(t: Target): CardModel | null {
  if (t.kind === 'country') { const c = countryOf(t.key); return c ? countryCard(c, cardCtx(), inCountry) : null }
  if (t.kind === 'city') { const c = cityOf(t.key); return c ? cityCard(c, countryOf(c.a3), cardCtx()) : null }
  return cardFor(t, cardCtx())
}
function showCard(t: Target): void {
  const m = modelFor(t)
  shown = m ? t : null
  if (m) card.show(m)
  else card.hide()
}
function refreshCard(): void {
  if (!shown || !card.isOpen) return
  const m = modelFor(shown)
  if (m) card.refresh(m)
}
function clearSelection(): void {
  shown = null
  card.hide()
  world?.mark(null)
  world?.geo.select(null)
  world?.geo.markCity(null)
  if (world) world.focusKind = null
}
/** Fly to a point on the globe at a given storyboard altitude, keeping the view upright. */
function flyGeo(lat: number, lon: number, altitude: number): void {
  if (!world) return
  const f = world.geo.focusFor(lat, lon, altitude)
  flight.to(f.camera, f.anchor, toggles.reducedMotion, () => pulse('arrive'))
}
function goGeo(t: Target, speak: boolean): void {
  if (!world || !brain) return
  world.clearDetail()
  world.mark(null)
  if (t.kind === 'country') {
    const c = countryOf(t.key)
    if (!c) return
    world.geo.select(c)
    world.geo.markCity(null)
    flyGeo(c.label[1], c.label[0], world.geo.countryAltitude(c))
    overlay.announce(c.name)
  } else {
    const c = cityOf(t.key)
    if (!c) return
    const country = countryOf(c.a3)
    if (country && world.geo.selected !== country) world.geo.select(country)
    world.geo.markCity(c)
    flyGeo(c.lat, c.lon, tierInfo('civil').altitude)
    overlay.announce(c.name)
  }
  world.focusKind = t.kind
  pulse('select')
  showCard(t)
  if (speak) void irisSays({ ...brain.describe(t), target: undefined })
}

function goTo(t: Target, speak = true): void {
  if (!world || !brain) return
  if (t.kind === 'country' || t.kind === 'city') return goGeo(t, speak)
  if (t.kind === 'iris') {
    world.clearDetail()
    clearSelection()
    flight.to(new THREE.Vector3(-9, 5, 25), orb.group.position.clone(), toggles.reducedMotion)
    if (speak) void irisSays({ ...brain.describe(t), target: undefined })
    return
  }
  if (t.kind === 'earth') return goHome(speak)
  if (t.kind === 'sector') world.setSector(t.key)
  const p = world.findPickable(t)
  if (!p) return
  const f = p.focus()
  pulse('select')
  flight.to(f.camera, f.anchor, toggles.reducedMotion, () => pulse('arrive'))
  world.clearDetail()
  world.focusKind = t.kind
  world.mark(f.anchor)
  world.geo.markCity(null)
  if (t.kind === 'jurisdiction') {
    const c = world.geo.countries.find(x => x.name.toLowerCase() === t.key.toLowerCase())
    world.geo.select(c ?? null)
  } else world.geo.select(null)
  showCard(t)
  if (t.kind === 'chamber' && !discovered.has(t.key)) {
    discovered.add(t.key)
    try { localStorage.setItem(DISC, JSON.stringify([...discovered])) } catch { /* private mode */ }
    world.setDiscovered(discovered)
    if (discovered.size === registry.chambers.length) pulse('seal')
  }
  overlay.announce(p.label)
  if (speak) {
    const reply = brain.describe(t)
    const all = registry.chambers.length
    if (t.kind === 'chamber') reply.speech += discovered.size === all ? ` That is every chamber of the Unity playground, all ${all}. The tree is lit.` : ` ${discovered.size} of ${all} chambers discovered.`
    void irisSays({ ...reply, target: undefined })
  }
}

function goHome(speak = true): void {
  if (!world || !brain) return
  const h = world.homeFocus()
  world.clearDetail()
  clearSelection()
  flight.to(h.camera, h.anchor, toggles.reducedMotion)
  if (speak) void irisSays({ ...brain.describe({ kind: 'earth', key: 'home' }), action: 'none', target: undefined })
}

async function makeUnityId(): Promise<void> {
  const res = await createPilotHandle()
  refreshUnityId()
  if (res.ok) {
    pulse('seal')
    await irisSays({ speech: 'Done. Your pilot handle is ready on this device, and it is in the Atlas. It is a pilot, not an issuance.', action: 'none' })
  } else {
    pulse('warn')
    await irisSays({ speech: FAILURE_SPEECH[res.reason], action: 'none' })
  }
}

// ---------------- input ----------------
const ray = new THREE.Raycaster()
const ndc = new THREE.Vector2()
let downAt: { x: number; y: number } | null = null
function pickAt(x: number, y: number): Target | 'orb' | null {
  if (!world) return null
  const r = canvas.getBoundingClientRect()
  ndc.set(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1)
  ray.setFromCamera(ndc, camera)
  const objs: THREE.Object3D[] = [orb.core, ...world.pickables.map(p => p.object)]
  for (const h of ray.intersectObjects(objs, true)) {
    let o: THREE.Object3D | null = h.object
    let visible = true
    while (o) { if (!o.visible) { visible = false; break } o = o.parent }
    if (!visible) continue
    if (h.object === orb.core) return 'orb'
    const pick = h.object.userData.pick as Target | undefined
    if (pick?.kind === 'earth') {
      // Tapping the planet chooses what is under your finger: a city near the ground, otherwise its country.
      const ll = toLatLon(h.point)
      const tier = world.tier
      if (tier === 'civil' || tier === 'street') {
        const c = world.geo.cityNear(ll.lat, ll.lon, tier === 'street' ? 0.35 : 0.9)
        if (c) return { kind: 'city', key: `${c.a3}:${c.name}` }
      }
      const country = world.geo.countryAt(ll.lat, ll.lon)
      return country ? { kind: 'country', key: country.a3 } : null
    }
    if (pick) return pick
  }
  return null
}
canvas.addEventListener('pointerdown', e => {
  downAt = { x: e.clientX, y: e.clientY }
  if (flight.active) flight.pause()
})
canvas.addEventListener('pointerup', e => {
  if (!downAt || !world || !mode) return
  const moved = Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y)
  downAt = null
  if (moved > 6) return
  const hit = pickAt(e.clientX, e.clientY)
  if (hit === 'orb') {
    if (!irisAwake) void wakeIris()
    else if (voice?.state === 'speaking') voice.stopSpeaking()
    else goTo({ kind: 'iris', key: 'iris' })
    return
  }
  if (hit) goTo(hit)
})
let hoverT = 0
canvas.addEventListener('pointermove', e => {
  if (!world || !mode || performance.now() - hoverT < 80) return
  hoverT = performance.now()
  canvas.style.cursor = pickAt(e.clientX, e.clientY) ? 'pointer' : 'grab'
})

const step = (dir: number): void => {
  if (!order.length) return
  cursor = (cursor + dir + order.length) % order.length
  goTo(order[cursor])
}
function orbit(az: number, el: number): void {
  flight.pause()
  const off = camera.position.clone().sub(controls.target)
  const sph = new THREE.Spherical().setFromVector3(off)
  sph.theta += az
  sph.phi = THREE.MathUtils.clamp(sph.phi + el, 0.15, Math.PI - 0.15)
  camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(sph))
}
function zoom(f: number): void {
  flight.pause()
  const off = camera.position.clone().sub(controls.target).multiplyScalar(f)
  const len = THREE.MathUtils.clamp(off.length(), controls.minDistance, controls.maxDistance)
  camera.position.copy(controls.target).add(off.setLength(len))
}
window.addEventListener('keydown', e => {
  if (!mode || (e.target as HTMLElement)?.closest?.('input,textarea')) return
  const k = e.key
  if (k === 'ArrowLeft') orbit(-0.08, 0)
  else if (k === 'ArrowRight') orbit(0.08, 0)
  else if (k === 'ArrowUp') orbit(0, -0.06)
  else if (k === 'ArrowDown') orbit(0, 0.06)
  else if (k === '+' || k === '=') zoom(0.88)
  else if (k === '-' || k === '_') zoom(1.12)
  else if (k === 'n' || k === 'N') step(1)
  else if (k === 'p' || k === 'P') step(-1)
  else if (k === ' ') { flight.pause(); voice?.stopSpeaking() }
  else if (k === 'h' || k === 'H') goHome()
  else if (k === 'a' || k === 'A') overlay.togglePanel('atlas')
  else if (k === 't' || k === 'T') { overlay.setToggle('transcript', !toggles.transcript); savePrefs(toggles) }
  else if (k === 'm' || k === 'M') void toggleMic(!voice?.micOn)
  else if (k === 'Escape') { overlay.togglePanel('atlas', false); world?.clearDetail(); clearSelection() }
  else return
  if (k.startsWith('Arrow') || k === ' ') e.preventDefault()
})

async function toggleMic(on: boolean): Promise<void> {
  if (on) {
    mode = 'talk'
    if (!irisAwake) return wakeIris()
    ensureVoice()
    const ok = (await voice?.enableMic()) ?? false
    overlay.setMic(ok)
    if (!ok) overlay.speechUnavailable()
  } else {
    voice?.disableMic()
    overlay.setMic(false)
  }
}

overlay.onToggle = (k, v) => {
  if (k === 'mic') return void toggleMic(v)
  savePrefs(toggles)
  if (k === 'sound') { if (v) startAmbient(); else ambient?.set(false) }
  if (k === 'haptics') { haptics.enabled = v; if (v) pulse('tap') }
  if (k === 'reducedMotion') card.setReducedMotion(v)
}
overlay.onAtlas = id => {
  overlay.togglePanel('atlas', false)
  cursor = Number(id)
  goTo(order[cursor])
}
overlay.onHome = () => goHome()
card.onClose = () => clearSelection()
card.onUp = () => {
  if (!shown) return goHome()
  if (shown.kind === 'city') return goTo({ kind: 'country', key: shown.key.split(':')[0] })
  goHome()
}
card.onAction = (_id, action) => {
  if (!shown || !world || !brain) return
  pulse('tap')
  if (action === 'ask') { void irisSays({ ...brain.describe(shown), target: undefined }); return }
  if (action === 'lower' && shown.kind === 'country') {
    const c = countryOf(shown.key)
    const cap = c && (registry.cities.cities.find(x => x.a3 === c.a3 && x.capital) ?? registry.cities.cities.filter(x => x.a3 === c.a3).sort((a, b) => b.pop - a.pop)[0])
    if (cap) goTo({ kind: 'city', key: `${cap.a3}:${cap.name}` })
    else if (c) flyGeo(c.label[1], c.label[0], tierInfo('civil').altitude)
    return
  }
  if (action === 'street' && shown.kind === 'city') {
    const c = cityOf(shown.key)
    if (c) { flyGeo(c.lat, c.lon, tierInfo('street').altitude); card.setOpen(false) }
    return
  }
  if (action === 'country' && shown.kind === 'jurisdiction') {
    const c = world.geo.countries.find(x => x.name.toLowerCase() === shown!.key.toLowerCase())
    if (c) goTo({ kind: 'country', key: c.a3 })
  }
}
/** Ladder: rise or descend over whatever you are looking at. */
ladder.onTier = (tier: Tier) => {
  if (!world || !mode) return
  pulse('tap')
  if (tier === 'orbit') return goHome(false)
  const look = controls.target.length() > 9 ? controls.target : camera.position
  const ll = toLatLon(look)
  flyGeo(ll.lat, ll.lon, tierInfo(tier).altitude)
  overlay.announce(`${tierInfo(tier).name}: ${tierInfo(tier).what}`)
}
overlay.onAsk = text => hear(text)
overlay.onUnityId = action => {
  if (action === 'forget') {
    forgetHandle()
    refreshUnityId()
    void irisSays({ speech: 'Forgotten on this device. The passkey itself stays in your authenticator until you remove it there.', action: 'none' })
  } else void makeUnityId()
}
overlay.onEnter = m => {
  mode = m
  // Everything here runs synchronously inside the entry tap: show the world, then let Iris speak
  // (speech must start inside the gesture), then set up optional ambient audio without awaiting it.
  overlay.enter()
  ladder.show()
  canvas.focus()
  if (m !== 'read' && !hadPrefs()) toggles.haptics = !toggles.reducedMotion
  if (m === 'read') toggles.transcript = true
  for (const k of ['sound', 'haptics', 'reducedMotion', 'transcript'] as const) overlay.setToggle(k, toggles[k])
  savePrefs(toggles)
  haptics.enabled = toggles.haptics
  void wakeIris()
  if (toggles.sound) startAmbient()
}

function startAmbient(): void {
  try {
    if (!audio) {
      audio = new AudioContext()
      ambient = new Ambient(audio)
    }
    void audio.resume().catch(() => undefined)
    ambient?.duck(voice?.state === 'speaking')
    ambient?.set(true)
  } catch { audio = null; ambient = null }
}

// Any later tap replays speech the browser refused earlier (it must be inside a gesture).
window.addEventListener('pointerdown', () => { voice?.retryIfBlocked() }, { capture: true })
window.addEventListener('keydown', () => { voice?.retryIfBlocked() }, { capture: true })

// ---------------- gamepad ----------------
let padPrev: boolean[] = []
function gamepad(dt: number): void {
  const pad = navigator.getGamepads?.().find(Boolean)
  if (!pad || !mode) return
  const dead = (v: number) => (Math.abs(v) < 0.15 ? 0 : v)
  const lx = dead(pad.axes[0] ?? 0)
  const ly = dead(pad.axes[1] ?? 0)
  const ry = dead(pad.axes[3] ?? 0)
  if (lx || ly) orbit(-lx * dt * 1.6, ly * dt * 1.2)
  if (ry) zoom(1 + ry * dt * 1.2)
  const b = pad.buttons.map(x => x.pressed)
  const edge = (i: number) => b[i] && !padPrev[i]
  if (edge(0)) step(1)
  if (edge(2)) step(-1)
  if (edge(1)) goHome()
  if (edge(3)) { if (!irisAwake) void wakeIris(); else voice?.stopSpeaking() }
  padPrev = b
}

// ---------------- loop ----------------
const clock = new THREE.Clock()
let fpsFrames = 0
let fpsTime = 0
let perfChecked = false
let instrumentTimer = 0
let frameErrors = 0
let cardTimer = 0
function frame(): void {
  const dt = Math.min(0.1, clock.getDelta())
  const t = clock.elapsedTime
  try {
    flight.update(dt)
    gamepad(dt)
    // Near the ground the orbit target sits on the surface: allow a close camera and never let it sink below the land.
    const onGround = controls.target.length() > 9
    controls.minDistance = onGround ? 0.45 : 4
    controls.update()
    const minR = 10.18
    if (camera.position.length() < minR) camera.position.setLength(minR)
    camera.userData.lookAt = controls.target
    voice?.update(dt, t)
    const speaking = voice?.state === 'speaking'
    const level = Math.min(1, (voice?.speechLevel ?? 0) + (voice?.micLevel ?? 0) * 1.4)
    orb.update(dt, t, level, voice?.spectrum ?? emptySpectrum, speaking ? 1 : 0)
    orb.group.lookAt(camera.position)
    if (world) {
      world.update(dt, t, camera, new Date(), toggles.reducedMotion)
      ladder.set(world.tier)
      cardTimer += dt
      if (cardTimer > 5) { cardTimer = 0; if (shown?.kind === 'feed') refreshCard() }
      instrumentTimer += dt
      if (instrumentTimer > 30) {
        instrumentTimer = 0
        for (const k of FEED_KEYS) world.renderInstrument(k, feeds.status.get(k), feeds.values, Date.now())
      }
    }
    renderer.render(scene, camera)
  } catch (err) {
    if (frameErrors++ < 5) console.error('frame error (recovered)', err)
  }
  // Twain² condition: drop bloom if the device cannot hold 30 fps once the world is up.
  if (world && !perfChecked) {
    fpsFrames++
    fpsTime += dt
    if (fpsTime > 4) {
      perfChecked = true
      if (fpsFrames / fpsTime < 30 && quality === 'high') renderer.applyQuality('medium')
    }
  }
}
renderer.gl.setAnimationLoop(frame)
document.addEventListener('visibilitychange', () => { if (!document.hidden) clock.getDelta() })

boot().catch(err => {
  console.error(err)
  overlay.fail(err instanceof Error ? err.message : 'Unknown error')
})

declare global { interface Window { __world: unknown } }
window.__world = {
  get ready() { return !!world },
  get mode() { return mode },
  get sector() { return world?.sector },
  get integrity() { return integrity.map(m => ({ module: m.module, state: m.state })) },
  get feeds() { return [...feeds.status.values()].map(s => ({ key: s.key, state: s.state })) },
  get discovered() { return [...discovered] },
  get camera() { return camera.position.toArray() },
  get flying() { return flight.active },
  get irisAwake() { return irisAwake },
  ask: (text: string) => {
    if (!brain) return undefined
    overlay.visitor(text)
    const reply = brain.respond(text)
    void irisSays(reply)
    return reply
  },
  goTo,
  pickables: () => world?.pickables.length ?? 0,
  pick: (x: number, y: number) => pickAt(x, y),
  get tier() { return world?.tier ?? null },
  get card() { const m = card.current; return m ? { id: m.id, title: m.title, open: card.isOpen } : null },
  get selected() { return world?.geo.selected?.name ?? null },
  ladder: (t: Tier) => ladder.onTier?.(t),
}
