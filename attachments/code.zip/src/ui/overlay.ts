// DOM layer. Default experience shows no Iris text: only the entry gate (consent), an icon dock,
// and opt-in panels (Atlas, Transcript). A visually hidden live region mirrors Iris for screen readers.
export type EntryMode = 'talk' | 'listen' | 'read'
export interface Toggles { sound: boolean; haptics: boolean; reducedMotion: boolean; transcript: boolean }
export interface AtlasItem { id: string; group: string; label: string }

const ICONS: Record<string, string> = {
  mic: '<path d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  sound: '<path d="M4 10v4h4l5 4V6L8 10H4Z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  haptics: '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M3 8v8M21 8v8"/>',
  motion: '<circle cx="12" cy="12" r="3"/><path d="M3 12h3M18 12h3M12 3v3M12 18v3"/>',
  transcript: '<path d="M4 5h16v11H8l-4 4V5Z"/><path d="M8 9h8M8 12h5"/>',
  atlas: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  home: '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/>',
}
const svg = (k: string): string => `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[k]}</svg>`

export class Overlay {
  readonly root: HTMLElement
  onEnter: ((mode: EntryMode) => void) | null = null
  onToggle: ((key: keyof Toggles | 'mic', value: boolean) => void) | null = null
  onAtlas: ((id: string) => void) | null = null
  onHome: (() => void) | null = null
  onAsk: ((text: string) => void) | null = null
  onUnityId: ((action: 'create' | 'forget') => void) | null = null
  private live: HTMLElement
  private gate: HTMLElement
  private dock: HTMLElement
  private atlas: HTMLElement
  private transcript: HTMLElement
  private log: HTMLElement
  private chip: HTMLElement

  constructor(host: HTMLElement, private toggles: Toggles, speechAvailable: boolean) {
    this.root = host
    host.innerHTML = `
      <div class="gate is-loading" role="dialog" aria-modal="true" aria-labelledby="gate-title">
        <div class="gate-card">
          <h1 id="gate-title">DCCP World</h1>
          <p class="lede">The Unity playground, mirrored as a world. Explore it, and ask Iris about Unity.</p>
          <p class="loading" aria-live="polite">Loading the world…</p>
          <div class="choices">
            <button data-enter="talk" ${speechAvailable ? '' : 'disabled aria-describedby="nospeech"'}><strong>Talk with Iris</strong><span>Voice in, voice out. Uses your microphone.</span></button>
            <button data-enter="listen"><strong>Listen only</strong><span>Iris speaks; you touch and use the keyboard.</span></button>
            <button data-enter="read"><strong>Read with transcript</strong><span>No microphone. Iris's words appear as text and you can type.</span></button>
          </div>
          ${speechAvailable ? '' : '<p id="nospeech" class="note warn">Speech recognition is not available in this browser, so talking is off. Listen-only and transcript modes work fully.</p>'}
          <details class="disclose"><summary>Privacy, sound and limits</summary>
            <p>Talking sends your voice to your browser's own speech service (in Chrome, Google) to turn it into words. This world does not record, store or send what you say anywhere else. The microphone opens only after you choose Talk, and the mic button closes it.</p>
            <p>Sound, haptics and motion start only after you choose, and each has its own off switch in the dock. Your system's reduced-motion setting is respected.</p>
            <p>Live feeds refresh on a best-effort basis while this tab stays open; browsers may pause background tabs. Sector grades are pilot research, not live data. Nothing here moves coin or changes any domain.</p>
          </details>
          <p class="error" hidden></p>
        </div>
      </div>
      <nav class="dock" aria-label="World controls" hidden>
        <button data-t="mic" aria-pressed="false" aria-label="Microphone" title="Microphone (M)">${svg('mic')}</button>
        <button data-t="sound" aria-pressed="false" aria-label="Ambient music" title="Ambient music (Iris speaks either way)">${svg('sound')}</button>
        <button data-t="haptics" aria-pressed="false" aria-label="Haptics" title="Haptics">${svg('haptics')}</button>
        <button data-t="reducedMotion" aria-pressed="false" aria-label="Reduce motion" title="Reduce motion">${svg('motion')}</button>
        <button data-t="transcript" aria-pressed="false" aria-label="Transcript" title="Transcript (T)">${svg('transcript')}</button>
        <button data-p="atlas" aria-expanded="false" aria-label="Atlas of every place" title="Atlas (A)">${svg('atlas')}</button>
        <button data-p="home" aria-label="Home view" title="Home (H)">${svg('home')}</button>
      </nav>
      <button class="chip" hidden></button>
      <section class="panel atlas" aria-label="Atlas" hidden>
        <header><h2>Atlas</h2><button class="close" aria-label="Close atlas">×</button></header>
        <p class="hint">Every place in the world. Choose one to fly there and hear Iris. Keys: arrows orbit, + and − zoom, N and P step through places, Space pauses a flight, H goes home.</p>
        <div class="atlas-list"></div>
        <div class="unity-id"></div>
      </section>
      <section class="panel transcript" aria-label="Transcript" hidden>
        <header><h2>Transcript</h2><button class="close" aria-label="Close transcript">×</button></header>
        <div class="log" role="log" aria-live="off"></div>
        <form class="ask"><label class="sr" for="ask-input">Ask Iris</label><input id="ask-input" autocomplete="off" placeholder="Ask Iris about Unity…" /><button type="submit">Ask</button></form>
      </section>
      <div class="sr" aria-live="polite" role="status"></div>`
    this.gate = host.querySelector('.gate')!
    this.dock = host.querySelector('.dock')!
    this.atlas = host.querySelector('.atlas')!
    this.transcript = host.querySelector('.transcript')!
    this.log = host.querySelector('.log')!
    this.live = host.querySelector('[role="status"]')!
    this.chip = host.querySelector('.chip')!
    host.querySelectorAll<HTMLButtonElement>('[data-enter]').forEach(b => b.addEventListener('click', () => this.onEnter?.(b.dataset.enter as EntryMode)))
    host.querySelectorAll<HTMLButtonElement>('[data-t]').forEach(b => b.addEventListener('click', () => {
      const k = b.dataset.t as keyof Toggles | 'mic'
      const next = b.getAttribute('aria-pressed') !== 'true'
      if (k !== 'mic') this.setToggle(k, next)
      this.onToggle?.(k, next)
    }))
    host.querySelector('[data-p="atlas"]')!.addEventListener('click', () => this.togglePanel('atlas'))
    host.querySelector('[data-p="home"]')!.addEventListener('click', () => this.onHome?.())
    host.querySelectorAll('.panel .close').forEach(b => b.addEventListener('click', e => {
      const panel = (e.currentTarget as HTMLElement).closest('.panel') as HTMLElement
      if (panel.classList.contains('transcript')) { this.setToggle('transcript', false); this.onToggle?.('transcript', false) } else this.togglePanel('atlas', false)
    }))
    host.querySelector('.ask')!.addEventListener('submit', e => {
      e.preventDefault()
      const input = host.querySelector<HTMLInputElement>('#ask-input')!
      const text = input.value.trim()
      if (text) { this.onAsk?.(text); input.value = '' }
    })
    this.chip.addEventListener('click', () => { this.chip.hidden = true; this.togglePanel('atlas', true) })
    for (const [k, v] of Object.entries(toggles)) this.setToggle(k as keyof Toggles, v)
  }

  ready(): void {
    this.gate.classList.remove('is-loading')
    this.gate.querySelector<HTMLButtonElement>('[data-enter]:not([disabled])')?.focus()
  }

  fail(message: string): void {
    const e = this.gate.querySelector<HTMLElement>('.error')!
    e.hidden = false
    e.textContent = message
    this.gate.querySelector<HTMLElement>('.loading')!.textContent = 'The world could not finish loading.'
  }

  enter(): void {
    this.gate.hidden = true
    this.dock.hidden = false
  }

  setToggle(k: keyof Toggles, v: boolean): void {
    this.toggles[k] = v
    this.dock.querySelector(`[data-t="${k}"]`)?.setAttribute('aria-pressed', String(v))
    if (k === 'transcript') this.transcript.hidden = !v
  }

  setMic(on: boolean): void {
    this.dock.querySelector('[data-t="mic"]')?.setAttribute('aria-pressed', String(on))
  }

  togglePanel(_which: 'atlas', force?: boolean): void {
    const show = force ?? this.atlas.hidden
    this.atlas.hidden = !show
    this.dock.querySelector('[data-p="atlas"]')?.setAttribute('aria-expanded', String(show))
    if (show) this.atlas.querySelector<HTMLButtonElement>('.atlas-list button')?.focus()
  }

  setAtlas(items: AtlasItem[]): void {
    const groups = new Map<string, AtlasItem[]>()
    for (const it of items) groups.set(it.group, [...(groups.get(it.group) ?? []), it])
    const list = this.atlas.querySelector('.atlas-list')!
    list.innerHTML = [...groups].map(([g, its]) => `<h3>${g}</h3><ul>${its.map(i => `<li><button data-id="${i.id}">${escapeHtml(i.label)}</button></li>`).join('')}</ul>`).join('')
    list.querySelectorAll<HTMLButtonElement>('button[data-id]').forEach(b => b.addEventListener('click', () => this.onAtlas?.(b.dataset.id!)))
  }

  setUnityId(handle: string | null, disclose: string): void {
    const box = this.atlas.querySelector('.unity-id')!
    box.innerHTML = handle
      ? `<h3>Your pilot Unity handle</h3><p class="handle">${escapeHtml(handle)}</p><p class="note">Pilot handle · made on this device from your passkey · not issued by the Unity Network · issuer and shape await David (CONSULT-0003/0004).</p><button data-u="forget">Forget it on this device</button>`
      : `<h3>Pilot Unity handle</h3><p class="note">${escapeHtml(disclose)}</p><button data-u="create">I understand — create a pilot handle</button>`
    box.querySelector<HTMLButtonElement>('[data-u]')?.addEventListener('click', e => this.onUnityId?.((e.currentTarget as HTMLElement).dataset.u as 'create' | 'forget'))
  }

  /** Mirror Iris for assistive tech; append to the transcript (visible only if opted in). */
  iris(text: string): void {
    this.live.textContent = ''
    requestAnimationFrame(() => { this.live.textContent = text })
    this.append('Iris', text)
  }

  visitor(text: string): void {
    this.append('You', text)
  }

  announce(text: string): void {
    this.live.textContent = ''
    requestAnimationFrame(() => { this.live.textContent = text })
  }

  private append(who: string, text: string): void {
    const p = document.createElement('p')
    p.className = who === 'Iris' ? 'iris' : 'you'
    p.innerHTML = `<b>${who}</b> ${escapeHtml(text)}`
    this.log.append(p)
    while (this.log.children.length > 120) this.log.firstElementChild?.remove()
    this.log.scrollTop = this.log.scrollHeight
  }

  /** Twain² condition: an explicit, visible fallback when speech fails. */
  speechUnavailable(): void {
    this.chip.hidden = false
    this.chip.textContent = 'Microphone or speech unavailable — tap to navigate with the Atlas'
  }
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!)
}
