// One storyboard for every genre: Macro (what it is, plain words) → Logic (how it works) → Physics (the evidence, numbers live here).
import type { City, Country, Grade, ModuleIntegrity, Registry } from '../data/types'
import type { FeedStatus, FeedValues } from '../live/feeds'
import { placeWeather, weatherLine, type PlaceWeather } from '../live/place'
import type { Target } from '../iris/brain'
import { arcDeg } from '../world/geo'
import type { CardItem, CardModel, Tone } from './card'

export interface CardCtx {
  reg: Registry
  integrity: ModuleIntegrity[]
  feeds: { values: FeedValues; status: Map<keyof FeedValues, FeedStatus> }
  discovered: Set<string>
  describe: (t: Target) => string
  /** Called when asynchronous data (weather) for the shown card arrives. */
  onLate: () => void
}

const GRADE_WORD: Record<Grade, string> = { 'AT BENCHMARK': 'At benchmark', NEAR: 'Near', GAPPED: 'Gapped', THIN: 'Thin', UNGRADED: 'Not graded' }
const GRADE_SCORE: Record<Grade, number> = { 'AT BENCHMARK': 4, NEAR: 3, GAPPED: 2, THIN: 1, UNGRADED: 0 }

const sentence = (s: string): string => { const t = s.trim(); return !t || /[.!?…"”)]$/.test(t) ? t : `${t}.` }
const firstSentence = (s: string): string => { const m = s.match(/^.*?[.!?](\s|$)/); return sentence(m ? m[0] : s) }
const ago = (ms: number | null): string => {
  if (!ms) return 'no reading yet'
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000))
  return s < 90 ? `${s} seconds ago` : s < 5400 ? `${Math.round(s / 60)} minutes ago` : `${Math.round(s / 3600)} hours ago`
}
export function bigNumber(n: number): string {
  if (!n) return 'not recorded'
  if (n >= 1e12) return `${(n / 1e12).toFixed(1).replace(/\.0$/, '')} trillion`
  if (n >= 1e9) return `${(n / 1e9).toFixed(1).replace(/\.0$/, '')} billion`
  if (n >= 1e6) return `${Math.round(n / 1e6)} million`
  if (n >= 1e3) return `${Math.round(n / 1e3)} thousand`
  return String(n)
}
const statusTone = (status: string): { label: string; tone: Tone } => {
  const s = status.toUpperCase()
  if (s.startsWith('APPROVED')) return { label: 'Approved', tone: 'verified' }
  if (s.startsWith('LANDED') || s.startsWith('LIVE')) return { label: 'Landed', tone: 'pilot' }
  if (s.startsWith('DRAFT')) return { label: 'Draft', tone: 'mock' }
  if (s.includes('PILOT')) return { label: 'Pilot', tone: 'pilot' }
  return { label: 'Design', tone: 'design' }
}

function quakesNear(v: FeedValues, test: (lat: number, lon: number) => boolean): { n: number; strongest?: number } {
  const items = v.quakes?.items ?? []
  let n = 0, strongest: number | undefined
  for (const q of items) if (test(q.lat, q.lon)) { n++; strongest = Math.max(strongest ?? -9, q.mag) }
  return { n, strongest }
}

function capitalOf(reg: Registry, a3: string): City | undefined {
  return reg.cities.cities.find(c => c.a3 === a3 && c.capital) ?? reg.cities.cities.filter(c => c.a3 === a3).sort((a, b) => b.pop - a.pop)[0]
}

function weatherFor(lat: number, lon: number, ctx: CardCtx): PlaceWeather | null | undefined {
  return placeWeather(lat, lon, () => ctx.onLate())
}

export function countryCard(c: Country, ctx: CardCtx, inCountry: (c: Country, lat: number, lon: number) => boolean): CardModel {
  const { reg } = ctx
  const cap = capitalOf(reg, c.a3)
  const w = cap ? weatherFor(cap.lat, cap.lon, ctx) : null
  const graded = reg.jurisdictions.find(j => j.name.toLowerCase() === c.name.toLowerCase())
  const cities = reg.cities.cities.filter(x => x.a3 === c.a3).sort((a, b) => b.pop - a.pop)
  const q = quakesNear(ctx.feeds.values, (lat, lon) => inCountry(c, lat, lon))
  const quakeWord = q.n === 0 ? 'None in the last day' : q.n === 1 ? 'One in the last day' : `${q.n} in the last day`
  const live = w ? { label: 'Live weather', tone: 'live' as Tone } : { label: 'Reference map', tone: 'verified' as Tone }
  const macro: CardItem[] = [
    { label: 'Region', value: c.subregion || c.continent },
    { label: cap?.capital ? 'Capital' : 'Largest city', value: cap?.name ?? 'Not in the map' },
    { label: cap ? `Weather in ${cap.name}` : 'Weather', value: cap ? weatherLine(w) : 'No city to check' },
    { label: 'Earthquakes', value: quakeWord },
  ]
  if (graded) macro.push({ label: 'Sector research', value: `${Object.keys(graded.grades).length} sector layers`, wide: true })
  return {
    id: `country:${c.a3}`, level: 2, path: ['Earth', c.continent, c.name], title: c.name, subtitle: c.subregion || c.continent,
    badge: live,
    layers: [
      { key: 'macro', lead: `${c.name} sits in ${c.subregion || c.continent}.${cap ? ` ${sentence(`${cap.capital ? 'Its capital is' : 'Its largest city is'} ${cap.name}`)}` : ''} Go lower to see its cities.`, items: macro, source: 'Natural Earth · Open-Meteo · USGS' },
      {
        key: 'logic', lead: 'Borders and cities come from Natural Earth, a public world map. Weather is fetched live for the capital. Earthquakes come from the US Geological Survey feed for the past day.',
        items: [
          ...(graded ? Object.entries(graded.grades).map(([k, g]) => ({ label: reg.sectors.find(s => s.key === k)?.name ?? k, value: GRADE_WORD[g.grade] })) : []),
          { label: 'Map', value: 'Natural Earth borders', wide: !graded },
        ],
        source: reg.countries.source,
      },
      {
        key: 'physics', lead: `The measurable picture of ${c.name}.`,
        items: [
          { label: `People (${c.popYear || 'year n/a'})`, value: bigNumber(c.pop) },
          { label: `Economy (${c.gdpYear || 'year n/a'})`, value: c.gdpMd ? `$${bigNumber(c.gdpMd * 1e6)}` : 'not recorded' },
          { label: 'Cities in the map', value: String(cities.length) },
          { label: 'Strongest quake, 24 h', value: q.strongest !== undefined ? `M ${q.strongest.toFixed(1)}` : '—' },
          ...(w ? [{ label: 'Wind at the capital', value: `${Math.round(w.windKmh)} km/h` }, { label: 'Weather checked', value: ago(w.at) }] : []),
        ],
        bars: cities.length > 1 ? { title: 'Largest cities · metro population', rows: cities.slice(0, 5).map(x => ({ label: x.name, value: x.pop, display: bigNumber(x.pop) })) } : undefined,
        boundary: 'Population and economy are Natural Earth estimates from the year shown, not live counts. This map is a model of the world, not a live digital twin.',
        source: 'Natural Earth 1:50m · Open-Meteo · USGS',
      },
    ],
    actions: [{ id: 'ask', label: 'Ask Iris', primary: true }, { id: 'lower', label: 'Go to its cities' }],
  }
}

export function cityCard(city: City, country: Country | undefined, ctx: CardCtx): CardModel {
  const w = weatherFor(city.lat, city.lon, ctx)
  const q = quakesNear(ctx.feeds.values, (lat, lon) => arcDeg(lat, lon, city.lat, city.lon) < 3)
  const others = ctx.reg.cities.cities.filter(x => x.a3 === city.a3 && x !== city).sort((a, b) => arcDeg(city.lat, city.lon, a.lat, a.lon) - arcDeg(city.lat, city.lon, b.lat, b.lon)).slice(0, 3)
  return {
    id: `city:${city.a3}:${city.name}`, level: 3, path: ['Earth', country?.name ?? city.a3, city.name], title: city.name,
    subtitle: city.capital ? `Capital · ${country?.name ?? ''}` : city.region || country?.name,
    badge: w ? { label: 'Live weather', tone: 'live' } : { label: 'Reference map', tone: 'verified' },
    layers: [
      {
        key: 'macro', lead: `${city.name} is ${city.capital ? 'the capital of' : 'a city in'} ${country?.name ?? 'this country'}. Go to street level to stand in it.`,
        items: [
          { label: 'Weather now', value: weatherLine(w) },
          { label: 'Earthquakes nearby', value: q.n === 0 ? 'None in the last day' : `${q.n} in the last day` },
          { label: 'Neighbours', value: others.map(o => o.name).join(', ') || '—', wide: true },
        ],
        source: 'Natural Earth · Open-Meteo · USGS',
      },
      {
        key: 'logic', lead: 'The civic layer holds cities and municipalities. Weather is fetched live for this exact spot. Municipal services and civic records are not connected yet.',
        items: [{ label: 'Civic data', value: 'Not connected yet', wide: true }],
        boundary: 'No municipal, civic or personal data is loaded for this city. Street level shows the place, not the people.',
        source: ctx.reg.cities.source,
      },
      {
        key: 'physics', lead: `The measurable picture of ${city.name}.`,
        items: [
          { label: 'Metro population', value: bigNumber(city.pop) },
          { label: 'Position', value: `${city.lat.toFixed(2)}°, ${city.lon.toFixed(2)}°` },
          ...(w ? [{ label: 'Wind', value: `${Math.round(w.windKmh)} km/h` }, { label: 'Checked', value: ago(w.at) }] : []),
          { label: 'Strongest quake within 300 km', value: q.strongest !== undefined ? `M ${q.strongest.toFixed(1)}` : '—' },
        ],
        boundary: 'Population is a Natural Earth metro estimate, not a census count.',
        source: 'Natural Earth 1:50m · Open-Meteo · USGS',
      },
    ],
    actions: [{ id: 'ask', label: 'Ask Iris', primary: true }, { id: 'street', label: 'Street level' }],
  }
}

export function cardFor(t: Target, ctx: CardCtx): CardModel | null {
  const { reg, integrity, feeds, discovered } = ctx
  const ask = { id: 'ask', label: 'Ask Iris', primary: true }
  switch (t.kind) {
    case 'jurisdiction': {
      const j = reg.jurisdictions.find(x => x.name === t.key)
      if (!j) return null
      const g = Object.entries(j.grades)
      const best = g.filter(([, v]) => v.grade === 'AT BENCHMARK').map(([k]) => reg.sectors.find(s => s.key === k)?.name ?? k)
      return {
        id: `jur:${j.name}`, level: 2, path: ['Earth', 'Sector research', j.name], title: j.name, subtitle: 'Sector country model',
        badge: { label: 'Pilot research', tone: 'pilot' },
        layers: [
          { key: 'macro', lead: best.length ? `${j.name} leads the benchmark in ${best.join(' and ')}.` : `How ${j.name} compares with the best in each sector.`, items: g.map(([k, v]) => ({ label: reg.sectors.find(s => s.key === k)?.name ?? k, value: GRADE_WORD[v.grade] })), source: 'Unity Framework · sector country models' },
          { key: 'logic', lead: 'Each sector picks a benchmark country. Every other country is graded against it: at benchmark, near, gapped or thin.', items: g.map(([k, v]) => ({ label: reg.sectors.find(s => s.key === k)?.name ?? k, value: sentence(v.fact), wide: true })), source: 'Unity Framework · sector country models' },
          { key: 'physics', lead: 'Grades on one scale.', bars: { title: 'Grade by sector', rows: g.map(([k, v]) => ({ label: reg.sectors.find(s => s.key === k)?.name ?? k, value: GRADE_SCORE[v.grade], display: GRADE_WORD[v.grade] })) }, boundary: `Pilot research from ${reg.sectors[0]?.researched ?? '2026'}. Modeled analysis, not a live feed.`, source: 'Unity Framework · sector country models' },
        ],
        actions: [ask, { id: 'country', label: 'See the country' }],
      }
    }
    case 'canada': {
      const c = reg.canada.find(x => x.key === t.key)
      if (!c) return null
      return {
        id: `canada:${c.key}`, level: 3, path: ['Earth', 'Canada', c.name], title: c.name, subtitle: 'Pan-Canadian scope',
        badge: { label: 'Specification', tone: 'design' },
        layers: [
          { key: 'macro', lead: `How the health runtime would connect in ${c.name}, without ever holding patient data.`, items: [{ label: 'Systems', value: c.systems, wide: true }], source: 'SIMA-DCLM RTE specification' },
          { key: 'logic', lead: 'The runtime reads through each portal’s own rules and keeps nothing.', items: [{ label: 'Guard', value: c.guard, wide: true }], boundary: 'Invariant: no personal health information is ingested, logged or retained.', source: 'SIMA-DCLM RTE specification' },
        ],
        actions: [ask],
      }
    }
    case 'rte': {
      const r = reg.rtes.find(x => x.key === t.key)
      if (!r) return null
      return {
        id: `rte:${r.key}`, level: 3, path: ['Universal RTE', r.name], title: r.name, subtitle: r.kind === 'suite' ? 'RTE room' : r.kind === 'unity' ? 'Unity RTE' : 'RTE specification',
        badge: statusTone(r.status),
        layers: [
          { key: 'macro', lead: firstSentence(r.job || r.about), items: [{ label: 'Status', value: statusTone(r.status).label }, { label: 'Kind', value: r.kind === 'suite' ? 'Room in the suite' : r.kind === 'unity' ? 'Unity runtime' : 'Specification' }], source: 'RTE suite' },
          { key: 'logic', lead: sentence(r.about || r.job), source: 'RTE suite' },
          ...(r.facts.length ? [{ key: 'physics' as const, lead: 'What the record holds.', items: r.facts.map((f, i) => ({ label: `Fact ${i + 1}`, value: sentence(f), wide: true })), boundary: `Recorded status: ${r.status}.`, source: 'RTE suite manifest' }] : []),
        ],
        actions: [ask],
      }
    }
    case 'chamber': {
      const c = reg.chambers.find(x => x.key === t.key)
      if (!c) return null
      return {
        id: `chamber:${c.key}`, level: 2, path: ['Unity playground', c.title], title: c.title, subtitle: 'Unity Framework chamber',
        badge: discovered.has(c.key) ? { label: 'Discovered', tone: 'verified' } : statusTone(c.status),
        layers: [
          { key: 'macro', lead: sentence(c.headline), items: c.summary.slice(0, 2).map((s, i) => ({ label: i ? 'And' : 'In short', value: sentence(s), wide: true })), source: c.source },
          { key: 'logic', lead: c.quotes[0] ? `“${c.quotes[0].text}”` : 'This chamber’s reasoning is in the framework.', items: c.quotes.slice(1, 3).map(q => ({ label: q.who, value: `“${q.text}”`, wide: true })), source: c.source },
          { key: 'physics', lead: 'The record behind this chamber.', items: [{ label: 'Status', value: c.status }, { label: 'Cards in the chamber', value: String(c.cards) }, { label: 'Source', value: c.source, wide: true }], source: c.source },
        ],
        actions: [ask],
      }
    }
    case 'sector': {
      if (t.key === 'pharmacology') {
        const p = reg.pharmacology
        return {
          id: 'sector:pharmacology', level: 1, path: ['Sector layers', 'Pharmacology'], title: 'Pharmacology', subtitle: 'Sector layer',
          badge: { label: 'Design', tone: 'design' },
          layers: [
            { key: 'macro', lead: 'Medicines, from discovery to the pharmacy shelf. Mapped, not yet graded.', items: [{ label: 'State', value: 'Design stage' }, { label: 'Data estates', value: 'Named, not researched' }], source: p.source },
            { key: 'logic', lead: sentence(p.arc), items: p.estates.map(e => ({ label: e.name, value: e.note, wide: true })), boundary: 'No grades are assigned, because the estate research has not been done.', source: p.source },
          ],
          actions: [ask],
        }
      }
      const s = reg.sectors.find(x => x.key === t.key)
      if (!s) return null
      const order: Grade[] = ['AT BENCHMARK', 'NEAR', 'GAPPED', 'THIN']
      return {
        id: `sector:${s.key}`, level: 1, path: ['Sector layers', s.name], title: s.name, subtitle: 'Sector layer',
        badge: { label: 'Pilot research', tone: 'pilot' },
        layers: [
          { key: 'macro', lead: sentence(s.headline), items: [{ label: 'Benchmark', value: s.benchmark }, { label: 'Scope', value: s.scope }], source: s.source },
          { key: 'logic', lead: `Every country is compared with ${s.benchmark}. Tap a pillar on the globe to see one country’s grade.`, items: s.rows.slice(0, 6).map(r => ({ label: r.jurisdiction, value: GRADE_WORD[r.grade] })), source: s.source },
          { key: 'physics', lead: 'How the graded countries spread.', bars: { title: 'Countries per grade', rows: order.map(g => ({ label: GRADE_WORD[g], value: s.counts[g] ?? 0, display: String(s.counts[g] ?? 0) })) }, boundary: `Pilot research from ${s.researched}. ${s.state}`, source: s.source },
        ],
        actions: [ask],
      }
    }
    case 'estates': return cardFor({ kind: 'sector', key: 'pharmacology' }, ctx)
    case 'dclm': {
      const locked = integrity.filter(m => m.state === 'MATCH').length
      const all = integrity.length
      return {
        id: 'dclm', level: 1, path: ['DCLM'], title: 'The DCLM', subtitle: 'Deterministic Compute Logic Machine',
        badge: locked === all ? { label: 'All data checked', tone: 'verified' } : { label: 'Check failed', tone: 'offline' },
        layers: [
          { key: 'macro', lead: 'The deterministic machine. It double-checks every piece of data this world loads, so nothing changes without being noticed.', items: [{ label: 'Data checked', value: locked === all ? 'Everything' : `${locked} of ${all}` }, { label: 'Way it checks', value: 'Twice, in lockstep' }], source: 'DCLM API v2' },
          { key: 'logic', lead: 'Each data file was sent to the DCLM twice. Both receipts had to agree. Your browser then re-fingerprints each file before using it, and refuses any file that does not match.', boundary: 'This is a client-side integrity check, not a seal or an approval.', source: 'DCLM API v2 · public/dclm-receipts.json' },
          { key: 'physics', lead: 'Per-module receipts (engineering view).', items: integrity.map(m => ({ label: m.module, value: `${m.state}${m.receipt ? ` · seq ${m.receipt.receipts.map(r => r.sequence).join('/')}` : ''}` })), source: 'DCLM receipts' },
        ],
        actions: [ask],
      }
    }
    case 'pipe': return {
      id: `pipe:${t.key}`, level: 2, path: ['DCCP pipe', t.key], title: `DCCP pipe`, subtitle: `Stage · ${t.key}`,
      badge: { label: 'Design', tone: 'design' },
      layers: [
        { key: 'macro', lead: 'Where releases will travel: proposed, voted on, finalized, then stored on IPFS and pointed to by IPNS.', items: [{ label: 'You are at', value: t.key[0].toUpperCase() + t.key.slice(1) }], source: 'DCCP design' },
        { key: 'logic', lead: 'A release becomes final only when the coin-controlled quorum agrees. Only then is it pinned and the public pointer moved.', boundary: 'Design only. Not deployed on any chain, and no coin moves through it.', source: 'DCCP authority registry design' },
      ],
      actions: [ask],
    }
    case 'universal': return {
      id: 'universal', level: 1, path: ['Universal RTE'], title: 'Universal RTE', subtitle: 'The root runtime',
      badge: { label: 'Doctrine', tone: 'design' },
      layers: [
        { key: 'macro', lead: sentence(reg.doctrine.universal_rte ?? 'The root runtime every RTE grows from.'), items: [{ label: 'Rule', value: 'One RTE per Unity ID' }, { label: 'Rooms below', value: 'Every planned RTE' }], source: 'Unity Framework doctrine' },
      ],
      actions: [ask],
    }
    case 'feed': {
      const st = feeds.status.get(t.key as keyof FeedValues)
      if (!st) return null
      const tone: Tone = st.state === 'LIVE' ? 'live' : st.state === 'STALE' ? 'stale' : st.state === 'UNAVAILABLE' ? 'offline' : 'pilot'
      return {
        id: `feed:${t.key}`, level: 1, path: ['Live feeds', st.title], title: st.title, subtitle: 'Live public feed',
        badge: { label: st.state === 'PENDING' ? 'Connecting' : st.state.toLowerCase().replace(/^./, c => c.toUpperCase()), tone },
        layers: [
          { key: 'macro', lead: ctx.describe(t), source: st.source },
          { key: 'logic', lead: 'Fetched straight from the public source on a timer. If it fails, the world keeps running and the badge tells you the reading is old.', items: [{ label: 'Source', value: st.source, wide: true }], source: st.source },
          { key: 'physics', lead: 'Feed health.', items: [{ label: 'Last good reading', value: ago(st.lastOk) }, { label: 'Failures in a row', value: String(st.failures) }, ...(st.lastError ? [{ label: 'Last error', value: st.lastError, wide: true }] : [])], source: st.source },
        ],
        actions: [ask],
      }
    }
    case 'earth': return {
      id: 'earth', level: 1, path: ['Earth'], title: 'Earth', subtitle: 'The overlook',
      badge: { label: 'Imagery of record', tone: 'verified' },
      layers: [
        { key: 'macro', lead: 'NASA Blue Marble by day and Black Marble by night, lit by where the sun is right now. Come closer and the borders appear. Tap a country.', source: 'NASA Visible Earth' },
      ],
    }
    default: return null
  }
}
