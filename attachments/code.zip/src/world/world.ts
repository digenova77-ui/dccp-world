import * as THREE from 'three'
import type { Font } from 'three/examples/jsm/loaders/FontLoader.js'
import type { Grade, ModuleIntegrity, Registry } from '../data/types'
import type { FeedStatus, FeedValues } from '../live/feeds'
import type { Target } from '../iris/brain'
import { text3D, textPlate } from './text3d'
import { GeoLayer, tierOf, type Tier } from './geo'

export const EARTH_R = 10
export const GRADE_COLOR: Record<Grade, number> = { 'AT BENCHMARK': 0xffd166, NEAR: 0x14b8a6, GAPPED: 0xf59e0b, THIN: 0xef4444, UNGRADED: 0x5b6b7a }
const GRADE_HEIGHT: Record<Grade, number> = { 'AT BENCHMARK': 2.6, NEAR: 1.9, GAPPED: 1.25, THIN: 0.7, UNGRADED: 0.25 }
export const SECTOR_COLOR: Record<string, number> = { water: 0x38bdf8, energy: 0xfacc15, climate: 0x34d399, food: 0xfb923c, pandemic: 0xf472b6, pharmacology: 0xa78bfa }
const STATUS_COLOR = (s: string): number => (s.startsWith('APPROVED') ? 0x22c55e : s.startsWith('DRAFT') ? 0xf59e0b : s.startsWith('LANDED') ? 0x14b8a6 : 0xa855f7)

export function latLonToVec(lat: number, lon: number, r: number, out = new THREE.Vector3()): THREE.Vector3 {
  const phi = THREE.MathUtils.degToRad(90 - lat)
  const theta = THREE.MathUtils.degToRad(lon + 180)
  return out.set(-r * Math.sin(phi) * Math.cos(theta), r * Math.cos(phi), r * Math.sin(phi) * Math.sin(theta))
}

/** Approximate subsolar point (declination + hour angle; equation of time ignored, ±4°). */
export function subsolar(date: Date): { lat: number; lon: number } {
  const start = Date.UTC(date.getUTCFullYear(), 0, 0)
  const doy = (date.getTime() - start) / 86_400_000
  const lat = -23.44 * Math.cos(((2 * Math.PI) / 365) * (doy + 10))
  const hours = date.getUTCHours() + date.getUTCMinutes() / 60 + date.getUTCSeconds() / 3600
  let lon = -(hours - 12) * 15
  if (lon < -180) lon += 360
  if (lon > 180) lon -= 360
  return { lat, lon }
}

export interface Focus { anchor: THREE.Vector3; camera: THREE.Vector3 }
interface Pickable { target: Target; object: THREE.Object3D; label: string; focus: () => Focus }

export class World {
  readonly root = new THREE.Group()
  readonly pickables: Pickable[] = []
  readonly sunDir = new THREE.Vector3(1, 0, 0)
  sector = 'water'
  private earthMat!: THREE.ShaderMaterial
  private pillars = new Map<string, THREE.Mesh>()
  private sectorTokens = new Map<string, THREE.Group>()
  private chambers = new Map<string, THREE.Group>()
  private estates = new THREE.Group()
  private quakes!: THREE.InstancedMesh
  private quakeData: { lat: number; lon: number; mag: number }[] = []
  private iss = new THREE.Group()
  private issTarget = new THREE.Vector3()
  private issTrail!: THREE.Line
  private issTrailPts: THREE.Vector3[] = []
  private dclmNodes: THREE.Mesh[] = []
  private dclmCore = new THREE.Group()
  private pipeMat!: THREE.ShaderMaterial
  private instruments = new Map<string, { group: THREE.Group; anchor: THREE.Vector3; facing: THREE.Vector3; plate?: THREE.Group; rendered: number }>()
  private detail?: THREE.Group
  private sunSprite!: THREE.Sprite
  private universalCore!: THREE.Mesh
  private tmp = new THREE.Vector3()
  private labels: THREE.Object3D[] | null = null
  private qa = new THREE.Quaternion()
  private qb = new THREE.Quaternion()
  private yAxis = new THREE.Vector3(0, 1, 0)
  private wp = new THREE.Vector3()
  private dummy = new THREE.Object3D()
  readonly geo: GeoLayer
  /** Kind of the place the visitor last chose; keeps its cluster unfolded at any altitude. */
  focusKind: string | null = null
  tier: Tier = 'orbit'
  private canadaRings: THREE.Mesh[] = []
  private marker!: THREE.Mesh
  private markerAt: THREE.Vector3 | null = null
  private labelSize = new Map<THREE.Object3D, number>()
  private box = new THREE.Box3()
  private sz = new THREE.Vector3()

  constructor(private font: Font, private reg: Registry, private integrity: ModuleIntegrity[], private textures: { day: THREE.Texture; night: THREE.Texture }, private quality: 'low' | 'medium' | 'high') {
    this.buildSky()
    this.buildEarth()
    this.buildPillars()
    this.buildCanada()
    this.buildSectorTokens()
    this.buildEstates()
    this.buildQuakes()
    this.buildIss()
    this.buildUnityRing()
    this.buildRteRoot()
    this.buildDclm()
    this.buildPipe()
    this.buildInstruments()
    this.geo = new GeoLayer(this.font, this.reg.countries.countries, this.reg.cities.cities)
    this.root.add(this.geo.group)
    this.marker = new THREE.Mesh(new THREE.RingGeometry(0.82, 1, 64), new THREE.MeshBasicMaterial({ color: 0xffd166, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false, toneMapped: false }))
    this.marker.visible = false
    this.root.add(this.marker)
    this.setSector('water')
  }

  private add(target: Target, object: THREE.Object3D, label: string, focus: () => Focus): void {
    object.traverse(o => { o.userData.pick = target })
    this.pickables.push({ target, object, label, focus })
  }

  findPickable(target: Target): Pickable | undefined {
    return this.pickables.find(p => p.target.kind === target.kind && p.target.key === target.key)
  }

  // ---------- sky ----------
  private buildSky(): void {
    const n = this.quality === 'low' ? 3500 : 8000
    const pos = new Float32Array(n * 3)
    const col = new Float32Array(n * 3)
    const c = new THREE.Color()
    let seed = 1234567
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647)
    for (let i = 0; i < n; i++) {
      const u = rnd() * 2 - 1
      const th = rnd() * Math.PI * 2
      const r = 420 + rnd() * 160
      const s = Math.sqrt(1 - u * u)
      // Concentrate a faint galactic band.
      const band = rnd() < 0.35 ? 0.18 : 1
      pos.set([r * s * Math.cos(th), r * u * band, r * s * Math.sin(th)], i * 3)
      c.setHSL(0.55 + rnd() * 0.15, 0.4, 0.6 + rnd() * 0.4)
      col.set([c.r, c.g, c.b], i * 3)
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    g.setAttribute('color', new THREE.BufferAttribute(col, 3))
    const stars = new THREE.Points(g, new THREE.PointsMaterial({ size: 1.6, sizeAttenuation: true, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false }))
    stars.rotation.z = 0.5
    this.root.add(stars)
    const cv = document.createElement('canvas')
    cv.width = cv.height = 128
    const x = cv.getContext('2d')!
    const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64)
    gr.addColorStop(0, 'rgba(255,250,230,1)')
    gr.addColorStop(0.2, 'rgba(255,220,150,0.8)')
    gr.addColorStop(1, 'rgba(255,180,80,0)')
    x.fillStyle = gr
    x.fillRect(0, 0, 128, 128)
    const tex = new THREE.CanvasTexture(cv)
    this.sunSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }))
    this.sunSprite.scale.setScalar(60)
    this.root.add(this.sunSprite)
    this.root.add(new THREE.AmbientLight(0x6b7f99, 0.55))
    const key = new THREE.DirectionalLight(0xfff1dc, 1.6)
    key.name = 'sun'
    this.root.add(key)
    const rim = new THREE.DirectionalLight(0x14b8a6, 0.5)
    rim.position.set(-30, 10, -20)
    this.root.add(rim)
  }

  // ---------- earth ----------
  private buildEarth(): void {
    const seg = this.quality === 'low' ? 64 : 128
    this.earthMat = new THREE.ShaderMaterial({
      uniforms: { uDay: { value: this.textures.day }, uNight: { value: this.textures.night }, uSun: { value: this.sunDir } },
      vertexShader: 'varying vec2 vUv; varying vec3 vN; varying vec3 vW; void main(){ vUv=uv; vN=normalize(mat3(modelMatrix)*normal); vec4 w=modelMatrix*vec4(position,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }',
      fragmentShader: /* glsl */ `
        uniform sampler2D uDay; uniform sampler2D uNight; uniform vec3 uSun;
        varying vec2 vUv; varying vec3 vN; varying vec3 vW;
        void main(){
          vec3 n = normalize(vN);
          float ndl = dot(n, normalize(uSun));
          vec3 day = texture2D(uDay, vUv).rgb;
          vec3 night = texture2D(uNight, vUv).rgb;
          float dayMix = smoothstep(-0.12, 0.18, ndl);
          vec3 lit = day * (0.08 + 1.15 * max(ndl, 0.0));
          vec3 lights = pow(night, vec3(1.6)) * vec3(1.6, 1.25, 0.85) * 1.8;
          vec3 col = mix(lights + day * 0.025, lit, dayMix);
          float ocean = smoothstep(0.05, 0.25, day.b - max(day.r, day.g));
          vec3 V = normalize(cameraPosition - vW);
          vec3 H = normalize(normalize(uSun) + V);
          col += ocean * pow(max(dot(n, H), 0.0), 60.0) * 0.6 * dayMix;
          float rim = pow(1.0 - max(dot(n, V), 0.0), 3.0);
          col += vec3(0.25, 0.55, 1.0) * rim * (0.25 + 0.6 * dayMix);
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`,
    })
    const earth = new THREE.Mesh(new THREE.SphereGeometry(EARTH_R, seg, seg / 2), this.earthMat)
    earth.name = 'earth'
    this.root.add(earth)
    const atmo = new THREE.Mesh(new THREE.SphereGeometry(EARTH_R * 1.035, 64, 32), new THREE.ShaderMaterial({
      uniforms: { uSun: { value: this.sunDir } },
      vertexShader: 'varying vec3 vN; varying vec3 vW; void main(){ vN=normalize(mat3(modelMatrix)*normal); vec4 w=modelMatrix*vec4(position,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }',
      fragmentShader: 'uniform vec3 uSun; varying vec3 vN; varying vec3 vW; void main(){ vec3 V=normalize(cameraPosition-vW); float f=pow(1.0-abs(dot(normalize(vN),V)),2.5); float d=smoothstep(-0.3,0.4,dot(normalize(vN),normalize(uSun))); gl_FragColor=vec4(vec3(0.3,0.6,1.0)*f*(0.25+d), f*0.8); }',
      transparent: true, side: THREE.BackSide, blending: THREE.AdditiveBlending, depthWrite: false,
    }))
    this.root.add(atmo)
    this.add({ kind: 'earth', key: 'home' }, earth, 'Earth — NASA imagery of record, lit by the current sun', () => this.homeFocus())
  }

  homeFocus(): Focus {
    return { anchor: new THREE.Vector3(0, -1, 0), camera: latLonToVec(28, -62, 1, new THREE.Vector3()).multiplyScalar(44).add(new THREE.Vector3(0, 4, 0)) }
  }

  private earthFocus(lat: number, lon: number, dist = 10): Focus {
    const anchor = latLonToVec(lat, lon, EARTH_R)
    const n = anchor.clone().normalize()
    return { anchor, camera: anchor.clone().add(n.multiplyScalar(dist)).add(new THREE.Vector3(0, 2, 0)) }
  }

  // ---------- jurisdictions ----------
  private buildPillars(): void {
    const geo = new THREE.CylinderGeometry(0.16, 0.22, 1, 12, 1)
    geo.translate(0, 0.5, 0)
    const cap = new THREE.SphereGeometry(0.24, 16, 8)
    for (const j of this.reg.jurisdictions) {
      const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.6, metalness: 0.3, roughness: 0.4 })
      const m = new THREE.Mesh(geo, mat)
      const capM = new THREE.Mesh(cap, mat)
      m.add(capM)
      const p = latLonToVec(j.lat, j.lon, EARTH_R)
      m.position.copy(p)
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p.clone().normalize())
      m.name = `pillar:${j.name}`
      this.root.add(m)
      this.pillars.set(j.name, m)
      this.add({ kind: 'jurisdiction', key: j.name }, m, `${j.name} — sector grades`, () => this.earthFocus(j.lat, j.lon, 9))
    }
  }

  private buildCanada(): void {
    const geo = new THREE.TorusGeometry(0.42, 0.07, 8, 32)
    for (const c of this.reg.canada) {
      const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0xff4d5e, emissive: 0xff4d5e, emissiveIntensity: 0.9 }))
      const p = latLonToVec(c.lat, c.lon, EARTH_R + 0.06)
      m.position.copy(p)
      m.lookAt(p.clone().multiplyScalar(2))
      m.name = `canada:${c.key}`
      this.root.add(m)
      this.canadaRings.push(m)
      this.add({ kind: 'canada', key: c.key }, m, `${c.name} — pan-Canadian clinical informatics scope`, () => this.earthFocus(c.lat, c.lon, 8))
    }
  }

  private buildSectorTokens(): void {
    const keys = ['water', 'energy', 'climate', 'food', 'pandemic', 'pharmacology']
    const names: Record<string, string> = { water: 'WATER', energy: 'ENERGY', climate: 'CLIMATE', food: 'FOOD', pandemic: 'PANDEMIC', pharmacology: 'PHARMA' }
    keys.forEach((k, i) => {
      const g = new THREE.Group()
      const a = THREE.MathUtils.degToRad(-50 + i * 20)
      g.position.set(Math.sin(a) * 15, 13.5 - Math.abs(i - 2.5) * 0.6, Math.cos(a) * 15)
      const shape = new THREE.Mesh(new THREE.TorusKnotGeometry(0.55, 0.16, 80, 10, 2, 3), new THREE.MeshStandardMaterial({ color: SECTOR_COLOR[k], emissive: SECTOR_COLOR[k], emissiveIntensity: 0.5, metalness: 0.6, roughness: 0.25 }))
      const label = text3D(this.font, names[k], { size: 0.42, color: 0xffffff, emissive: SECTOR_COLOR[k], emissiveIntensity: 0.6 })
      label.position.y = -1.25
      g.add(shape, label)
      g.lookAt(0, g.position.y, 0)
      g.rotateY(Math.PI)
      this.root.add(g)
      this.sectorTokens.set(k, g)
      this.add({ kind: 'sector', key: k }, g, `${names[k]} sector layer`, () => ({ anchor: new THREE.Vector3(0, 0, 0), camera: g.position.clone().multiplyScalar(2.4).setY(16) }))
    })
  }

  private buildEstates(): void {
    const est = this.reg.pharmacology.estates
    est.forEach((e, i) => {
      const a = (i / est.length) * Math.PI * 2
      const m = new THREE.Mesh(new THREE.OctahedronGeometry(0.35), new THREE.MeshStandardMaterial({ color: 0xa78bfa, emissive: 0xa78bfa, emissiveIntensity: 1.2 }))
      m.position.set(Math.cos(a) * 13.5, 6 + Math.sin(a * 2) * 1.2, Math.sin(a) * 13.5)
      m.name = `estate:${e.name}`
      this.estates.add(m)
    })
    this.estates.visible = false
    this.root.add(this.estates)
    this.add({ kind: 'estates', key: 'pharmacology' }, this.estates, 'Pharmacology data estates — design stage, ungraded', () => ({ anchor: new THREE.Vector3(0, 6, 0), camera: new THREE.Vector3(0, 22, 26) }))
  }

  setSector(key: string): void {
    this.sector = key
    for (const [k, g] of this.sectorTokens) {
      const on = k === key
      g.scale.setScalar(on ? 1.35 : 1)
      g.traverse(o => {
        const m = (o as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined
        if (m && 'emissiveIntensity' in m) m.emissiveIntensity = on ? 1.4 : 0.35
      })
    }
    this.estates.visible = key === 'pharmacology'
    for (const j of this.reg.jurisdictions) {
      const m = this.pillars.get(j.name)!
      const g: Grade = key === 'pharmacology' ? 'UNGRADED' : (j.grades[key]?.grade ?? 'UNGRADED')
      const mat = m.material as THREE.MeshStandardMaterial
      mat.color.setHex(GRADE_COLOR[g])
      mat.emissive.setHex(GRADE_COLOR[g])
      mat.emissiveIntensity = g === 'UNGRADED' ? 0.15 : 0.7
      m.userData.targetHeight = GRADE_HEIGHT[g]
    }
  }

  // ---------- live: quakes / ISS ----------
  private buildQuakes(): void {
    this.quakes = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 10, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, toneMapped: false }), 400)
    this.quakes.count = 0
    this.quakes.name = 'quakes'
    this.root.add(this.quakes)
    this.add({ kind: 'feed', key: 'quakes' }, this.quakes, 'Earthquakes M2.5+ past day — USGS', () => this.earthFocus(this.quakeData[0]?.lat ?? 35, this.quakeData[0]?.lon ?? 140, 16))
  }

  setQuakes(items: { lat: number; lon: number; mag: number }[]): void {
    this.quakeData = items.slice(0, 400)
    this.quakes.count = this.quakeData.length
    const c = new THREE.Color()
    this.quakeData.forEach((q, i) => {
      c.setHSL(Math.max(0, 0.14 - (q.mag - 2.5) * 0.035), 1, 0.55)
      this.quakes.setColorAt(i, c)
    })
    if (this.quakes.instanceColor) this.quakes.instanceColor.needsUpdate = true
  }

  private buildIss(): void {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.18, 0.18), new THREE.MeshStandardMaterial({ color: 0xdddddd, metalness: 0.8, roughness: 0.3 }))
    const panelMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, emissive: 0x2563eb, emissiveIntensity: 0.6, side: THREE.DoubleSide })
    const p1 = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.9), panelMat)
    p1.position.x = -0.32
    const p2 = p1.clone()
    p2.position.x = 0.32
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }))
    this.iss.add(body, p1, p2, beacon)
    this.iss.visible = false
    this.root.add(this.iss)
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(240 * 3), 3))
    g.setDrawRange(0, 0)
    this.issTrail = new THREE.Line(g, new THREE.LineBasicMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.6 }))
    this.root.add(this.issTrail)
    this.add({ kind: 'feed', key: 'iss' }, this.iss, 'International Space Station — live position, altitude exaggerated four times', () => {
      const a = this.iss.position.clone()
      return { anchor: a, camera: a.clone().normalize().multiplyScalar(EARTH_R + 9).add(new THREE.Vector3(0, 1.5, 0)) }
    })
  }

  setIss(lat: number, lon: number, altKm: number): void {
    const r = EARTH_R * (1 + (altKm / 6371) * 4)
    latLonToVec(lat, lon, r, this.issTarget)
    if (!this.iss.visible) { this.iss.position.copy(this.issTarget); this.iss.visible = true }
    this.issTrailPts.push(this.issTarget.clone())
    if (this.issTrailPts.length > 240) this.issTrailPts.shift()
    const pos = this.issTrail.geometry.getAttribute('position') as THREE.BufferAttribute
    this.issTrailPts.forEach((p, i) => pos.setXYZ(i, p.x, p.y, p.z))
    pos.needsUpdate = true
    this.issTrail.geometry.setDrawRange(0, this.issTrailPts.length)
  }

  // ---------- Unity ring ----------
  private buildUnityRing(): void {
    const R = 25
    const n = this.reg.chambers.length
    const ringGeo = new THREE.TorusGeometry(R, 0.05, 6, 240)
    const ring = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0x14b8a6, transparent: true, opacity: 0.45, toneMapped: false }))
    ring.rotation.x = Math.PI / 2
    this.root.add(ring)
    this.reg.chambers.forEach((c, i) => {
      const a = (i / n) * Math.PI * 2 + Math.PI / 2
      const g = new THREE.Group()
      g.position.set(Math.cos(a) * R, Math.sin(a * 3) * 0.6, Math.sin(a) * R)
      const edge = new THREE.MeshStandardMaterial({ color: 0x14b8a6, emissive: 0x14b8a6, emissiveIntensity: 0.8 })
      const glass = new THREE.MeshPhysicalMaterial({ color: 0x0c2230, metalness: 0.2, roughness: 0.08, clearcoat: 1, transparent: true, opacity: 0.78, emissive: 0x062a2a, emissiveIntensity: 0.6 })
      const mono = new THREE.Mesh(new THREE.BoxGeometry(2.1, 3.2, 0.3), [edge, edge, edge, edge, glass, glass])
      const frame = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.12, 0.42), edge)
      frame.position.y = -1.66
      const title = text3D(this.font, c.title.replace(/^The /, '').toUpperCase().slice(0, 22), { size: 0.3, emissive: 0x14b8a6, emissiveIntensity: 0.55 })
      title.position.y = 2.15
      const glyph = new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 0), new THREE.MeshStandardMaterial({ color: 0xe6fffb, emissive: c.status === 'LANDED' ? 0x14b8a6 : 0x8eb4c8, emissiveIntensity: 1.1, flatShading: true }))
      glyph.position.set(0, 0.2, 0.3)
      glyph.name = 'glyph'
      g.add(mono, frame, title, glyph)
      g.lookAt(0, g.position.y, 0)
      g.rotateY(Math.PI)
      g.userData.edge = edge
      this.root.add(g)
      this.chambers.set(c.key, g)
      this.add({ kind: 'chamber', key: c.key }, g, `Unity chamber: ${c.title} — ${c.headline}`, () => {
        const out = g.position.clone().setY(0).normalize()
        return { anchor: g.position.clone(), camera: g.position.clone().add(out.multiplyScalar(7.5)).add(new THREE.Vector3(0, 1.2, 0)) }
      })
    })
  }

  setDiscovered(keys: Set<string>): void {
    for (const [k, g] of this.chambers) {
      const on = keys.has(k)
      const edge = g.userData.edge as THREE.MeshStandardMaterial
      edge.color.setHex(on ? 0xffd166 : 0x14b8a6)
      edge.emissive.setHex(on ? 0xffd166 : 0x14b8a6)
      edge.emissiveIntensity = on ? 1.3 : 0.8
    }
  }

  // ---------- Universal RTE root ----------
  private buildRteRoot(): void {
    const Y = -21
    this.universalCore = new THREE.Mesh(new THREE.OctahedronGeometry(2.2, 0), new THREE.MeshPhysicalMaterial({ color: 0x5eead4, emissive: 0x14b8a6, emissiveIntensity: 0.9, metalness: 0.1, roughness: 0.05, clearcoat: 1, flatShading: true }))
    this.universalCore.scale.y = 1.8
    this.universalCore.position.set(0, Y, 0)
    this.root.add(this.universalCore)
    const label = text3D(this.font, 'UNIVERSAL RTE', { size: 0.95, emissive: 0x14b8a6, emissiveIntensity: 0.7 })
    label.position.set(0, Y + 5.4, 3)
    this.root.add(label)
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.5, Math.abs(Y) - EARTH_R, 12, 1, true), new THREE.MeshBasicMaterial({ color: 0x14b8a6, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }))
    beam.position.set(0, (Y - EARTH_R) / 2, 0)
    this.root.add(beam)
    const disk = new THREE.Mesh(new THREE.RingGeometry(9.5, 13.5, 96), new THREE.MeshBasicMaterial({ color: 0x0f766e, transparent: true, opacity: 0.25, side: THREE.DoubleSide, toneMapped: false }))
    disk.rotation.x = -Math.PI / 2
    disk.position.y = Y - 0.6
    this.root.add(disk)
    this.add({ kind: 'universal', key: 'universal' }, this.universalCore, 'The Universal RTE — the root every room is seated into', () => ({ anchor: new THREE.Vector3(0, Y, 0), camera: new THREE.Vector3(0, Y + 7, 24) }))
    const n = this.reg.rtes.length
    this.reg.rtes.forEach((r, i) => {
      const a = (i / n) * Math.PI * 2 + Math.PI / 2
      const g = new THREE.Group()
      g.position.set(Math.cos(a) * 11.5, Y, Math.sin(a) * 11.5)
      const color = STATUS_COLOR(r.status)
      const base = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.6, 0.55, 6), new THREE.MeshStandardMaterial({ color: 0x0f1d2b, metalness: 0.7, roughness: 0.3, emissive: color, emissiveIntensity: 0.15 }))
      const emblem = new THREE.Mesh(r.kind === 'spec' ? new THREE.OctahedronGeometry(0.6, 0) : r.kind === 'unity' ? new THREE.DodecahedronGeometry(0.6, 0) : new THREE.IcosahedronGeometry(0.62, 0), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.1, flatShading: true }))
      emblem.position.y = 1.5
      emblem.name = 'emblem'
      const title = text3D(this.font, r.name.replace('Athletic Intelligence RTE', 'ATHLETIC RTE').replace('Baseball Diamond Module', 'BASEBALL DIAMOND').replace('DCCP Crypto Flight HUD', 'CRYPTO FLIGHT HUD').replace('Public Sector à la carte', 'PUBLIC SECTOR').replace('Energy & SCADA RTE', 'ENERGY · SCADA').toUpperCase(), { size: 0.34, emissive: color, emissiveIntensity: 0.6 })
      title.position.y = 2.7
      const spoke = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 9.5, 6), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.4, toneMapped: false }))
      spoke.rotation.z = Math.PI / 2
      spoke.position.set(-5.4, 0.1, 0)
      g.add(base, emblem, title)
      g.lookAt(0, Y, 0)
      g.rotateY(Math.PI)
      const spokeHolder = new THREE.Group()
      spokeHolder.position.copy(g.position)
      spokeHolder.lookAt(0, Y, 0)
      spokeHolder.rotateY(Math.PI / 2)
      spoke.position.set(-4.9 + 0.0, 0, 0)
      spokeHolder.add(spoke)
      this.root.add(g, spokeHolder)
      this.add({ kind: 'rte', key: r.key }, g, `${r.name} — ${r.status}`, () => {
        const out = g.position.clone().setY(0).normalize()
        return { anchor: g.position.clone().add(new THREE.Vector3(0, 1.4, 0)), camera: g.position.clone().add(out.multiplyScalar(7)).add(new THREE.Vector3(0, 3.2, 0)) }
      })
    })
  }

  // ---------- DCLM machine ----------
  private buildDclm(): void {
    const Y = 21
    this.dclmCore.position.set(0, Y, 0)
    const core = new THREE.Mesh(new THREE.SphereGeometry(1.2, 32, 16), new THREE.MeshStandardMaterial({ color: 0xe9d5ff, emissive: 0xa855f7, emissiveIntensity: 1.2, metalness: 0.3, roughness: 0.2 }))
    this.dclmCore.add(core)
    for (let i = 0; i < 3; i++) {
      const cube = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(2.6 + i * 1.1, 2.6 + i * 1.1, 2.6 + i * 1.1)), new THREE.LineBasicMaterial({ color: i === 1 ? 0x14b8a6 : 0xa855f7, transparent: true, opacity: 0.8 - i * 0.2 }))
      cube.userData.spin = (i + 1) * 0.18 * (i % 2 ? -1 : 1)
      this.dclmCore.add(cube)
    }
    this.root.add(this.dclmCore)
    const label = text3D(this.font, 'DCLM', { size: 1.1, emissive: 0xa855f7, emissiveIntensity: 0.8 })
    label.position.set(0, Y + 4.2, 0)
    this.root.add(label)
    const seq = Math.max(0, ...this.integrity.flatMap(m => m.receipt?.receipts.map(r => r.sequence ?? 0) ?? [0]))
    const seqLabel = text3D(this.font, `KERNEL SEQ ${seq}`, { size: 0.36, emissive: 0x14b8a6, emissiveIntensity: 0.5 })
    seqLabel.position.set(0, Y - 3.4, 0)
    this.root.add(seqLabel)
    this.integrity.forEach((m, i) => {
      const color = m.state === 'MATCH' ? 0x22c55e : m.state === 'UNCHECKED' ? 0xf59e0b : 0xef4444
      const node = new THREE.Mesh(new THREE.OctahedronGeometry(0.28), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.3 }))
      node.userData.phase = (i / this.integrity.length) * Math.PI * 2
      node.name = `module:${m.module}`
      this.dclmNodes.push(node)
      this.root.add(node)
    })
    this.add({ kind: 'dclm', key: 'dclm' }, this.dclmCore, 'The DCLM machine — module receipts and client-side integrity status', () => ({ anchor: new THREE.Vector3(0, Y, 0), camera: new THREE.Vector3(0, Y + 2, 12) }))
  }

  // ---------- DCCP pipe ----------
  private buildPipe(): void {
    const pts = [new THREE.Vector3(0, 21, 0), new THREE.Vector3(10, 23.5, -7), new THREE.Vector3(19, 21, -13), new THREE.Vector3(26, 14, -16), new THREE.Vector3(30, 6, -15), new THREE.Vector3(32, -2, -10)]
    const curve = new THREE.CatmullRomCurve3(pts)
    this.pipeMat = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform float uTime; varying vec2 vUv; void main(){ float p=fract(vUv.x*6.0-uTime*0.35); float pulse=smoothstep(0.0,0.08,p)*smoothstep(0.22,0.08,p); vec3 c=mix(vec3(0.08,0.72,0.65),vec3(0.66,0.33,0.97),vUv.x); gl_FragColor=vec4(c*(0.35+2.2*pulse), 0.55+0.45*pulse); }',
      transparent: true, depthWrite: false, toneMapped: false,
    })
    const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 200, 0.2, 10, false), this.pipeMat)
    this.root.add(tube)
    const stages: [string, string][] = [['proposal', 'PROPOSAL'], ['quorum', 'QUORUM'], ['finalize', 'FINALIZE'], ['ipfs', 'IPFS · PINATA'], ['ipns', 'IPNS']]
    stages.forEach(([key, name], i) => {
      const p = pts[i + 1]
      const g = new THREE.Group()
      g.position.copy(p)
      const node = new THREE.Mesh(key === 'ipfs' ? new THREE.CylinderGeometry(0.9, 0.9, 0.5, 6) : key === 'ipns' ? new THREE.ConeGeometry(0.7, 1.6, 6) : new THREE.SphereGeometry(0.6, 20, 12), new THREE.MeshStandardMaterial({ color: 0xc4b5fd, emissive: i < 3 ? 0x7c3aed : 0x0ea5e9, emissiveIntensity: 0.9, metalness: 0.4, roughness: 0.3 }))
      if (key === 'ipfs') node.rotation.x = Math.PI / 2
      const label = text3D(this.font, name, { size: 0.42, emissive: 0xa855f7, emissiveIntensity: 0.5 })
      label.position.y = 1.5
      g.add(node, label)
      g.lookAt(p.x * 0.4, p.y, 30)
      this.root.add(g)
      this.add({ kind: 'pipe', key }, g, `DCCP release pipe: ${name} — design, not deployed`, () => ({ anchor: p.clone(), camera: p.clone().add(new THREE.Vector3(2, 2.5, 9)) }))
    })
    const design = text3D(this.font, 'DCCP PIPE · DESIGN', { size: 0.5, emissive: 0x0ea5e9, emissiveIntensity: 0.5 })
    design.position.set(21, 25.5, -10)
    design.lookAt(0, 25.5, 30)
    this.root.add(design)
  }

  // ---------- live instruments ----------
  private buildInstruments(): void {
    const keys = ['weather', 'river', 'quakes', 'iss', 'kp', 'carbon']
    keys.forEach((k, i) => {
      const col = i % 3
      const row = Math.floor(i / 3)
      const a = THREE.MathUtils.degToRad(196 + col * 17)
      const anchor = new THREE.Vector3(Math.cos(a) * 30, 5.2 - row * 6.2, -Math.sin(a) * 30)
      const g = new THREE.Group()
      g.position.copy(anchor)
      const facing = new THREE.Vector3(0, anchor.y, 14).sub(anchor).normalize()
      g.lookAt(anchor.clone().add(facing))
      const beacon = new THREE.Mesh(new THREE.OctahedronGeometry(0.55), new THREE.MeshStandardMaterial({ color: 0x8eb4c8, emissive: 0x8eb4c8, emissiveIntensity: 1.1, flatShading: true }))
      beacon.name = 'beacon'
      g.add(beacon)
      this.root.add(g)
      this.instruments.set(k, { group: g, anchor, facing, rendered: 0 })
      this.add({ kind: 'feed', key: k }, g, `Live instrument: ${k}`, () => ({ anchor: anchor.clone(), camera: anchor.clone().add(facing.clone().multiplyScalar(11)) }))
    })
    const title = text3D(this.font, 'LIVE PUBLIC FEEDS', { size: 0.62, emissive: 0x38bdf8, emissiveIntensity: 0.6 })
    const a = THREE.MathUtils.degToRad(213)
    title.position.set(Math.cos(a) * 30, 10.6, -Math.sin(a) * 30)
    title.lookAt(0, 10.6, 14)
    this.root.add(title)
  }

  renderInstrument(key: string, st: FeedStatus | undefined, v: FeedValues, now: number): void {
    const inst = this.instruments.get(key)
    if (!inst || !st) return
    const ago = st.lastOk ? Math.max(0, Math.round((now - st.lastOk) / 60000)) : null
    const when = ago === null ? 'not yet updated' : ago < 1 ? 'updated under a minute ago' : `updated ${ago} min ago`
    let value = '—'
    let detail = ''
    if (st.state === 'LIVE' || st.state === 'STALE') {
      if (key === 'weather' && v.weather) { value = `${Math.round(v.weather.tempC)} °C`; detail = `Wind ${Math.round(v.weather.windKmh)} km/h · observation ${v.weather.at.replace('T', ' ')} local` }
      if (key === 'river' && v.river) { value = v.river.levelM !== undefined ? `${v.river.levelM.toFixed(2)} m` : 'no level'; detail = `${v.river.dischargeM3s !== undefined ? `Discharge ${v.river.dischargeM3s.toFixed(1)} m³/s · ` : ''}provisional · ${v.river.at.slice(0, 16).replace('T', ' ')} UTC` }
      if (key === 'quakes' && v.quakes) { value = `${v.quakes.count} quakes`; detail = v.quakes.strongest ? `Strongest M${v.quakes.strongest.mag.toFixed(1)} · ${v.quakes.strongest.place}` : '' }
      if (key === 'iss' && v.iss) { value = `${Math.round(v.iss.altKm)} km up`; detail = `${v.iss.lat.toFixed(1)}°, ${v.iss.lon.toFixed(1)}° · ${Math.round(v.iss.speedKmh).toLocaleString('en-US')} km/h · ${v.iss.visibility}` }
      if (key === 'kp' && v.kp) { value = `Kp ${v.kp.kp.toFixed(1)}`; detail = `${v.kp.kp >= 5 ? 'Geomagnetic storm' : v.kp.kp >= 4 ? 'Active' : 'Quiet'} · ${v.kp.at.replace('T', ' ').slice(0, 16)} UTC` }
      if (key === 'carbon' && v.carbon) { value = `${Math.round(v.carbon.intensity)} gCO₂/kWh`; detail = `Index ${v.carbon.index} · from ${v.carbon.from.replace('T', ' ').replace('Z', ' UTC')}` }
    }
    const accent = st.state === 'LIVE' ? '#22c55e' : st.state === 'STALE' ? '#f59e0b' : st.state === 'PENDING' ? '#8eb4c8' : '#ef4444'
    if (inst.plate) { inst.group.remove(inst.plate); inst.plate.userData.dispose?.() }
    const plate = textPlate({ width: 8.2, title: `${st.title}`, lines: [`${value}`, detail || (st.state === 'UNAVAILABLE' ? `Source did not answer${st.lastError ? ` (${st.lastError})` : ''}; retrying with backoff.` : 'Waiting for first reading.'), `Source: ${st.source}`], accent, footer: `${st.state} · ${when}` })
    plate.traverse(o => { o.userData.pick = { kind: 'feed', key } })
    inst.group.add(plate)
    inst.plate = plate
    const beacon = inst.group.getObjectByName('beacon') as THREE.Mesh | undefined
    if (beacon) { const bm = beacon.material as THREE.MeshStandardMaterial; bm.color.set(accent); bm.emissive.set(accent) }
    inst.rendered = now
  }

  instrumentAge(key: string): number {
    return this.instruments.get(key)?.rendered ?? 0
  }

  // ---------- detail plate ----------
  showDetail(anchor: THREE.Vector3, title: string, lines: string[], accent: string, footer?: string): void {
    this.clearDetail()
    const plate = textPlate({ width: 6.4, title, lines, accent, footer })
    plate.position.copy(anchor)
    plate.userData.anchor = anchor.clone()
    this.detail = plate
    this.root.add(plate)
  }

  /** A soft gold ring that marks the chosen place. Replaces in-world text plates (the card carries the words). */
  mark(anchor: THREE.Vector3 | null): void {
    this.markerAt = anchor ? anchor.clone() : null
    this.marker.visible = !!anchor
  }

  clearDetail(): void {
    if (!this.detail) return
    this.root.remove(this.detail)
    this.detail.userData.dispose?.()
    this.detail = undefined
  }

  // ---------- per-frame ----------
  update(dt: number, t: number, camera: THREE.Camera, now: Date, reducedMotion: boolean): void {
    const ss = subsolar(now)
    latLonToVec(ss.lat, ss.lon, 1, this.sunDir).normalize()
    this.sunSprite.position.copy(this.sunDir).multiplyScalar(380)
    const sun = this.root.getObjectByName('sun') as THREE.DirectionalLight | undefined
    sun?.position.copy(this.sunDir).multiplyScalar(100)
    const motion = reducedMotion ? 0.15 : 1
    for (const m of this.pillars.values()) {
      const h = m.userData.targetHeight ?? 0.3
      m.scale.y += (h - m.scale.y) * Math.min(1, dt * 4)
      const cap = m.children[0] as THREE.Mesh
      cap.position.y = 1
      cap.scale.set(1, 1 / Math.max(0.05, m.scale.y), 1)
    }
    for (const g of this.sectorTokens.values()) g.children[0].rotation.y += dt * 0.6 * motion
    for (const g of this.chambers.values()) { const gl = g.getObjectByName('glyph'); if (gl) gl.rotation.y += dt * 0.5 * motion }
    this.universalCore.rotation.y += dt * 0.25 * motion
    this.root.traverse(o => { if (o.name === 'emblem') o.rotation.y += dt * 0.8 * motion })
    this.dclmCore.children.forEach(c => { if (c.userData.spin) { c.rotation.x += dt * c.userData.spin * motion; c.rotation.y += dt * c.userData.spin * 0.7 * motion } })
    this.dclmNodes.forEach(n => {
      const a = n.userData.phase + t * 0.4 * motion
      n.position.set(Math.cos(a) * 3.8, 21 + Math.sin(a * 2) * 0.5, Math.sin(a) * 3.8)
      n.rotation.y += dt
    })
    this.estates.rotation.y += dt * 0.05 * motion
    this.pipeMat.uniforms.uTime.value = t * motion
    // quakes pulse
    for (let i = 0; i < this.quakes.count; i++) {
      const q = this.quakeData[i]
      latLonToVec(q.lat, q.lon, EARTH_R + 0.05, this.tmp)
      const s = (0.07 + (q.mag - 2.5) * 0.045) * (1 + 0.25 * Math.sin(t * 3 * motion + i))
      this.dummy.position.copy(this.tmp)
      this.dummy.scale.setScalar(Math.max(0.05, s))
      this.dummy.updateMatrix()
      this.quakes.setMatrixAt(i, this.dummy.matrix)
    }
    this.quakes.instanceMatrix.needsUpdate = true
    if (this.iss.visible) {
      this.iss.position.lerp(this.issTarget, Math.min(1, dt * 0.8))
      this.iss.lookAt(0, 0, 0)
    }
    // ---- folding: the far view shows the planet and the main holograms; detail unfolds as you approach ----
    const h = camera.position.length() - EARTH_R
    this.tier = tierOf(h)
    const fk = this.focusKind
    // Pillars belong to the cloud layer: they fold away at orbit (unless asked for) and again near the ground.
    const pillarsOn = this.tier === 'cloud' || ((fk === 'sector' || fk === 'jurisdiction') && this.tier !== 'street')
    for (const m of this.pillars.values()) m.visible = pillarsOn
    // Below orbit the main holograms step aside if they would sit in front of you; the one you chose stays.
    for (const g of this.sectorTokens.values()) g.visible = this.tier === 'orbit' || fk === 'sector' || camera.position.distanceTo(g.position) > 14
    const canadaOn = (this.tier === 'cloud' && h < 12) || fk === 'canada'
    for (const m of this.canadaRings) m.visible = canadaOn
    for (const inst of this.instruments.values()) {
      const near = camera.position.distanceTo(inst.anchor) < 24 || fk === 'feed'
      if (inst.plate) inst.plate.visible = near
      const b = inst.group.getObjectByName('beacon')
      if (b) { b.visible = !near || !inst.plate; b.rotation.y += dt * 0.9 * motion }
    }
    this.geo.update(camera, (camera as THREE.PerspectiveCamera).userData.lookAt ?? this.tmp.set(0, 0, 0), dt)
    if (this.markerAt) {
      const d = camera.position.distanceTo(this.markerAt)
      this.marker.position.copy(this.markerAt)
      this.marker.quaternion.copy(camera.quaternion)
      this.marker.scale.setScalar(Math.max(0.05, d * 0.035) * (1 + (reducedMotion ? 0 : 0.08 * Math.sin(t * 3))))
    }
    // Every extruded label turns (upright, yaw only) to face the visitor, so text never reads backwards.
    // Labels fold away with distance: big hub titles stay, small titles appear only when you are near them.
    if (!this.labels) {
      this.labels = []
      this.root.traverse(o => { if (o.name.startsWith('text:')) this.labels!.push(o) })
      for (const o of this.labels) {
        this.box.setFromObject(o).getSize(this.sz)
        this.labelSize.set(o, Math.min(this.sz.y, 2))
      }
    }
    for (const o of this.labels) {
      if (!o.parent) continue
      const size = this.labelSize.get(o) ?? 0.4
      const reach = size >= 0.6 ? 80 : size >= 0.36 ? 34 : 19
      o.getWorldPosition(this.wp)
      o.visible = camera.position.distanceTo(this.wp) < reach
      if (!o.visible) continue
      o.getWorldPosition(this.wp)
      const yaw = Math.atan2(camera.position.x - this.wp.x, camera.position.z - this.wp.z)
      this.qa.setFromAxisAngle(this.yAxis, yaw)
      o.parent.getWorldQuaternion(this.qb)
      o.quaternion.copy(this.qb.invert().multiply(this.qa))
    }
    if (this.detail) {
      // Camera-space placement: the slab always fits (≤ 42% of view width, ≤ 72% of height),
      // sits beside the subject (right on landscape, low on portrait) and floats with slight parallax.
      const cam = camera as THREE.PerspectiveCamera
      const w = 6.4
      const h = (this.detail.userData.height as number | undefined) ?? 4
      const d = 9
      const viewH = 2 * d * Math.tan(THREE.MathUtils.degToRad(cam.fov / 2))
      const viewW = viewH * cam.aspect
      const portrait = cam.aspect < 0.9
      const scale = Math.min((viewW * (portrait ? 0.9 : 0.42)) / w, (viewH * (portrait ? 0.42 : 0.72)) / h)
      const offX = portrait ? 0 : viewW / 2 - (w * scale) / 2 - viewW * 0.04
      const offY = portrait ? -viewH / 2 + (h * scale) / 2 + viewH * 0.12 : viewH * 0.02
      const target = this.tmp.set(offX, offY, -d).applyMatrix4(cam.matrixWorld)
      if (!this.detail.userData.placed) { this.detail.position.copy(target); this.detail.userData.placed = true }
      else this.detail.position.lerp(target, Math.min(1, dt * (reducedMotion ? 30 : 6)))
      this.detail.scale.setScalar(scale)
      this.detail.quaternion.copy(cam.quaternion)
      if (!reducedMotion) this.detail.rotateY(portrait ? 0 : -0.12 + Math.sin(t * 0.6) * 0.015)
    }
  }
}
