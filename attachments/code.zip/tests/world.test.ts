// @ts-nocheck — Node-side test (node:fs, node:crypto); type-checked by Vitest at runtime, not the browser tsconfig.
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { IrisBrain, normalize, speakable, type LiveSnapshot } from '../src/iris/brain'
import { splitSentences } from '../src/iris/voice'
import { integrityOf, MODULES } from '../src/data/registry'
import type { ReceiptsDoc, Registry } from '../src/data/types'
import { backoffMs, fetchJson, LiveFeeds, stateOf, FEEDS } from '../src/live/feeds'
import { handleFromPublicKey } from '../src/unity/unityid'

const read = (m: string) => readFileSync(`public/registry/${m}.json`)
const reg: Registry = {
  doctrine: JSON.parse(read('doctrine').toString()), sectors: JSON.parse(read('sectors').toString()), pharmacology: JSON.parse(read('pharmacology').toString()),
  jurisdictions: JSON.parse(read('jurisdictions').toString()), canada: JSON.parse(read('canada').toString()), rtes: JSON.parse(read('rtes').toString()),
  chambers: JSON.parse(read('chambers').toString()), verdict: JSON.parse(read('trinity-verdict').toString()),
}
const receipts: ReceiptsDoc = JSON.parse(readFileSync('public/dclm-receipts.json', 'utf8'))
const now = Date.UTC(2026, 9, 3, 8, 0, 0)
const snap = (): LiveSnapshot => ({
  values: { iss: { lat: 12.3, lon: -45.6, altKm: 421, speedKmh: 27600, visibility: 'daylight', at: now }, quakes: { count: 31, items: [], generated: now, strongest: { id: 'x', mag: 5.4, place: '10 km S of Somewhere', time: now, lat: 0, lon: 0, depthKm: 10 } } },
  status: FEEDS.map(f => ({ key: f.key, title: f.title, source: f.source, state: f.key === 'iss' || f.key === 'quakes' ? 'LIVE' : f.key === 'kp' ? 'UNAVAILABLE' : 'PENDING', lastOk: f.key === 'iss' || f.key === 'quakes' ? now - 120_000 : null, lastError: f.key === 'kp' ? 'timed out' : null, failures: f.key === 'kp' ? 3 : 0, nextAt: 0 })),
})
const brain = () => new IrisBrain(reg, snap, () => ({ locked: 8, total: 8, mismatched: [] }), () => null)

describe('registry and DCLM receipts', () => {
  it('has every module receipted in lockstep and byte-identical to the shipped file', () => {
    expect(receipts.modules.map(m => m.module).sort()).toEqual([...MODULES].sort())
    for (const m of receipts.modules) {
      const hash = createHash('sha256').update(read(m.module)).digest('hex')
      expect(m.lockstep).toBe(true)
      expect(m.receipts).toHaveLength(2)
      expect(m.receipts[0].inputDigest).toBe(m.receipts[1].inputDigest)
      expect(m.receipts[1].sequence).toBeGreaterThan(m.receipts[0].sequence!)
      expect(integrityOf(m, hash)).toBe('MATCH')
      expect(integrityOf(m, hash.replace(/^./, c => (c === '0' ? '1' : '0')))).toBe('MISMATCH')
    }
    expect(integrityOf(undefined, 'abc')).toBe('NOT-LOCKED')
    expect(integrityOf(receipts.modules[0], undefined)).toBe('UNCHECKED')
  })
  it('loads all sectors, jurisdictions, scopes, RTEs and chambers', () => {
    expect(reg.sectors.map(s => s.key).sort()).toEqual(['climate', 'energy', 'food', 'pandemic', 'water'])
    expect(reg.jurisdictions.length).toBeGreaterThanOrEqual(20)
    expect(reg.canada.length).toBe(7)
    expect(reg.rtes.length).toBe(12)
    expect(reg.chambers.length).toBe(21)
    for (const j of reg.jurisdictions) expect(Number.isFinite(j.lat) && Number.isFinite(j.lon)).toBe(true)
  })
})

describe('Iris diverter', () => {
  it('is deterministic: same words, same reply', () => {
    for (const q of ['how is japan in water', 'tell me about the design law', 'where is the space station', 'what is the universal rte'])
      expect(brain().respond(q, now)).toEqual(brain().respond(q, now))
  })
  it('answers a grade from the registry and never invents one', () => {
    const r = brain().respond('How is Japan doing in water?', now)
    const g = reg.jurisdictions.find(j => j.name === 'Japan')!.grades.water
    expect(r.target).toEqual({ kind: 'jurisdiction', key: 'Japan' })
    expect(r.sector).toBe('water')
    expect(r.speech.toLowerCase()).toContain(({ 'AT BENCHMARK': 'at benchmark', NEAR: 'near benchmark', GAPPED: 'gapped', THIN: 'thin', UNGRADED: 'not graded' } as const)[g.grade])
    const ungraded = reg.jurisdictions.find(j => !j.grades.food)
    if (ungraded) expect(brain().respond(`how is ${ungraded.name} in food`, now).speech).toMatch(/not graded in Food\. I will not guess/)
  })
  it('routes every chamber, RTE, sector, scope and feed to a target', () => {
    const b = brain()
    for (const c of reg.chambers) expect(b.describe({ kind: 'chamber', key: c.key }).target).toEqual({ kind: 'chamber', key: c.key })
    for (const r of reg.rtes) expect(b.describe({ kind: 'rte', key: r.key }).speech).toContain(r.name.split(' ')[0])
    for (const s of ['water', 'energy', 'climate', 'food', 'pandemic', 'pharmacology']) expect(b.respond(`show me ${s}`, now).sector).toBe(s)
    for (const c of reg.canada) expect(b.describe({ kind: 'canada', key: c.key }).speech).toContain(c.name)
    expect(b.respond('take me to ontario', now).target).toEqual({ kind: 'canada', key: 'on' })
    expect(b.respond('teacher room', now).target).toEqual({ kind: 'rte', key: 'teach' })
    expect(b.respond('scada microgrid', now).target).toEqual({ kind: 'rte', key: 'energy' })
    expect(b.respond('what is unity id', now).target).toEqual({ kind: 'chamber', key: 'unity-id' })
  })
  it('reports live feeds with source and freshness, and admits unavailability', () => {
    const b = brain()
    const iss = b.respond('where is the space station', now)
    expect(iss.speech).toMatch(/421 kilometres up/)
    expect(iss.speech).toMatch(/wheretheiss\.at/)
    expect(iss.speech).toMatch(/2 minutes ago/)
    expect(b.respond('any earthquakes', now).speech).toMatch(/31 earthquakes/)
    expect(b.respond('aurora tonight', now).speech).toMatch(/unavailable right now/)
    expect(b.respond('weather in belleville', now).speech).toMatch(/still loading/)
  })
  it('holds jacket binding and requires confirmation before a Unity ID', () => {
    const b = brain()
    expect(b.respond('bind my api v2 jacket', now).speech).toMatch(/on hold/)
    const d = b.respond('create my unity id', now)
    expect(d.action).toBe('unity-id-disclose')
    expect(d.speech).toMatch(/not issued by the Unity Network/)
    expect(b.respond('confirm', now).action).toBe('unity-id-create')
    b.respond('create my unity id', now)
    expect(b.respond('cancel', now).action).toBe('none')
  })
  it('supports follow-ups and graceful fallbacks', () => {
    const b = brain()
    b.respond('tell me about water', now)
    const more = b.respond('tell me more', now)
    expect(more.speech).toMatch(new RegExp(reg.sectors.find(s => s.key === 'water')!.rows[0].jurisdiction))
    expect(b.respond('repeat', now).speech).toBe(more.speech)
    expect(b.respond('quantum banana', now).speech).toMatch(/do not hold that yet/)
    expect(b.respond('', now).speech).toMatch(/did not catch/)
    expect(b.respond('go home', now).action).toBe('home')
    expect(b.respond('goodbye', now).action).toBe('sleep')
  })
  it('never runs two registry sentences together', () => {
    const b = brain()
    const run = /[a-z0-9] [A-Z][a-z]+ (research|said|words)/
    for (const j of reg.jurisdictions) for (const k of Object.keys(j.grades)) expect(b.respond(`how is ${j.name} in ${k}`, now).speech).not.toMatch(/[a-z0-9)] Pilot research/)
    for (const c of reg.chambers) expect(b.describe({ kind: 'chamber', key: c.key }).speech).not.toMatch(/[a-z0-9] (In David's words|This chamber)/)
    for (const r of reg.rtes) expect(b.describe({ kind: 'rte', key: r.key }).speech).not.toMatch(run)
  })
  it('speaks registry symbols safely', () => {
    expect(speakable('Twain² → 0:1 · done — ok')).toBe('Twain squared to zero colon one, done, ok')
    expect(normalize('Québec!')).toBe(' quebec ')
    for (const c of reg.chambers) expect(brain().describe({ kind: 'chamber', key: c.key }).speech).not.toMatch(/[→·²≤≥“”]/)
  })
})

describe('voice chunking', () => {
  it('splits long speech into bounded sentences without losing words', () => {
    const text = 'One. ' + 'word, '.repeat(80) + 'end. Two?'
    const parts = splitSentences(text, 120)
    expect(parts.every(p => p.length <= 120)).toBe(true)
    expect(parts.join(' ').replace(/\s+/g, ' ')).toBe(text.trim().replace(/\s+/g, ' '))
  })
})

describe('live feeds never hang', () => {
  it('computes freshness states and capped backoff', () => {
    expect(stateOf({ lastOk: null, failures: 0 }, 1000, 0)).toBe('PENDING')
    expect(stateOf({ lastOk: null, failures: 2 }, 1000, 0)).toBe('UNAVAILABLE')
    expect(stateOf({ lastOk: 0, failures: 0 }, 1000, 500)).toBe('LIVE')
    expect(stateOf({ lastOk: 0, failures: 0 }, 1000, 5000)).toBe('STALE')
    expect(backoffMs(60_000, 20)).toBe(600_000)
    expect(backoffMs(5_000, 1)).toBeGreaterThanOrEqual(5_000)
  })
  it('times out a fetcher that ignores abort', async () => {
    const never = (() => new Promise<Response>(() => undefined)) as unknown as typeof fetch
    const t0 = Date.now()
    await expect(fetchJson('x', 150, never)).rejects.toThrow(/timed out/)
    expect(Date.now() - t0).toBeLessThan(1000)
  })
  it('marks a failing feed UNAVAILABLE and keeps others LIVE', async () => {
    const fetcher = (async (url: string) => {
      if (url.includes('wheretheiss')) return new Response(JSON.stringify({ latitude: 1, longitude: 2, altitude: 420, velocity: 27000, visibility: 'eclipsed', timestamp: 1 }))
      throw new Error('offline')
    }) as unknown as typeof fetch
    const f = new LiveFeeds(FEEDS, 500, fetcher)
    f.start()
    await new Promise(r => setTimeout(r, 200))
    f.stop()
    expect(f.status.get('iss')!.state).toBe('LIVE')
    expect(f.values.iss!.altKm).toBe(420)
    expect(f.status.get('weather')!.state).toBe('UNAVAILABLE')
    expect(f.status.get('weather')!.lastError).toBe('offline')
  })
})

describe('pilot Unity handle', () => {
  it('derives a stable 32-hex handle from the public key bytes', async () => {
    const key = new Uint8Array([1, 2, 3, 4, 5]).buffer
    const h = await handleFromPublicKey(key)
    expect(h).toMatch(/^unity:pilot\.[0-9a-f]{32}$/)
    expect(h).toBe(`unity:pilot.${createHash('sha256').update(Buffer.from([1, 2, 3, 4, 5])).digest('hex').slice(0, 32)}`)
    expect(await handleFromPublicKey(key)).toBe(h)
  })
})
