# DCCP World build progress (updated 2026-10-03 04:19 ET)

## Trinity verdict (trinity/VERDICT-DCCPWORLD-V1.json, trinity/CONDITIONS.md)
P1–P17 admitted (P17 Unity ID as pilot handle with conditions). P18 (automatic API v2 jacket binding) held by Iris.

## Done and verified
- src/main.ts orchestrator (entry modes talk/listen/read, Iris loop, picking, flights, keyboard, gamepad, feeds, discovery, perf guard)
- Quality: ?quality=low|medium|high override; auto-low on SwiftShader/llvmpipe; webglcontextlost -> message
- Entry fix: overlay.enter() before audio; AudioContext.resume() raced with 1.5 s timeout (it hung forever without a trusted gesture)
- feeds.ts fetchJson: hard Promise.race deadline (fetcher ignoring abort cannot hang)
- world.ts: detail plate in camera space (always fits; right side landscape, bottom portrait); all `text:` meshes yaw-billboard to camera
- brain.ts: sentence() helper closes spliced registry fragments
- main.ts detailFor: 'feed' plate with reading, source, state, last-good age, last error
- index.html replaced; public/favicon.svg (Iris orb); styles/main.css replaced; NotoSansSC removed
- tests/world.test.ts: 15 tests pass (receipts byte-match, diverter determinism, grades, routing, feeds, timeouts, Unity handle, punctuation)
- pnpm build passes: JS 195 KB gzip, transfer 2.06 MB
- Browser check (SwiftShader): 87 pickables, 84 Atlas places, 8/8 DCLM MATCH, 6/6 feeds LIVE, 21/21 chambers discoverable, zero console errors
- scripts/smoke.mjs rewritten: desktop/read/phone/offline/tamper scenarios (running: /tmp/smoke.log)

## Remaining
1. Smoke PASS
2. Sharing: webdev.config POST game/sharing/prepare {}; assets/share/favicon.png (from favicon.svg); OG cover (AI-generated, 1200x630, lettering "DCCP World"); game-sharing.json schemaVersion 2 with title/description
3. Read references/deployment.md; git fetch origin main; integrate; commit; push canonical main; confirm checkpoint recorded
4. Report preview URL; publishing is separate and needs user authorization

## 2026-10-03 04:35 — audio fix + altitude storyboard (in progress)
- Audio fixed (tsc OK, not yet browser-verified): voice.ts no held getUserMedia stream; greeting spoken synchronously in entry tap; cancel only if queued + resume(); start watchdog -> blocked -> replay on next pointerdown/keydown; synthetic orb spectrum. ambient.ts: soft sine pad >200 Hz highpass, 0.07 level, ducks during speech, OFF by default; prefs key v2; sound button = "Ambient music". haptics.ts: audio thump removed.
- User storyboard: ORBIT (celestial + main holos; clusters expand on approach) -> CLOUD (countries/companies; borders appear; country tap = telemetry plate + zoom) -> CIVIC (provinces, regions, municipal feeds) -> STREET (individual/social; nothing held by design).
- Borders source: Natural Earth 1:50m admin-0 GeoJSON https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson (public domain), fields NAME ISO_A3 ADM0_A3 CONTINENT SUBREGION POP_EST POP_YEAR GDP_MD GDP_YEAR LABEL_X LABEL_Y; 242 features. scripts/build_countries.py -> public/registry/countries.json (9th DCLM module; lockstep globs registry/*.json). Need MODULES + tests/smoke 8->9.
- Country telemetry plan: Open-Meteo current at LABEL point (CORS OK), USGS quake count in polygon, NE population (dataset year), sector grades if jurisdiction.
